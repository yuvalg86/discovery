#include <atomic>
#include <functional>
#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
#include <memory>
#include <vector>
#include <algorithm>

using namespace std;

/*********
 *Headers*
 ********/
class provider;

//logger will print output in a manner suitable for parsing and graph creation
template<class out>
class logger {
  void log();
};
class offer_status {
};
class offer {
};
class offer_descriptor {
};
class offer_container {
};
class job_status {
};
class resource_status {
};
class provider_status {
};
class client_status {
};
class job_descriptor {
};
class provider_descriptor {
};
class client_descriptor {
};
//directory will provide interface for clients to query about providers
/*
  template<>
  class directory {
  get_providers();
  get_capable_providers();
  get_capable_providers_sorted_by_price();
  register_provider();
  deregister_provider();
  };
  //engine will 'execute' jobs for a provider
  template<>
  class engine {
  void execute_job_on_resource();  
  };
*/



//resource is a representation of a machine that runs jobs
class component {
private:
  int _ncpu, _mem;
public:
  component(int ncpu = 1, int mem = 1024):_ncpu{ncpu},_mem{mem}
  {
    
  }
  int getNcpu()
  {
    return _ncpu;
  }
  int getMem()
  {
    return _mem;
  }
  /*
    get_capabilities();
    get_resource_status();
    evict_job();
    load_job();
  */
  bool greater_or_equal( component other )
  {
    return (_ncpu >= other._ncpu && _mem >= other._mem); 
  }
};

class resource : public component {
public:
  resource(int ncpu = 1, int mem = 1024):component(ncpu, mem){}
};

class job : public component {
  using step_func = function<void()>;
private:
  static int id;
  int _id;
  step_func _step;
public:
  job(int ncpu = 1, int mem = 1024, step_func sfunc = [](){}):component(ncpu, mem),_id{id++},
						     _step{sfunc}{}
  int get_id(){return _id;}
  void execute_step() {_step();}
};
int job::id = 0;

//interface to query and execute jobs
class resource_container {
};
/*
//representation of a job
class job {
get_demands();
run_for_round();
get_job_status();
suspend_job();
};

//interface to hold jobs at various states
class job_container {
iterate_jobs();
is_done();
is_stuck();
add_job();
remove_job();
};*/

//represents a provider in the alg
//template<class >
class provider {
public:
  enum class rejection_main_reason {
    not_capable,
    low_price,
    outbidded,
    bid_window_closed
  };
  using accept_responce = function<void()>;
  using reject_responce = function<void(rejection_main_reason)>;
  using price_update_func = function<int(bool, int)>;
  using bid_loop_thread_type = function<void()>;
  
  provider(resource r, price_update_func f = default_price_update):
    _r{r},
    _price{0},
    _bid_window_open{false},
    _bid_loop{false},
    //_associated_job{nullptr},
    _price_update_policy{f}//,
    //_bid_loop_thread_func{},
    //_bid_loop_thread{nullptr}
  {
    _bid_loop_thread_func = [&]()
      {
	//open_bid_window();
	while(_bid_loop)
	  {
	    using namespace std::chrono_literals;
	    bid_window_loop_step();
	    this_thread::sleep_for(get_bid_window_open()?100ms:10ms); //TODO: refactor _step() to reopen
	  }
	close_bid_window();
      };
  }
  bool capable(job j)
  {
    return _r.greater_or_equal(j);
  }
  int get_price() {return _price;}
  void bid(job& job, int price, accept_responce accept, reject_responce reject)
  {
    lock_guard<mutex> tmp(guard);
    if (!capable(job))
      {
	reject(rejection_main_reason::not_capable);
      }
    else if (_bid_window_open != true)
      {
	reject(rejection_main_reason::bid_window_closed);
      }
    else if (_price > price)
      {
	reject(rejection_main_reason::low_price);
      }
    else
      {
	if (has_associated_job())
	  {
	    _late_rejection_func(rejection_main_reason::outbidded);
	  }
	{//extract to func + lock guard?
	  //lock_guard<mutex> tmp(guard);
	  _associated_job = &job;
	  _late_rejection_func = reject;
	  _price = max(get_price(), _price_update_policy(has_associated_job(), price));
	}
	accept();
      }
    
  }
  bool has_associated_job(){ return _associated_job != nullptr; }
  void open_bid_window()
  {
    //lock_guard<mutex> tmp(guard);
    if (!_bid_window_open)
      {
	//cout << open_count++<<endl;
	_bid_window_open = true;
	{ //extract to func + lock guard?
	  //lock_guard<mutex> tmp(guard);
	  _associated_job = nullptr;
	  _late_rejection_func = _nop_rejection;
	}
      }
  }
  void close_bid_window()
  {
    //lock_guard<mutex> tmp(guard);
    if (_bid_window_open)
      {
	_bid_window_open = false;
	//lock guard?
	//lock_guard<mutex> tmp(guard);
	if (has_associated_job())
	  {
	    _associated_job->execute_step();
	    _associated_job = nullptr;
	  }
	_price = _price_update_policy(has_associated_job(), _price);
      }
  }
  bool get_bid_window_open(){return _bid_window_open;}
  void bid_window_loop_step()
  {
    if (get_bid_window_open())
      {
	if(has_associated_job())
	  {
	    close_bid_window();
	    //this_thread::sleep_for(10ms);
	    //open_bid_window();
	  }
      }
    else
      {
	open_bid_window();
      }
    
  }
  void start_bid_loop()
  {
    if (_bid_loop)
      return;
    
    _bid_loop = true;
    
    _bid_loop_thread = move(thread(_bid_loop_thread_func));/*(thread([&]()
      {
	while(_bid_loop)
	  {
	    using namespace std::chrono_literals;
	    bid_window_loop_step();
	    this_thread::sleep_for(100ms);
	  }
	close_bid_window();
	}));*/
    
  }
  void stop_bid_loop()
  {
    if (!_bid_loop)
      return;
    
    _bid_loop = false;
    //if(_bid_loop_thread )
      {
	if(_bid_loop_thread.joinable())
	  _bid_loop_thread.join();
	//delete _bid_loop_thread;
	//_bid_loop_thread = nullptr;
	close_bid_window();
      }
  }

  void __set_price(int new_price)
  {
    _price = new_price;
  }
  
  virtual ~provider()
  {
    if(_bid_loop_thread.joinable())
      _bid_loop_thread.join();
  }
  /*
  get_provider_state();
offer_bid();
enum class providerState {
idle,
protect,
free,
bid,
available
};
  */
private:
  resource _r;
  atomic<int> _price;
  atomic<bool> _bid_window_open;
  atomic<bool> _bid_loop;
  job* _associated_job = nullptr;
  static reject_responce _nop_rejection;
  static price_update_func default_price_update;
  reject_responce _late_rejection_func = _nop_rejection;
  price_update_func _price_update_policy;
  bid_loop_thread_type _bid_loop_thread_func;
  thread _bid_loop_thread;
  //int open_count = 0;
  mutex guard;
  /*
  const int minPrice = 0;
int currentPrice = 0, scheduledPrice =0;
job *currentProcess = nullptr, *scheduledProcess = nullptr;
int p = minPrice;
  */
  
};
provider::reject_responce provider::_nop_rejection =  [](provider::rejection_main_reason r){};
provider::price_update_func provider::default_price_update = [](bool b, int i){ return max(i + b?1:-1, 0);};


//representation of a client in the algorithm
class client {
public:
  client(job j):_job{j}{}
  void register_providers(vector<shared_ptr<provider>> p)
  {
    _providers = p;
  }
  const vector<shared_ptr<provider>>& get_providers()
  {
    return _providers;
  }
  vector<shared_ptr<provider>> get_capable_providers()
  {
    vector<shared_ptr<provider>> ret(_providers.size());
    auto it = copy_if(_providers.begin(),
		      _providers.end(),
		      ret.begin(),
		      [this](shared_ptr<provider> p)
		      {return p->capable(this->_job);});
    ret.resize(distance(ret.begin(),it));
    return ret;
  }
  vector<shared_ptr<provider>> get_sorted_capable_providers()
  {
    auto ret = get_capable_providers();
    sort(ret.begin(),ret.end(),[](auto a, auto b){return a->get_price() < b->get_price();});
    return ret;
  }
  
private:
  job _job;
  vector<shared_ptr<provider>> _providers;
};


//passed by directory to client, interface for client to send/recv msg from providers
class provider_container {
};
//creates a simulation object from xml description
class simulation_builder {
};
//a full run of the simulation
class simulation {
};
/***************
 *Template impl*
 **************/

/******
 *Impl*
 *****/

/******
 *Main*
 *****/
/*
  int main()
  {
  return 0;
  }
*/

