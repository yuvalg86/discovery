#include "code.cpp"

//class resource;
//class provider;

int main()
{
  resource r ;
  atomic<bool> accepted{false}, rejected{false}, job_executed{false};
  provider::price_update_func f = [](bool b, int i){return b?i*2:i+2;};
  provider p{r,f};
  job fitting_job = job(1, 1024, [&](){job_executed = true;});

  provider::accept_responce accept_func {[&](){accepted = true;}};
  provider::rejection_main_reason rejection_reason;
  provider::reject_responce reject_func {[&](provider::rejection_main_reason r){
      rejected = true;
      rejection_reason = r;}};
  p.open_bid_window();
  cout<<p.get_price()<<endl;
  p.bid(fitting_job, 10, accept_func, reject_func);
  cout<<p.get_price()<<endl;
  p.close_bid_window();
  cout<<p.get_price()<<endl;
  cout<<"no crash\n";

  return 0;
}
