#include "gtest/gtest.h"
#include "gmock/gmock.h"

#include "code.cpp"

#include <random>

class Unit : public ::testing::Test {
protected:
  int arbitrary_ncpu = 2;
  int arbitrary_mem = 2048;

};

TEST_F(Unit, testComponent){
  auto c = component(arbitrary_ncpu, arbitrary_mem);
  auto c_high_mem = component(arbitrary_ncpu, arbitrary_mem*2);
  auto c_high_ncpu = component(arbitrary_ncpu*2, arbitrary_mem);
  auto c_high_both = component(arbitrary_ncpu*2, arbitrary_mem*2);

  ASSERT_TRUE(c_high_both.greater_or_equal(c_high_ncpu));
  ASSERT_TRUE(c_high_both.greater_or_equal(c_high_mem));
  ASSERT_TRUE(c_high_both.greater_or_equal(c));

  ASSERT_TRUE(c_high_mem.greater_or_equal(c));
  ASSERT_TRUE(c_high_ncpu.greater_or_equal(c)); 

  ASSERT_FALSE(c_high_mem.greater_or_equal(c_high_ncpu));
  ASSERT_FALSE(c_high_ncpu.greater_or_equal(c_high_mem));
  ASSERT_FALSE(c.greater_or_equal(c_high_both));
  
  ASSERT_EQ(arbitrary_ncpu, c.getNcpu());
  ASSERT_EQ(arbitrary_mem, c.getMem());
}

TEST_F(Unit, CreateNonEmptyJob) {
  auto j = job(arbitrary_ncpu, arbitrary_mem);
  auto j2 = job(arbitrary_ncpu, arbitrary_mem);
  
  ASSERT_EQ(arbitrary_ncpu, j.getNcpu());
  ASSERT_EQ(arbitrary_mem, j.getMem());
  ASSERT_EQ(j2.get_id(), j.get_id() + 1);
}

TEST_F(Unit, CreateNonEmptyResource) {
  
  auto r = resource(arbitrary_ncpu, arbitrary_mem);

  ASSERT_EQ(arbitrary_ncpu, r.getNcpu());
  ASSERT_EQ(arbitrary_mem, r.getMem());
}

class ProviderUnitTests : public ::testing::Test {
protected:
  int arbitrary_ncpu = 2;
  int arbitrary_mem = 2048;
  resource _r;
  provider _p;
  job heavy_job1 = job(arbitrary_ncpu, arbitrary_mem + 1);
  job heavy_job2 = job(arbitrary_ncpu + 1, arbitrary_mem);
  atomic<bool> accepted{false}, rejected{false}, job_executed{false};
  job fitting_job = job(arbitrary_ncpu, arbitrary_mem, [&](){job_executed = true;});
  int random_price = 10;
  provider::accept_responce accept_func {[&](){accepted = true;}};
  provider::rejection_main_reason rejection_reason;
  provider::reject_responce reject_func {[&](provider::rejection_main_reason r){
      rejected = true;
      rejection_reason = r;}};
    
  provider::price_update_func price_update_policy {
    [](bool associated, int current_price){
      return associated ? current_price * 2 : current_price + 2;
    }
  };
  function<void()> dummy {[](){}};//TODO: why does it segfault without it?
  ProviderUnitTests():_r{arbitrary_ncpu, arbitrary_mem},_p{_r, price_update_policy}
  {
    _p.open_bid_window();
  }
};

TEST_F(ProviderUnitTests, testCapability) {

  ASSERT_TRUE(_p.capable(fitting_job));
  ASSERT_FALSE(_p.capable(heavy_job1));
  ASSERT_FALSE(_p.capable(heavy_job2));

}

TEST_F(ProviderUnitTests, publishsPrice) {
  ASSERT_EQ(_p.get_price(), 0);
}

TEST_F(ProviderUnitTests, rejectsBidWhenNotCapable) {
  _p.bid(heavy_job1, random_price, accept_func, reject_func);
  ASSERT_TRUE(rejected);
  ASSERT_EQ(rejection_reason, provider::rejection_main_reason::not_capable);
}

TEST_F(ProviderUnitTests, rejectsBidBeforeFirstOpen) {
  provider p{_r, price_update_policy};
  p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_EQ(rejection_reason, provider::rejection_main_reason::bid_window_closed);
}

TEST_F(ProviderUnitTests, acceptsFirstBid) {
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_TRUE(accepted);  
}

TEST_F(ProviderUnitTests, get_pricePromisesAcceptance) {
  _p.bid(fitting_job, _p.get_price(), accept_func, reject_func);
  ASSERT_TRUE(accepted);  
}
TEST_F(ProviderUnitTests, updatesPrice) {
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_EQ(_p.get_price(), price_update_policy(true,random_price));
}

TEST_F(ProviderUnitTests, tracksAssociatedJob) {
  ASSERT_FALSE(_p.has_associated_job());
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_TRUE(_p.has_associated_job());
}

TEST_F(ProviderUnitTests, rejectsBidWithLowPrice) {
  _p.bid(fitting_job, _p.get_price(), accept_func, reject_func);
  ASSERT_TRUE(accepted);
  ASSERT_FALSE(rejected);
  _p.bid(fitting_job, _p.get_price() - 1, accept_func, reject_func);
  ASSERT_TRUE(rejected);
  ASSERT_EQ(rejection_reason, provider::rejection_main_reason::low_price);
}

TEST_F(ProviderUnitTests, rejectsWhenOutbidded) {
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_TRUE(accepted);
  ASSERT_FALSE(rejected);
  accepted = false;
  _p.bid(fitting_job, _p.get_price(), accept_func, [](provider::rejection_main_reason r){});
  ASSERT_TRUE(accepted);
  ASSERT_TRUE(rejected);
  ASSERT_EQ(rejection_reason, provider::rejection_main_reason::outbidded);
}

TEST_F(ProviderUnitTests, closes_bid_window) {
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_TRUE(accepted);
  ASSERT_FALSE(rejected);
  accepted = false;
  rejected = false;
  _p.close_bid_window();
  _p.bid(fitting_job, random_price + 1, accept_func, reject_func);
  ASSERT_FALSE(accepted);
  ASSERT_TRUE(rejected);
  ASSERT_EQ(rejection_reason, provider::rejection_main_reason::bid_window_closed);
}

TEST_F(ProviderUnitTests, report_bid_window_state) {
  ASSERT_TRUE(_p.get_bid_window_open());
  _p.close_bid_window();
  ASSERT_FALSE(_p.get_bid_window_open());
}

TEST_F(ProviderUnitTests, execute_job_after_bid_window_closes) {
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_TRUE(accepted);
  ASSERT_FALSE(rejected);

  _p.close_bid_window();

  ASSERT_TRUE(job_executed);
}

TEST_F(ProviderUnitTests, clear_associated_job_after_bid_window_openes) {
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_TRUE(accepted);
  ASSERT_FALSE(rejected);
  ASSERT_TRUE(_p.has_associated_job());
  _p.close_bid_window();
  ASSERT_TRUE(job_executed);
  _p.open_bid_window();
  ASSERT_FALSE(_p.has_associated_job());
}

TEST_F(ProviderUnitTests, update_price_on_window_close_after_associated) {
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  int previous_price = _p.get_price();
  _p.close_bid_window();
  ASSERT_EQ(_p.get_price(), price_update_policy(_p.has_associated_job(), previous_price));
}


TEST_F(ProviderUnitTests, update_price_on_window_open_after_not_associated) {
  int previous_price = _p.get_price();
  _p.close_bid_window();
  ASSERT_EQ(_p.get_price(), price_update_policy(_p.has_associated_job(), previous_price));
}

class ProviderIntegrationTests : public ProviderUnitTests {
protected:
  provider _p;//hides
  provider _slow;
  provider::price_update_func slow_price_update {
    [](bool associated, int current_price){
      return associated ? current_price + 2 : current_price + 1;
    }
  };
    ProviderIntegrationTests():ProviderUnitTests(),
			       _p{_r, price_update_policy},
			       _slow{_r, slow_price_update}
  {
    //ProviderUnitTests::_p.close_bid_window();
  }
  
};

TEST_F(ProviderIntegrationTests, testBidWindowLoopStep1Open) {
  ASSERT_FALSE(_p.get_bid_window_open());
  _p.bid_window_loop_step();
  ASSERT_TRUE(_p.get_bid_window_open());
}

TEST_F(ProviderIntegrationTests, testBidWindowLoopStep2KeepOpenIfNoBids) {
  ASSERT_FALSE(_p.get_bid_window_open());
  for (int i = 0; i < 10; i++)
    {
      _p.bid_window_loop_step();
      ASSERT_TRUE(_p.get_bid_window_open());
    }
}

TEST_F(ProviderIntegrationTests, testBidWindowLoopStep2KeepOpenIfNoAssocBid) {
  ASSERT_FALSE(_p.get_bid_window_open());
  _p.bid_window_loop_step();
  ASSERT_TRUE(_p.get_bid_window_open());
   for (int i = 0; i < 10; i++)
     {
       _p.bid(heavy_job1, random_price, accept_func, reject_func);
       ASSERT_TRUE(rejected);
       ASSERT_EQ(rejection_reason, provider::rejection_main_reason::not_capable);  
       _p.bid_window_loop_step();
       ASSERT_TRUE(_p.get_bid_window_open());
     }
}

TEST_F(ProviderIntegrationTests, testBidWindowLoopStep3CloseIfHasAssociatedBid) {
  ASSERT_FALSE(_p.get_bid_window_open());
  _p.bid_window_loop_step();
  ASSERT_TRUE(_p.get_bid_window_open());
  _p.bid(fitting_job, random_price, accept_func, reject_func);
  ASSERT_TRUE(accepted);  
  _p.bid_window_loop_step();
  ASSERT_FALSE(_p.get_bid_window_open());
}


TEST_F(ProviderIntegrationTests, testBidWindowLoopStep4ReopensAfterAssociation) {
   for (int i = 0; i < 10; i++)
     {
       
       ASSERT_FALSE(_p.get_bid_window_open());
       _p.bid_window_loop_step();
       ASSERT_TRUE(_p.get_bid_window_open());
       accepted = false;
       _p.bid(fitting_job, _p.get_price() + 1, accept_func, reject_func);
       ASSERT_TRUE(accepted);
       _p.bid_window_loop_step();
     }
}

TEST_F(ProviderIntegrationTests, testBidWindowLoop)
{
  _p.start_bid_loop();
  //_slow.start_bid_loop();
  while(!_p.get_bid_window_open())
    {
      _p.bid(fitting_job, _p.get_price(), accept_func, reject_func);
      ASSERT_EQ(rejection_reason, provider::rejection_main_reason::bid_window_closed);
    }
  provider::rejection_main_reason local_rejection_reason;

  while(_p.get_bid_window_open())
    {
      auto tmp = _p.get_price();
      
      accepted = false;
      _p.bid(fitting_job, _p.get_price(), accept_func, reject_func);
      if(tmp < _p.get_price() &&
	 _p.get_bid_window_open())
	{
	  ASSERT_TRUE(accepted);
	}
     
      rejected = false;
      local_rejection_reason = provider::rejection_main_reason::not_capable;
      _p.bid(fitting_job, _p.get_price() - 1,[&](){}, [&](provider::rejection_main_reason r)
	     {
	       local_rejection_reason = r;
	       rejected = true;
	     });
      ASSERT_TRUE(rejected);
      if(_p.get_bid_window_open())
	{
	  ASSERT_EQ(local_rejection_reason, provider::rejection_main_reason::low_price);
	}
    }
  _p.stop_bid_loop();
  //_slow.stop_bid_loop();
  ASSERT_FALSE(_p.get_bid_window_open());
  
}

TEST_F(ProviderIntegrationTests, testBidderOnOtherThread)
{
  _p.start_bid_loop();

  auto f ([&]()
	  {
	    _p.bid(fitting_job, random_price, accept_func, reject_func);
	  });
  
  while(!_p.get_bid_window_open()){}
  thread t(f);
  t.join();

  ASSERT_TRUE(accepted);  
  _p.stop_bid_loop();
}

TEST_F(ProviderIntegrationTests, testBiddersOnOtherThreads)
{
  int thread_count = 20;
  atomic<int> flag;
  flag = 0;
  vector<int> rejected_threads;
  rejected_threads.reserve(thread_count);
  job fitting_job = job(arbitrary_ncpu, arbitrary_mem, [&flag](){
      flag++;
    }); //hides
  auto accept_func([](){}); //hides

  auto f ([&](int index)
	  {
	    auto reject_func([&rejected_threads,index](provider::rejection_main_reason r)
			     {
			       rejected_threads.push_back(index);
			     }); //hides
	    _p.bid(fitting_job, _p.get_price(), accept_func, reject_func);
	    
	  });
   
  vector<thread> threadvec;
  
  _p.start_bid_loop();
  while(!_p.get_bid_window_open()){}
  for (int i = 0; i < thread_count; i++)
    threadvec.push_back(thread (f,i));
  
  for (auto& t : threadvec)
    t.join();

  while(!flag){}
  int done_flag = flag;
  ASSERT_EQ(done_flag,1);
  ASSERT_EQ(rejected_threads.size(), thread_count - 1);
  _p.stop_bid_loop();
}

TEST_F(ProviderIntegrationTests, testRepeatingBiddersOnOtherThreads)
{
  int thread_count = 20;
  int bid_count = 550;
  atomic<int> flag;
  flag = 0;
  vector<int> rejected_threads;
  rejected_threads.reserve(thread_count * bid_count);
  job fitting_job = job(arbitrary_ncpu, arbitrary_mem, [&flag](){
      flag++;
    }); //hides
  auto accept_func([](){}); //hides

  auto f ([&](int index)
	  {
	    auto reject_func([&rejected_threads,index](provider::rejection_main_reason r)
			     {
			       rejected_threads.push_back(index);
			     }); //hides
	    for (int i = 0; i < bid_count; i++)
	      _slow.bid(fitting_job, _slow.get_price(), accept_func, reject_func);
	    
	  });
   
  vector<thread> threadvec;
  
  _slow.start_bid_loop();
  while(!_slow.get_bid_window_open()){}
  for (int i = 0; i < thread_count; i++)
    threadvec.push_back(thread (f,i));
  
  for (auto& t : threadvec)
    t.join();

  while(!flag){}
  //while(rejected_threads.size() < thread_count*bid_count - 1){}
  _slow.stop_bid_loop();
  int done_flag = flag;
  ASSERT_EQ(done_flag,1);
  ASSERT_EQ(rejected_threads.size(), thread_count * bid_count - 1);
}

TEST(clientUnit, ctor){
  int arbitrary_ncpu = 2;
  int arbitrary_mem = 2048;
  job _job{arbitrary_ncpu, arbitrary_mem};
  client _c1{_job};
}

class clientFixture : public ::testing::Test {
protected:
  int arbitrary_ncpu = 2;
  int arbitrary_mem = 2048;
  constexpr static int providers = 10;
  job _job1{arbitrary_ncpu, arbitrary_mem};
  job _job2{arbitrary_ncpu * 5, arbitrary_mem * 5};

  vector<shared_ptr<provider>> _p;
  
  client _c1{_job1};
  client _c2{_job2};
  
  provider::price_update_func slow_price_update {
    [](bool associated, int current_price){
      return associated ? current_price + 2 : max(current_price - 1,0);
    }
  };
  clientFixture()
  {
    for(int i = 1; i<=providers; i++)
      _p.push_back(make_shared<provider>(resource{arbitrary_ncpu * i, arbitrary_mem * i},
					 slow_price_update));
  }
};

TEST_F(clientFixture, tellClientAboutProviders){
  _c1.register_providers(_p);
  auto ret = _c1.get_providers();

  ASSERT_EQ(_p.size(), ret.size());
  for (unsigned int i=0; i<_p.size(); i++)
    ASSERT_EQ(_p[i], ret[i]);
}

TEST_F(clientFixture, clientFiltersUncapableProviders){
  _c1.register_providers(_p);
  _c2.register_providers(_p);
  
  auto ret1 = _c1.get_capable_providers();
  ASSERT_EQ(ret1.size(),_p.size());
  for (auto &p : ret1)
    ASSERT_TRUE(p->capable(_job1));
  
  auto ret2 = _c2.get_capable_providers();
  ASSERT_EQ(ret2.size(),6);
  for (auto &p : ret2)
    {
      if (find(_p.begin(),_p.end(),p) != _p.end())
	ASSERT_TRUE(p->capable(_job2));
      else
	ASSERT_FALSE(p->capable(_job2));
    }
}

TEST_F(clientFixture, clientSortsCapableProvidersByPrice){
  _c2.register_providers(_p);
  std::random_device rd;  //Will be used to obtain a seed for the random number engine
  std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
  std::uniform_int_distribution<> dis(1, 100);
  for (auto& p : _p)
    p->__set_price(dis(gen));
  auto ret = _c2.get_sorted_capable_providers();
  ASSERT_EQ(ret.size(),6);
  ASSERT_TRUE(is_sorted(ret.begin(),ret.end(),
			[](auto a, auto b){return a->get_price() < b->get_price(); }));
}

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

/*
testlist:

provider updates price on window open

*/
