#!/usr/bin/python

import random

random.seed()
random.jumpahead(10)

#gen providers
#	gen resources
#gen clients
#	gen jobs

sim = """<sim quantum='{quantum}' delta='{delta}' noise='{noise}' migration='{migration_cost}' bid_window='{bid_window}'>
	<providers>
{providers}	</providers>

	<clients>
{clients}	</clients>
</sim>
"""
client = """		<client agent='{agent}' name='{name}'>
{jobs}		</client>\n"""
job = """			<job value='{value}' ncpu='{ncpu}' mem='{mem}' arrival='{arrival}' remaining='{remaining}' budget='{budget}' succrate='{succrate}'/>\n"""
prov = """		<provider state='on' market_status='free' agent='{agent}' name='{name}' incparam='{incparam}' decparam='{decparam}'>
{reso}		</provider>\n"""
reso = """			<resource ncpu='{ncpu}' mem='{mem}'/>\n"""

ncpu_range=(1,10)
mem_range=(512,2048)
value_range=(1,45)
arrival_range=(5,10)
remaining_range=(20,30,5)
budget_range=(10000,100000)
incparam_range=(1,1)
decparam_range=(1,1)
succrate_range=(100,100)
workloads = 6
workload_seperator = 3000
arrivaltmp = 1

def genprov(prov,reso):
	agents=['NONE','NO_INC']
	agents=['NO_INC']
	#agents=['NONE']
	tmpret=""
	for i in range(10):
		tmpres=""
		for j in range(1):
			tmpres = tmpres + reso.format(ncpu=random.randint(ncpu_range[0]+10,ncpu_range[1]+10),mem=random.randint(mem_range[0]+2048,mem_range[1]+2048))
		tmpret = tmpret + prov.format(name='p'+str(i),agent=random.choice(agents),incparam=random.randint(incparam_range[0],incparam_range[1]),decparam=random.randint(decparam_range[0],decparam_range[1]),reso=tmpres) 
	return tmpret

def genclient(client,job):
	agents=['NONE','OBLIV','AVOID_MIGRATION']
	agents=['AVOID_MIGRATION']
	#agents=['OBLIV']
	tmpret=""
	for i in range(30):
		arr = 1
		tmpjob=""
		for j in range(50):
                        tmp_wrkload = workload_seperator * random.randint(0, workloads)
			arr = arr + random.randint(arrival_range[0],arrival_range[1])
			tmpjob = tmpjob + job.format(ncpu=random.randint(ncpu_range[0],ncpu_range[1]),
						     mem=random.randint(mem_range[0],mem_range[1]),
						     value=random.randint(value_range[0],value_range[1]),
						     arrival=arr + tmp_wrkload,
						     remaining=random.randrange(remaining_range[0],remaining_range[1],remaining_range[2]),
						     budget=random.randint(budget_range[0],budget_range[1]), succrate=random.randint(succrate_range[0],succrate_range[1]))
		tmpret = tmpret + client.format(name='c'+str(i),agent=random.choice(agents),jobs=tmpjob)
	return tmpret

res = ""

res = sim.format(quantum='5', delta='5', noise='10', migration_cost='1', bid_window='15', providers=genprov(prov, reso), clients=genclient(client, job))
print res
