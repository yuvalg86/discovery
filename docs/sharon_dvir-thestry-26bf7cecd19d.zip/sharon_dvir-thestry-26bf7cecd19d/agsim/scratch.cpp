class trivial_pagent: public provider_agent {
	void update_next_price()
	{

	}
};



//	bool all_done()
		/*
		bool flag = true, del_job = false;
		for (int i = 0; i < jobs.size(); i++) {
			if (jobs[i]->state != job_state::done && jobs[i]->state != job_state::abort)
				flag = false;
			else
				del_job = true;
		}
		for (int i = 0; i < jobs.size() && del_job == true; i++) {
			if (jobs[i]->state == job_state::done || jobs[i]->state == job_state::abort) {
				delete(jobs[i]);
				jobs[i] = NULL;
				jobs.erase(jobs.begin() + i);
				i = 0;
			}
		}
		*/


class trivial_cagent: public client_agent {
	public:
	trivial_cagent()
	{
		int i;
		for (i = 0; i < providers.size(); i++)
			p.push_back(providers[i]);
	}
	int get_bid()
	{
		return 1;
	}
	virtual void bid_all();
};

class obliv_cagent: public client_agent {
	public:
	int threshold;

	obliv_cagent()
	{
		int i;
		for (i = 0; i < providers.size(); i++)
			p.push_back(providers[i]);
		threshold = operating_cost;
	}
	int get_bid()
	{
		return threshold;
	}
	virtual void bid_all();
};

void trivial_cagent::bid_all()
{
	for (int i = 0; i < c->jobs.size(); i++) {
		bool skip = false;
		class job *j = c->jobs[i];
		if (j->state != job_state::ready || j->arrival_time > ticks)
			continue;
		int feasible_flag = 0;
		int r = 0, min_p = 9999999;
		for (int p_index = 0; p_index < p.size(); p_index++) {
			if ( is_feasible(p[p_index], j->mem, j->ncpu ) == false )
				continue;
			//if some capable provider was found, set feasible_flag
			feasible_flag = 1;
			if (p[p_index]->agent->get_next_price() <= min_p) {
				min_p = p[p_index]->agent->get_next_price();
				r = p_index;
			}
		}
		if (feasible_flag == 0) {
			LOG << "no capable provider, job "<<c->jobs[i]->id;
			c->jobs[i]->state = job_state::abort;
			continue;
		}
		//next: don't bid over budget, inc/decr bids.
		//if it looks like prices are higher than remaining avg per cycle, wait for prices to drop.
		if (min_p > (((float)j->budget / j->remaining_time) * quantum)) {
			LOG << "waiting " << min_p << " remains: " << (((float)j->budget / j->remaining_time) * quantum)<<" job "<<c->jobs[i]->id;
			skip = true;
		}
		if (min_p > j->budget) {//don't bid over budget
			LOG << "can't bid over budget, job "<<c->jobs[i]->id;
			skip = true;
		}
		if ((((float)j->budget / j->remaining_time) * quantum) <= operating_cost) {//check if out of budget
			j->state = job_state::abort;
			LOG<<"out of budget, job "<<c->jobs[i]->id;
			skip = true;
		}
		if (skip == true)
			continue;
		LOG<<"bidding  "<<min_p<<" job "<<c->jobs[i]->id;//<<" min bid "<<p[r]->agent->get_price();
		bid(j, p[r], min_p);
		j->state = job_state::wait;
		j->budget -= min_p; //update remaining budget, value stays put.
	}
}

void obliv_cagent::bid_all()
{
	for (int i = 0; i < c->jobs.size(); i++) {
		bool skip = false;
		class job *j = c->jobs[i];
		if (j->state != job_state::ready || j->arrival_time > ticks)
			continue;
		int feasible_flag = 0;
		int r = 0, min_p = 9999999;
		for (int p_index = 0; p_index < p.size(); p_index++) {
			if ( is_feasible(p[p_index], j->mem, j->ncpu ) == false || p[p_index]->market_status != provider_market_status::bid)
				continue;
			//if some capable provider was found, set feasible_flag
			feasible_flag = 1;
			if (p[p_index]->agent->get_next_price() <= min_p) {
				min_p = p[p_index]->agent->get_next_price();
				r = p_index;
			}
		}
		if (feasible_flag == 0) {
			LOG << "no capable provider job, job "<<c->jobs[i]->id;
			c->jobs[i]->state = job_state::abort;
			continue;
		}
		//next: don't bid over budget, inc/decr bids.
		if (min_p > j->budget && min_p > 0) {//don't bid over budget
			LOG << "can't bid over budget, job "<<c->jobs[i]->id;
			skip = true;
		}
		if (operating_cost > j->budget) {//will never finish
			LOG << "can't bid below operating_cost, job "<<c->jobs[i]->id;
			c->jobs[i]->state = job_state::abort;
			skip = true;
		}
		if (skip == true)
			continue;

		//check if min_p < threshold to determine bidding/updating threshold
		if ( min_p > threshold ) {
			threshold++;
		} else {
			LOG<<"bidding  "<<min_p<<" job "<<c->jobs[i]->id;//<<" min bid "<<p[r]->agent->get_price();
			bid(j, p[r], min_p);
			j->state = job_state::wait;
			j->budget -= min_p; //update remaining budget, value stays put.
			threshold = min_p;
		}
	}
}

/*void avoid_migrate_cagent::bid_all()
{
	for (int i = 0; i < c->jobs.size(); i++) {
		bool skip = false;
		class job *j = c->jobs[i];
		int feasible_flag = 0;
		int r = 0, min_p = 9999999;
		int final_bid = 0;
		class provider *final_p;
		if (j->state != job_state::ready || j->arrival_time > ticks)
			continue;

		for (int p_index = 0; p_index < p.size(); p_index++) {
			if ( is_feasible(p[p_index], j->mem, j->ncpu ) == false )
				continue;
			//if some capable provider was found, set feasible_flag
			feasible_flag = 1;
			if (p[p_index]->agent->get_next_price() <= min_p) {
				min_p = p[p_index]->agent->get_next_price();
				r = p_index;
			}
		}
		if (feasible_flag == 0) {
			LOG << "no capable provider, job "<<c->jobs[i]->id;
			c->jobs[i]->state = job_state::abort;
			continue;
		}
		//next: don't bid over budget, inc/decr bids.
		if (min_p > j->budget && min_p > 0) {//don't bid over budget
			LOG << "can't bid over budget, job "<<c->jobs[i]->id;
			skip = true;
		}
		if (min_p > j->value) {//don't bid over value
			LOG << "won't bid over value, job "<<c->jobs[i]->id;
			skip = true;
		}
		/******leave out for now
		*if (operating_cost > j->budget) {//will never finish
		*	LOG << "can't bid below operating_cost "<<c->jobs[i]->id;
		*	c->jobs[i]->state = job_state::abort;
		*	skip = true;
		*}
		********
		if (skip == true)
			continue;

		final_bid = min_p;
		final_p = p[r];
		//if job associated with some provider already, get it's price and bid it if it's lower than min_p+migration_cost
		if (j->assoc_provider != NULL) {
			if (min_p + (migration_cost*(j->mem/1024.0)) >= j->assoc_provider->agent->get_next_price()) {
				final_bid = j->assoc_provider->agent->get_next_price();
				final_p = j->assoc_provider;
				LOG<<"avoiding migration, job "<<j->id;
			} else {
				j->assoc_provider = NULL;
				LOG<<"attempting migration, job "<<j->id;
			}
		}
		//check if min_p < threshold to determine bidding/updating threshold
		if ( min_p > threshold ) {
			threshold++;
		} else {
			LOG<<"bidding  "<<final_bid<<" job "<<j->id;//<<" min bid "<<p[r]->agent->get_price();
			bid(j, final_p, final_bid);
			j->state = job_state::wait;
			j->budget -= final_bid; //update remaining budget, value stays put.
			threshold = min_p;
		}
	}
}*/

//int avoid_migrate_cagent::update_offer(offer *o)//todo:finish

	/*
	LOG<<"DBG: update_offer() enter job "<<o->j->id;
	if (o->obsolete == false) {
	LOG<<"DBG: update_offer() o.obsolete == false job "<<o->j->id;
		return 0;
	}
	//delete(o);//TODO:debug test
	//o = NULL;
	//LOG<<"DBG: update_offer() leave";
	//return;

	//if (o == NULL) {
	//	LOG<<"DBG: update_offer() o==NULL";
	//	return;
	//}

	//if (o.j->market_status == job_market_status::protect) {
	//	return -1;
	//}
	string state = " init?";
	switch (o->state) {
	case offer_state::leading:
		state = " leading";
			LOG<<"DBG: update_offer() leading job "<<o->j->id;
		//o.j->market_status = job_market_status::ready;
		return 0;
		//bid(o->j, o->p, o->price);
		break;
	case offer_state::rejected:
		state = " rejected";
		LOG<<"DBG: update_offer() rejected job "<<o->j->id;
		o->j->market_status = job_market_status::ready;
		return -1;
		//o->price = o->next_price;//todo: check val, consider other providers
		//bid(o->j, o->p, o->price);
		break;
	case offer_state::scheduled:
		state = " scheduled";
		if (o->j->market_status != job_market_status::protect) {
			o->j->market_status = job_market_status::protect;
		}
		LOG<<"DBG: update_offer() scheduled job "<<o->j->id<<" provider "<<o->p->agent->name;
		return -1;
		break;
	case offer_state::init:
		state = " init";
		if (o->p->market_status != provider_market_status::bid) {
			LOG<<"DBG: update_offer() offer in init state, provider not in bid job "<<o->j->id;
			return -1;
		}
		//LOG<<"DBG: update_offer() offer in init state";
		LOG<<"DBG: update_offer() init job "<<o->j->id;
		return 0;
		break;
	};
	LOG<<"update_offer job "<<o->j->id<<state<<" provider "<<o->p->agent->name<<" job "<<o->j->id;
	if (o->obsolete == true) {
		LOG<<"DBG: update_offer() obsolete";
		//o.j->market_status = job_market_status::ready;
		//delete(o);
		//o = NULL;
		return -1;
	}
	*/

//bidding loop
/*void bid_loop()
{
	while (clients.size() > 0) {
	for (int i = 0; i < clients.size(); i++) {
			ticks_mtx.lock();
			ticks++;
			ticks_mtx.unlock();
			clients[i]->agent->bid_all();
			this_thread::sleep_for(chrono::milliseconds(10));
	}
	while (some_provider_still_accepts_bids(providers)) {
	for (int i = 0; i<providers.size(); i++) {
			providers[i]->agent->schedule_bids();
			this_thread::sleep_for(chrono::milliseconds(10));
			providers[i]->agent->curr_price = providers[i]->agent->next_price;
			//providers[i]->agent->offers.clear();
	}

	for (int i = 0; i < clients.size(); i++) {
			ticks_mtx.lock();
			ticks++;
			ticks_mtx.unlock();
			clients[i]->agent->bid_callback();
			//clients[i]->agent->offers.clear();
			this_thread::sleep_for(chrono::milliseconds(10));
	}
	}
	for (int i = 0; i < clients.size(); i++) {
		if (clients[i]->all_done()) {
			SIM_LOG<<"delete client "<<clients[i]->agent->name;
			for (int j = 0; j < clients[i]->agent->offers.size(); j++)
				delete(clients[i]->agent->offers[j]);
			delete(clients[i]->agent);
			delete(clients[i]);
			clients.erase(clients.begin() + i);
			i = 0;
		}
	}
	}
}*/

/*select highest feasible bid, don't try to increase price */
/*void no_inc_pagent::schedule_bids()
	{
		int mp = -9999, mi = -9999;
		mp = -9999; //curr_price;
		next_price = max(curr_price, 0);
		noise();
		//if (offers.size() == 0)
		//	return;

		for(int i = 0; i < offers.size(); i++) {
			if (offers[i] == NULL)
				continue;
			LOG<<"offered: "<<offers[i]->price<<" for job "<<offers[i]->j->id;
			if (offers[i]->price >= mp) {
				int flag = 0;
				for (int j = 0; j < p->resources.size(); j++)
					if (offers[i]->j->ncpu <= p->resources[j]->ncpu)
						flag = 1;
				if (flag == 1) {
					mp = offers[i]->price;
					mi = i;
				}
			}
		}
		for(int i = 0; i < offers.size(); i++) {
			if (offers[i] == NULL)
				continue;
			offers[i]->state = offer_state::rejected;
			if (i == mi) {
				offers[i]->state = offer_state::scheduled;
				LOG<<"scheduled: "<<offers[i]->price<<" for job "<<offers[i]->j->id;
				next_price = max(offers[i]->price, next_price);
			}
		}
		if (offers.size() == 0) {
			LOG<<"no offers";
			next_price = max(next_price - 1, 0);
			//return;
		}
		LOG << "next, curr: "<<next_price<<", "<<curr_price;
		//LOG << "mi, mp: "<<mi<<", "<<mp;
		if (mi < 0 || mp < 0)
			return;
		if (offers[mi]->p == NULL)
			LOG<<"null provider bug";
		if (offers[mi]->ca->c == NULL)
			LOG<<"null client bug";
		if (offers[mi]->j == NULL)
			LOG<<"null job bug";
		ticks_mtx.lock();
		ticks++;
		ticks_mtx.unlock();

		if (offers[mi] != NULL) {
			pq_mtx.lock();
			event e1 = event(offers[mi]->ca->c, offers[mi]->p, offers[mi]->j, ticks, event_type::load, 0, ticks + quantum, quantum);
			pq.push(e1);
			pq_mtx.unlock();
		} else {
			LOG<<"mem freed too early job "<<mi;
		}
		//for (int i = 0; i < offers.size(); i++)
		//	delete(offers[i]);
		offers.clear();
	}*/	

/*select highest feasible bid,  notify the sender of scheduling, notify the other bidders of rejection, clear offers */
void provider_agent::schedule_bids()
	{
		int mp = -1, mi = -1;
		mp = -1; //curr_price;
		next_price = max(curr_price - 1, operating_cost);
		noise();
		//if (offers.size() == 0)
		//	return;

		for(int i = 0; i < offers.size(); i++) {
			if (offers[i] == NULL)
				continue;
			LOG<<"offered: "<<offers[i]->price<<" for job "<<offers[i]->j->id;
			if (offers[i]->price >= mp) {
				int flag = 0;
				for (int j = 0; j < p->resources.size(); j++)
					if (offers[i]->j->ncpu <= p->resources[j]->ncpu)
						flag = 1;
				if (flag == 1) {
					mp = offers[i]->price;
					mi = i;
				}
			}
		}
		for(int i = 0; i < offers.size(); i++) {
			if (offers[i] == NULL)
				continue;
			offers[i]->state = offer_state::rejected;
			if (i == mi) {
				offers[i]->state = offer_state::scheduled;
				LOG<<"scheduled: "<<offers[i]->price<<" for job "<<offers[i]->j->id;
				next_price = curr_price + 1;
			}
		}
		if (offers.size() == 0) {
			LOG<<"no offers";
			//return;
		}
		LOG << "next, curr: "<<next_price<<", "<<curr_price;
		if (mi < 0 || mp < 0)
			return;
		if (offers[mi]->p == NULL)
			LOG<<"null provider bug";
		if (offers[mi]->ca->c == NULL)
			LOG<<"null client bug";
		if (offers[mi]->j == NULL)
			LOG<<"null job bug";
		ticks_mtx.lock();
		ticks++;
		ticks_mtx.unlock();

		if (offers[mi] != NULL) {
			pq_mtx.lock();
			event e1 = event(offers[mi]->ca->c, offers[mi]->p, offers[mi]->j, ticks, event_type::load, 0, ticks + quantum, quantum);
			pq.push(e1);
			pq_mtx.unlock();
		}
		//for (int i = 0; i < offers.size(); i++)
		//	delete(offers[i]);
		offers.clear();
	}
