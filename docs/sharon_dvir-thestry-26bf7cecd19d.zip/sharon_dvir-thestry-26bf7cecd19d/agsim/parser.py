#!/usr/bin/python
import sys
import matplotlib.pyplot as plt
import re
from numpy import median
import numpy as np
from scipy.interpolate import interp1d


#parse stdin in 2 ways:
#-by time
#-by entity and internally by time
entities = {}
jobs = {}

prog = re.compile(' \d+')

#assume stdin is sorted by time

def tokenize(l):
	#print l
	#sys.stdout.write(l)
	tmp = l.split(']')
	#print tmp	
	time = tmp[0].replace('[', '')
	entity = tmp[1].replace('[', '')
	msg = l.split(']')[-1].replace('\n', '')
	return time.replace(' ', ''), entity.replace(' ', ''), msg

def tokenize_job(l):
        #print l
	tmp = l.split(']')
	time = tmp[0].replace('[', '')
	msg = l.split(']')[-1].replace('\n', '')
	entity = re.findall(r' job \d+',msg)[0]
	#print entity, msg
	entity = re.findall(r'\d+', entity)[0]
	return time.replace(' ', ''), entity.replace(' ', ''), msg

evictions = 0
for line in sys.stdin:
	#print line
	if "DBG" in line:
		continue
	if "[evict]" in line and "job" in line and "done" in line:
		evictions = evictions + 1
		sys.stdout.write( "\rdone jobs count: %d" % evictions)
		sys.stdout.flush()
	t = tokenize(line)
	if t[1] not in entities:
		entities[t[1]] = []
	entities[t[1]].append((t[0],t[2]))
	if ' job ' in t[2]:
		jt = tokenize_job(line)
		#print jt[1]
		if jt[1] not in jobs:
			jobs[jt[1]] = []
		jobs[jt[1]].append((jt[0],jt[1],jt[2]))
		#print (jt[0],jt[1],jt[2])
print "\nProcessing...\n"


#for k in entities:
#	print k
#	print entities[k]

def price_c(c,n):
	tmpx = []
	tmpy = []
	for tup in c:
		if 'paying' in tup[1]:
			tmpx.append(tup[0])
			tmpy.append(tup[1].split(' ')[2])
	plt.title('Price over time for client '+n)
	plt.xlabel('Time')
	plt.ylabel('Price')
	plt.plot(tmpx,tmpy,'ro')
	plt.show()

def price_2c(c1,n1,c2,n2):
	tmpx = []
	tmpy = []
	for tup in c1:
		if 'paying' in tup[1]:
			tmpx.append(tup[0])
			tmpy.append(tup[1].split(' ')[2])
			#print tup[0], tup[1].split(' ')[2]
	tmpx2 = []
	tmpy2 = []
	for tup in c2:
		if 'paying' in tup[1]:
			tmpx2.append(tup[0])
			tmpy2.append(tup[1].split(' ')[2])
			#print tup[0], tup[1].split(' ')[2]
	plt.title('Price payed over time for clients '+n1+' (red) and '+n2+' (blue)')
	plt.xlabel('Time')
	plt.ylabel('Price')
	plt.plot(tmpx,tmpy,'ro',tmpx2,tmpy2,'bo')
	plt.show()

def price_2p(c1,n1,c2,n2):
	tmpx = []
	tmpy = []
	for tup in c1:
		if 'scheduled' in tup[1]:
			tmpx.append(tup[0])
			tmpy.append(tup[1].split(' ')[2])
	tmpx2 = []
	tmpy2 = []
	for tup in c2:
		if 'scheduled' in tup[1]:
			tmpx2.append(tup[0])
			tmpy2.append(tup[1].split(' ')[2])
	plt.title('Price over time for providers '+n1+' (red) and '+n2+' (blue)')
	plt.xlabel('Time')
	plt.ylabel('Price')
	plt.plot(tmpx,tmpy,'r-',tmpx2,tmpy2,'b-')
        print tmpx,tmpy
        print tmpx2,tmpy2
	plt.show()

def price_2p_groups(c1,n1,c2,n2):
	tmpx = []
	tmpy = []
	for tup in c1:
		if 'scheduled' in tup[1]:
			tmpx.append(tup[0])
			tmpy.append(tup[1].split(' ')[2])
			#print tup[0], tup[1].split(' ')[2]
	tmpx2 = []
	tmpy2 = []
	for tup in c2:
		if 'scheduled' in tup[1]:
			tmpx2.append(tup[0])
			tmpy2.append(tup[1].split(' ')[2])
			#print tup[1]
			#print tup[0], tup[1].split(' ')[2]
	plt.title('Price received over time for provider groups '+n1+' (red) and '+n2+' (blue)')
	plt.xlabel('Time')
	plt.ylabel('Price')
	plt.plot(tmpx,tmpy,'ro',tmpx2,tmpy2,'bo')
	plt.show()

def price_p(c):
	tmpx = []
	tmpy = []
	for tup in c:
		if 'scheduled' in tup[1]:
			tmpx.append(tup[0])
			tmpy.append(tup[1].split(' ')[2])
        plt.title('Price received over time for provider')
        plt.xlabel('Time')
        plt.ylabel('Price')
        plt.plot(tmpx,tmpy,'ro')
	plt.show()

def avg_similar_neigh(a):
        #a is a list of tuples.
        #return a similar list of tuples in which the first element is also unique
        #the second element is the average of elements with the same first element in a
        d = {}
        for t in a:
                if t[0] in d:
                        d[t[0]]=(d[t[0]][0]+t[1],d[t[0]][1]+1)
                else:
                        d[t[0]]=(t[1],1)
        #print d
        ret = []
        for k in d:
                ret.append((k,d[k][0]/d[k][1]))
        ret.sort(key=lambda tup: tup[0])
        return ret


def value_vs_slowdown(evict, job):
	#get jobs
	j={}#job_id:(value, arrival, duration)
	for i in job:
		#print i
		i2=i[1].split(" ")
		k=i2[3]
		#print i2
		v=(i2[5],i2[7],i2[9])
		j[k]=v
	#print j,'\n'
	#get done times
	t={}
	for i in evict:
		if 'done' in i[1]:
			i2=i[1].split(" ")
			t[i2[2]] = i[0]
	#print t
	tmpx = []
	tmpy = []
        tmpz = []
	for k in j:
		if k in t:
			#print j[k][0],t[k],j[k][1],j[k][2]
			tmpx.append(int(j[k][0]))#value
			tmpy.append((float(t[k])-float(j[k][1]))/float(j[k][2]))#(done_time - arrival)/job_remaining_time
                        #print float(t[k])-float(j[k][1]), float(j[k][2])
        #print tmpx,tmpy
        unify = []
        for i in range(0,len(tmpx)):
                unify.append((tmpx[i],tmpy[i]))
        unify.sort(key=lambda tup: tup[0])
        unify = avg_similar_neigh(unify)
        tmpy = []
        tmpx = []
        for i in range(0,len(unify)):
                tmpx.append(unify[i][0])
                tmpy.append(unify[i][1])
        print tmpx,tmpy
        f1 = interp1d(tmpx, tmpy, kind='cubic')
        xnew = np.linspace(tmpx[0], tmpx[-1], num=150, endpoint=True)
        plt.title('Job value VS job slowdown')
	plt.xlabel('Value')
	plt.ylabel('Slowdown')
	plt.plot(tmpx,tmpy,'g+')
        plt.plot(xnew,f1(xnew),'b-')
        plt.legend(['Data','Curve'], loc='best')
	plt.show()

def total_price_per_job(job):
	tmpx = []
	tmpy = []
	d = {}
	for k in job:
		#print job[k]
		d[k] = 0
		for kk in job[k]:
			if 'paying' in kk[2]:
				#print kk
				t = re.findall(r'paying [0-9]+ ', kk[2])
				t = int(re.findall(r'[0-9]+', t[0])[0])
				d[k] = d[k]+t
		#print k, d[k]
	for k in sorted(d):
		tmpx.append(int(k))
		tmpy.append(d[k])
	plt.title('Total price per job')
	plt.xlabel('Job id')
	plt.ylabel('Total price')
	plt.plot(tmpx,tmpy,'ro')
	plt.show()

def avg_price_per_job( job):
	tmpx = []
	tmpy = []
	d = {}
	for k in job:
		#print job[k]
		d[k] = (0.0,0.0)
		for kk in job[k]:
			if 'paying' in kk[2]:
				#print kk
				t = re.findall(r'paying [0-9]+ ', kk[2])
				t = int(re.findall(r'[0-9]+', t[0])[0])
				d[k] = (d[k][0]+float(t),d[k][1]+1.0)
		#print k, d[k]
	for k in sorted(d):
		tmpx.append(int(k))
		tmpy.append(d[k][0]/d[k][1])
	plt.title('Avg price per job')
	plt.xlabel('Job id')
	plt.ylabel('Avg price')
	plt.plot(tmpx,tmpy,'ro')
	plt.show()

def migrations_per_job( job):
	tmpx = []
	tmpy = []
	d = {}
	for k in job:
		#print job[k]
		d[k] = 0
		for kk in job[k]:
			if 'attempting migration' in kk[2]:
				#print kk
				#t = re.findall(r'paying [0-9]+ ', kk[2])
				#t = int(re.findall(r'[0-9]+', t[0])[0])
				d[k] = d[k]+1
		#print k, d[k]
	for k in sorted(d):
		tmpx.append(int(k))
		tmpy.append(d[k])
	plt.title('Total migration attempts per job')
	plt.xlabel('Job id')
	plt.ylabel('Total migrations')
	plt.plot(tmpx,tmpy,'ro')
	plt.show()

def migration_avoidances_per_job( job):
	tmpx = []
	tmpy = []
	d = {}
	for k in job:
		#print job[k]
		d[k] = 0
		for kk in job[k]:
			if 'avoiding migration' in kk[2]:
				#print kk
				#t = re.findall(r'paying [0-9]+ ', kk[2])
				#t = int(re.findall(r'[0-9]+', t[0])[0])
				d[k] = d[k]+1
		#print k, d[k]
	for k in sorted(d):
		tmpx.append(int(k))
		tmpy.append(d[k])
	plt.title('Total migration avoidances per job')
	plt.xlabel('Job id')
	plt.ylabel('Total migration avoidances')
	plt.plot(tmpx,tmpy,'ro')
	plt.show()

def value_range_vs_slowdown(evict, job):
	#get jobs
	minv=999
	maxv=0
	j={}#job_id:(value, arrival)
	for i in job:
		#print i
		i2=i[1].split(" ")
		k=i2[3]
		#print i2
		v=(i2[5],i2[7],i2[9])# value arrival remaining
		j[k]=v
		if int(v[0])>maxv:
			maxv=int(v[0])
		if int(v[0])<minv:
			minv=int(v[0])
		#print k,j[k]
	#print j,'\n'
	#get done times
	t={}
	for i in evict:
		if 'done' in i[1]:
			i2=i[1].split(" ")
			t[i2[2]] = i[0]
	#print t
	tmpx = []
	tmpy = []
	tmpa = {}
	for i in range(minv,maxv+1):
		tmpa[i] = (0.0,0.0)

	#return
	for k in j:
		if k in t:
			#print k,j[k],t[k]
			#tmpx.append(int(j[k][0]))#value
			#tmpy.append(int(t[k])-int(j[k][1]))#done_time
			tmpk = int(j[k][0])
			#print tmpk,tmpa
			tmpa[tmpk] = (tmpa[tmpk][0]+(int(t[k])-int(j[k][1])-int(j[k][2])),tmpa[tmpk][1]+1.0)
	print tmpa
	
	for i in sorted(tmpa):
		if tmpa[i][1] != 0:
			tmpx.append(i)
			tmpy.append(tmpa[i][0]/tmpa[i][1])
	
	
	plt.title('Jobs value VS avg slowdown')
	plt.xlabel('Value')
	plt.ylabel('AVG Slowdown')
	plt.plot(tmpx,tmpy)
	plt.show()

def welfare_for_client(c):
	tmpx = []
	tmpy = []
	for tup in c:
		if 'paying' in tup[1]:
			tmpx.append(tup[0])
			splitted_line = tup[1].split(' ')
			#print splitted_line
			tmpy.append(int(splitted_line[6])-int(splitted_line[2]))
                        if int(splitted_line[6])-int(splitted_line[2]) < 0:
                                print splitted_line
	plt.title('Social welfare for client')
	plt.xlabel('time')
	plt.ylabel('value - price')
	plt.plot(tmpx,tmpy,'b-')
	plt.show()

def welfare_for_2_clients(c1,c2):
	tmpx = []
	tmpy = []
        tmpx2 = []
        tmpy2 = []
	for tup in c1:
		if 'paying' in tup[1]:
			tmpx.append(tup[0])
			splitted_line = tup[1].split(' ')
			#print splitted_line
			tmpy.append(int(splitted_line[6])-int(splitted_line[2]))
                        if int(splitted_line[6])-int(splitted_line[2]) < 0:
                                print splitted_line
	for tup in c2:
		if 'paying' in tup[1]:
			tmpx2.append(tup[0])
			splitted_line = tup[1].split(' ')
			#print splitted_line
			tmpy2.append(int(splitted_line[6])-int(splitted_line[2]))
                        if int(splitted_line[6])-int(splitted_line[2]) < 0:
                                print splitted_line
	plt.title('Social welfare for client')
	plt.xlabel('time')
	plt.ylabel('value - price')
	plt.plot(tmpx,tmpy,'b-',tmpx2,tmpy2,'r-')
	plt.show()

def util_for_2_providers(p1, p2):
	tmpx = []
	tmpy = []
        tmpx2 = []
        tmpy2 = []
	for tup in p1:
		if 'utilizing' in tup[1]:
			tmpx.append(tup[0])
			splitted_line = tup[1].split(' ')
			#print splitted_line
			tmpy.append(100*float(splitted_line[2])/float(splitted_line[4]))
        for tup in p2:
		if 'utilizing' in tup[1]:
			tmpx2.append(tup[0])
			splitted_line = tup[1].split(' ')
			#print splitted_line
			tmpy2.append(100*float(splitted_line[2])/float(splitted_line[4]))
        print tmpx,tmpy
        print tmpx2,tmpy2
        plt.title('CPU utilization for 2 providers')
	plt.xlabel('time')
	plt.ylabel('utilization precentage')
	plt.plot(tmpx,tmpy,'r-',tmpx2,tmpy2,'b-')
	plt.show()

def util_for_1_provider(p1):
	tmpx = []
	tmpy = []
        tmpx2 = []
        tmpy2 = []
	for tup in p1:
		if 'utilizing' in tup[1]:
			tmpx.append(tup[0])
			splitted_line = tup[1].split(' ')
                        if (100*float(splitted_line[2])/float(splitted_line[4]) > 100):
                                print "ERR", float(splitted_line[2]),float(splitted_line[4]),splitted_line
			tmpy.append(100*float(splitted_line[2])/float(splitted_line[4]))
                        #print "debug prints"
                        #print splitted_line
                        #print float(splitted_line[2]),float(splitted_line[4])
        print tmpx,tmpy
        plt.title('CPU utilization for a provider')
	plt.xlabel('time')
	plt.ylabel('utilization precentage')
	plt.plot(tmpx,tmpy,'b-')
	plt.show()


def succrate_vs_slowdown(evict, job):
	#get jobs
	j={}#job_id:(succrate, arrival, duration)
	for i in job:
		#print i
		i2=i[1].split(" ")
		k=i2[3]
		#print i2
		v=(i2[11],i2[7],i2[9])
                #print v
		j[k]=v
	#print j,'\n'
	#get done times
	t={}
	for i in evict:
		if 'done' in i[1]:
			i2=i[1].split(" ")
			t[i2[2]] = i[0]
	#print t
	tmpx = []
	tmpy = []
        tmpz = []
	for k in j:
		if k in t:
			#print j[k][0],t[k],j[k][1],j[k][2]
			tmpx.append(int(j[k][0]))#value
			tmpy.append((float(t[k])-float(j[k][1]))/float(j[k][2]))#(done_time - arrival)/job_remaining_time
                        #print float(t[k])-float(j[k][1]), float(j[k][2])
        #print tmpx,tmpy
        unify = []
        for i in range(0,len(tmpx)):
                unify.append((tmpx[i],tmpy[i]))
        unify.sort(key=lambda tup: tup[0])
        unify = avg_similar_neigh(unify)
        tmpy = []
        tmpx = []
        for i in range(0,len(unify)):
                tmpx.append(unify[i][0])
                tmpy.append(unify[i][1])
        print tmpx,tmpy
        plt.title('Job success rate VS job slowdown')
	plt.xlabel('Success rate')
	plt.ylabel('Slowdown')
	plt.plot(tmpx,tmpy,'b-')
	plt.show()


def avgmean_price(ent):
        prs = {}
        cls = {}
        avg = []
        mean = []
        tot1 = {}
        tot2 = {}
        
        for k in ent:
                if 'p' in k:
                        prs[k] = [n for n in ent[k] if 'next_price' in n[1]]
                if 'c' in k and k != "evict":
                        cls[k] = [n for n in ent[k] if 'paying' in n[1]]
        for k in prs:
                print k,prs[k][0],len(prs[k])
        for k in cls:
                #print k,cls[k][0],len(cls[k])
                for t in cls[k]:
                        bucket = 200
                        tmpindex = (int(t[0])/int(bucket))*bucket
                        tmpprice = int(t[1].split(" ")[2])
                        if tmpindex in tot2:
                                tot2[tmpindex][0]+=1
                                tot2[tmpindex][1]+=tmpprice
                                tot2[tmpindex][2].append(float(tmpprice))
                                #print tot2[tmpindex]
                        else:
                                tot2[tmpindex] = [1, tmpprice, [float(tmpprice)]]
        d2=[]
        for i in tot2:
                d2.append((i,float(tot2[i][1])/float(tot2[i][0]), median(tot2[i][2])))

        d2.sort(key=lambda tup: tup[0])
        tmpy = []
        tmpx = []
        tmpy2 = []
        for i in d2:
                tmpx.append(i[0])
                tmpy.append(i[1])
                tmpy2.append(i[2])
                #print i
        #print tmpx,tmpy
        f1 = interp1d(tmpx, tmpy, kind='cubic')
        xnew = np.linspace(tmpx[0], tmpx[-1], num=150, endpoint=True)
        plt.title('Average price over time')
	plt.xlabel('Average price')
	plt.ylabel('Time')
        #plt.plot(tmpx, tmpy2, 'r--')
        plt.plot(xnew, f1(xnew), 'g-')
	plt.plot(tmpx,tmpy,'b+')
        plt.legend(['Avg price curve','Avg price data points'], loc='best')
	plt.show()

        
#def slowdown_per_job(, job):

#def idle_time_per_provider():

#def idle_time_per_client():

#def bid_success_rate_per_client():


#price_c(entities['c1'],'c1')
#price_c(entities['c2'],'c2')
#price_c(entities['c3'])
#price_c(entities['c4'])

#price_p(entities['p1'])
#price_p(entities['p2'])

#price_2c(entities['c1'],'High mem & value',entities['c0'],'Low mem & value')

#lowmem = []
#lowmem.extend(entities['p0'])
#print lowmem
#lowmem.extend(entities['p1'])
#print lowmem
#lowmem.extend(entities['p2'])
#lowmem.extend(entities['p3'])
#lowmem.extend(entities['p4'])
#print "lowmem size ",len(lowmem)
#lowmem.extend(entities['p5'])
#lowmem.extend(entities['p6'])
#lowmem.extend(entities['p7'])
#print "lowmem size ",len(lowmem)
#lowmem.extend(entities['p8'])
#lowmem.extend(entities['p9'])
#print "lowmem size ",len(lowmem)

#highmem= entities['p10']
#highmem.extend(entities['p11'])
#highmem.extend(entities['p12'])
#highmem.extend(entities['p13'])
#print "highmem size ",len(highmem)
#highmem.extend(entities['p14'])
#highmem.extend(entities['p15'])
#highmem.extend(entities['p16'])
#highmem.extend(entities['p17'])
#highmem.extend(entities['p18'])
#highmem.extend(entities['p19'])
#price_2p_groups(lowmem,'Low_mem',highmem,'High_mem')
#price_2p(entities['p0'],'p0',entities['p2'],'p2')
#price_p(entities['p0'])
#price_p(entities['p1'])
#value_vs_slowdown(entities['evict'],entities['job'])
#total_price_per_job(jobs)
#avg_price_per_job(jobs)
#migrations_per_job(jobs)
#migration_avoidances_per_job( jobs)

#value_range_vs_slowdown(entities['evict'],entities['job'])

value_vs_slowdown(entities['evict'],entities['job'])

#welfare_for_client(entities['c0'])
#welfare_for_client(entities['c1'])
#welfare_for_client(entities['c3'])

#welfare_for_2_clients(entities['c0'], entities['c1'])
#succrate_vs_slowdown(entities['evict'],entities['job'])

#util_for_2_providers(entities['p0'],entities['p1'])
#util_for_1_provider(entities['p0'])
#util_for_1_provider(entities['p1'])

#avgmean_price(entities)
