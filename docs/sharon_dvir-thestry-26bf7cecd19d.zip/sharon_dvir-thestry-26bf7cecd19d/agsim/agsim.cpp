#include <map>
#include <vector>
#include <thread>
#include <iostream>
#include <mutex>
#include <queue>
#include <chrono>
#include <random>
#include <algorithm>
#include <string>
#include <functional>
#include "tinyxml2.h"

using namespace tinyxml2;
using namespace std;

int quantum = 5;
int delta = 5;
int noise_max = 1;
int operating_cost = 1;
int migration_cost = 1;
int bid_window = 15;

//global time
int ticks = 0;
//mutex for time
mutex ticks_mtx;
//mutex for printing
mutex log_mtx;


class logger
{
	public:
	logger(const string &name)
	{
		log_mtx.lock();
		cout << "[" << ticks << "] " << "[" << name << "] ";
	}

	template <class T>
	logger &operator<<(const T &v)
	{
		cout << v;
		return *this;
	}
	~logger()
	{
		cout << endl;
		log_mtx.unlock();
	}
};

#define LOG logger(this->name)
#define EVICT_LOG logger("evict")
#define LOAD_LOG logger("load")
#define BID_LOG logger("bid")
#define SIM_LOG logger("sim")
#define JOB_LOG logger("job")
#define DBG logger("DBG")

void noise()
{
	//return;
	auto r = bind(uniform_int_distribution<>{0,noise_max}, default_random_engine{});
	this_thread::sleep_for(chrono::milliseconds(r()));
}

enum class job_state {
	done,
	run,
	abort,
	suspend,
	wait,
	migration,
	ready,
	post_run
};

string jsp(job_state js)
{
	switch (js) {
	case (job_state::done):
		return "done";
	case (job_state::run):
		return "run";
	case (job_state::abort):
		return "abort";
	case (job_state::suspend):
		return "suspend";
	case (job_state::wait):
		return "wait";
	case (job_state::migration):
		return "migration";
	case (job_state::ready):
		return "ready";
	case (job_state::post_run):
		return "post_run";
	default:
	  return "ERROR";
	};
}

enum class job_market_status {
	bid,
	win,
	ready,
	protect,
	no_budget
};

string jmsp(job_market_status jms)
{
	switch (jms) {
	case (job_market_status::bid):
		return "bid";
	case (job_market_status::win):
		return "win";
	case (job_market_status::ready):
		return "ready";
	case (job_market_status::protect):
		return "protect";
	case (job_market_status::no_budget):
		return "no_budget";
	default:
	  return "ERROR";
	};
}

class provider;
class job {
	public:
	static int counter;
	int id;
	int value;
	int ncpu;
	int mem;
	int arrival_time;
	int remaining_time;
	int completion_time;
	int budget;
  int succrate_priority;
  float succrate_total;
  float succrate_win;
  job_state state;
	job_market_status market_status;
	class provider *assoc_provider = NULL;

  job(int _value, int _ncpu, int _mem, int _at, int _rt, int _b, int _sr):
	    value(_value), ncpu(_ncpu), mem(_mem), arrival_time(_at),
	    remaining_time(_rt), completion_time(-1), budget(_b), succrate_priority(_sr){
		id = counter++;
		state = job_state::ready;
		market_status = job_market_status::ready;
		succrate_total = 0.0;
		succrate_win = 0.0;
		JOB_LOG<<"creating job "<<id<<" value "<<value<<" arrival "<<arrival_time<<" remaining "<<remaining_time << " succrate " << succrate_priority;
	};
};
int job::counter = 0;

class cpu {
	public:
	int job;//job_id cpus work on, negative for vacant
	int price;

	cpu(int _j, int _p): job(_j), price(_p){};
}; 

class resource {
	public:
	int ncpu;
  vector<cpu> cpus;
	int mem;
	int free_mem;

  resource(int _ncpu, int _mem): ncpu(_ncpu), mem(_mem), cpus(ncpu, cpu(-1, 0)) {
    //for (int i = 0; i < ncpu; i++)
    //cpus.push_back(new cpu(-1, 0));
		//cpus
    free_mem = mem;
  };
};

class client_agent;

enum class offer_state {
	init,
	rejected,
	scheduled,
	leading,
	post_run,
	abandoned
};

string osp(offer_state os)
{
	switch (os) {
	case (offer_state::init):
		return "init";
	case (offer_state::rejected):
		return "rejected";
	case (offer_state::scheduled):
		return "scheduled";
	case (offer_state::leading):
		return "leading";
	case (offer_state::post_run):
		return "post_run";
	case (offer_state::abandoned):
	  return "abandoned";
	default:
	  return "ERROR";
	};
}


enum class provider_state {
	on,
	off,
	home
};

enum class provider_market_status {
	protect,
	available,
	free,
	bid
};

class provider_agent;

class provider {
	public:
	vector<resource *> resources;
	provider_agent *agent;
	provider_state state;
	provider_market_status market_status;
	int timeout;
	string name;
	int round_counter;
  //int incparam, decparam;
  
	bool check_timeout()
	{
		//SIM_LOG<<"check_timout() "<<ticks<<" "<<timeout;
		if (ticks >= timeout)
			return true;
		return false;
	}
	void update_timeout()
	{
		timeout = ticks + bid_window;
	}
  provider(vector<resource*> _r, provider_agent *_a):
	resources(_r), agent(_a), round_counter(0)
	{
		state = provider_state::on;
		market_status = provider_market_status::bid;
		//timeout = ticks + bid_window;
		update_timeout();
	}
	
};
vector<provider* > providers;

class offer {
	public:
	job *j;
	client_agent *ca;
	provider *p;
	int price;
	offer_state state;
	int next_price;
	bool obsolete;
	bool mark_for_deletion;
	int present_round;

  //offer(offer&) = delete;
  //offer& operator=(offer&) = delete;
  
offer(job *_j, client_agent *_ca, provider *_pr, int _p): j(_j), ca(_ca), price(_p), p(_pr), present_round(_pr->round_counter)
		,state{offer_state::init}, next_price{0}, obsolete{false}, mark_for_deletion{false}
	{
		/*state = offer_state::init;
		next_price = 0;
		obsolete = false;
		mark_for_deletion = false;*/
	};
	offer(){};
};

class offer;
//void client_agent::register_rejection(offer o);

class provider_agent {
	public:
	provider *p;
	int curr_price = 0, next_price = 0;
	//vector<offer *> offers;
	offer leading_offer;
	bool leading_valid = false;
	mutex leading_offer_mtx;

	int incparam = 0, decparam = 0;
	string name;

provider_agent(int inc, int dec):incparam{inc},decparam{dec}{}
	
	virtual int get_price()
	{
		return curr_price;
	}
	virtual int get_next_price()
	{
		return next_price;
	}
	virtual void reject_bid(offer * o);
	virtual void lead_bid(offer o);
	virtual void register_bid(offer  &o)
	{
		if (o.obsolete == true) {
			LOG<<"register_bid() obsolete";
			return;
		}
		o.obsolete = true;
		if (p->market_status != provider_market_status::bid) {
			LOG<<"register_bid() not in bid state";
			
			//o->state = offer_state::rejected;
			return;
			}
		leading_offer_mtx.lock();
		//check if offer o is better than leading_offer
		DBG<<"register_bid() o.price "<<o.price;
		if ((leading_valid == true &&  o.price > leading_offer.price) || leading_valid == false) {
			if (leading_valid == true) {
				reject_bid(&leading_offer);
			}
			leading_offer = o;
			leading_valid = true;
			leading_offer.state = offer_state::leading;
			lead_bid(o);
		} else {
			reject_bid(&o);
		}
		leading_offer_mtx.unlock();
	}
	/*select highest bid, notify the sender of scheduling, notify the other bidders of rejection, clear offers */
	virtual void schedule_bids();
	virtual void update_next_price(){};
	
	//provider agent needs to be aware of the provider's resources and utilization.
	virtual ~provider_agent(){}
};

class no_inc_pagent: public provider_agent {
public:
	//int incparam, decparam;

  no_inc_pagent(int inc, int dec) : provider_agent(inc, dec) {}
	//void update_next_price(){}
	//void schedule_bids();
};

class client;

class client_agent {
	public:
	client *c;
	vector<provider*> p;
	map<int, offer> offers;
	//vector<offer > offers, tmp_offers, del_offers;
	string name;

	client_agent(){
		int i;
		for (i = 0; i < providers.size(); i++)
			p.push_back(providers[i]);
		
	}
	//virtual ~client_agent();
	virtual ~client_agent(){}
	
	virtual void register_rejection(offer o){
		LOG<<"reigster_rejection 1 "<< osp(offers[o.j->id].state)<<" "<<osp(o.state);
		//offers[o.j->id] = o;
		offers[o.j->id].state == offer_state::abandoned;
		//offers.erase(o.j->id);
		LOG<<"reigster_rejection 2 "<< osp(offers[o.j->id].state);
	}
	virtual void register_leading(offer o) {
		LOG<<"reigster_leading 1 "<< osp(offers[o.j->id].state)<<" "<<osp(o.state);
		offers[o.j->id] = o;
		LOG<<"reigster_leading 2 "<< osp(offers[o.j->id].state);
	}
	virtual void register_post_run(int j) {
		
	}
  virtual int get_bid(){return -1;}
	//client agent needs to be aware of a client's jobs, and some providers to bid to.
	/*bid job j to provider p for price 'price', add offer to offers*/
	virtual void bid(job *j, provider *pr, int price)
	{
		
		//cout<<"SHARON: price: "<<price<<" job "<<j->id<<endl;
		//DBG<<"bid 1 "<<offers.size();
		offer o{j, this, pr, price};
		//DBG<<"bid 2 "<<offers.size()<<" bid price "<<offers.back().price;
		offers[j->id] = move(o);
		pr->agent->register_bid(offers[j->id]);
		//noise();
		//return o;
	}
	virtual void bid_all();
	/*collect notifications of rejection or scheduling
	iterate over offers, clear rejected.*/
	virtual void bid_callback()
	{
		for (int i = 0; i < offers.size(); i++) {
			if (offers[i].state == offer_state::rejected) {
				offers[i].j->state = job_state::ready;
				LOG<<"bid rejected "<<offers[i].price<<" job "<<offers[i].j->id;
			} else if (offers[i].state == offer_state::scheduled) {
				//LOG<<"paying "<<offers[i]->price<<" job "<<offers[i]->j->id;
			}
			//delete(offers[i]);
		}
		/*
		int flag = 0;
		while (flag == 0) {
		flag = -1;
		for (int i = 0; i < offers.size(); i++) {
			if (offers[i] != NULL && (offers[i].state == offer_state::rejected || offers[i].state == offer_state::scheduled)) {
				//delete(offers[i]);
				//offers[i] = NULL;
				//flag = flag;
				
			} else {
				flag = 0;
			}

		}
		}
		offers.clear();
		*/
		/*
		for (auto i : offers) {
			if (offers[i].state == offer_state::rejected || offers[i].state == offer_state::scheduled)
				
		}*/
		//noise();
	}
	virtual bool bidded_to_provider(provider *p);
	virtual void pay(offer *o)
	{
		LOG<<"paying "<<o->price<<" job "<<o->j->id << " value " << o->j->value;
		o->j->budget -= o->price;
		o->j->succrate_win++;
	}
	virtual vector<offer *> find_offer(job *j);
	virtual void first_offer(job *j);
	/*{
		cout<<"SHARON: SHOULD NOT GET HERE"<<endl;
		return ;
	}*/
	virtual int update_offer(offer &o);
	virtual void remove_offers();
};

void provider_agent::reject_bid(offer * o)
{
	o->state = offer_state::rejected;
	o->next_price = next_price;
	o->ca->register_rejection(*o);
}

void provider_agent::lead_bid(offer o)
{
	o.state = offer_state::leading;
	//o->next_price = next_price;
	o.ca->register_leading(o);
}

class avoid_migrate_cagent: public client_agent {
	public:
	int threshold;
	
avoid_migrate_cagent():client_agent(){
		threshold = operating_cost;
	}
	
	~avoid_migrate_cagent(){}
	
	int get_bid()
	{
		return threshold;
	}
	virtual void bid_all();	
	virtual void first_offer(job *j);
	//virtual int update_offer(offer &o);
	
};

class client {
	public:
	vector<job> jobs;
	client_agent *agent;

	client(vector<job> _j, client_agent *_a):
	       jobs(_j), agent(_a) {};

	bool all_done()
	{
		bool flag = true;
		for (int i = 0; i < jobs.size(); i++) {
			if (jobs[i].state != job_state::done && jobs[i].state != job_state::abort)
				flag = false;
			//cout<<"SHARON: job "<<jobs[i].id<<" state "<<jsp(jobs[i].state)<<endl; 
			//if (!(jobs[i].state == job_state::done || jobs[i].state == job_state::abort))
				//cout<<"SHARON: job "<<jobs[i].id<<" state "<<jsp(jobs[i].state)<<endl;
		}
		if (flag == true) {
			for (int i = 0; i < jobs.size(); i++) {
				//delete(jobs[i]);
				//jobs[i] = NULL;
			}
		jobs.clear();
		}

		return flag;
	}
};

vector<client*> clients;

bool is_feasible(provider *p, int mem, int ncpu)
{
	bool ret = false;
	for (int i = 0; i < p->resources.size(); i++) {
		if (p->resources[i]->mem >= mem && 
		    p->resources[i]->ncpu >= ncpu) {
			ret = true;
			break;
		}
	}
	return ret;
}


vector<offer *> client_agent::find_offer(job *j)
{
	vector<offer *> ret;
	//LOG<<"DBG find_offer() start ";//<<offers.size();
	//LOG<<"j valid? "<<j->id;
	LOG<<"DBG find_offer() start "<<offers.size();
	for (int i = 0; i < offers.size(); i++) {
		LOG<<"DBG find_offer() sanity job "<</*offers[i].j->id <<*/ " obsolete: "<<offers.size();
		if(/*offers[i] != NULL &&*/ offers[i].j != nullptr) {
			//LOG<<"DBG find_offer() first if ";
			
			if( offers[i].j->id == j->id) {
				//LOG<<"DBG find_offer() second if ";
				ret.push_back(&offers[i]);
			}
		}
	}
	//LOG<<"DBG find_offer() done ";
	return ret;
}

bool client_agent::bidded_to_provider(provider *p)
{
	//LOG << "offers size: "<<offers.size();
  for (auto i : offers) {
    if (i.second.p->agent->name == p->agent->name)
      return true;
  }
  return false;
}

void client_agent::first_offer(job *j)
{
	
	//LOG<<"DBG first_offer() called";
	bool skip = false;
	int feasible_flag = 0, some_capable = 0;
	int r = 0, r_max = 0, min_p = 9999999, max_p_under_val = -1;
	int final_bid = 0;
	class provider *final_p;
	offer *ret = NULL;

	/*quick skip for done jobs*/
	if (j->state == job_state::done ||
	    j->state == job_state::abort ||
	    j->state == job_state::post_run) {
		return ;
	}

	for (int p_index = 0; p_index < p.size(); p_index++) {
		if ( is_feasible(p[p_index], j->mem, j->ncpu ) == false || p[p_index]->market_status != provider_market_status::bid) {
			if (is_feasible(p[p_index], j->mem, j->ncpu ) == true) {
				some_capable = 1;
			}
			continue;
		}

		//if some capable provider was found, set feasible_flag
		feasible_flag = 1;
		
		//don't compete with other offers you made
		if (bidded_to_provider(p[p_index]) && false) {
		  //LOG<<"AVOID SELF COMPETITION";
		  continue;
		}
		if (p[p_index]->agent->get_next_price() <= min_p) {
			min_p = p[p_index]->agent->get_next_price();
			r = p_index;
		}
		if (p[p_index]->agent->get_next_price() > max_p_under_val &&
		    p[p_index]->agent->get_next_price() <= j->value) {
			max_p_under_val = p[p_index]->agent->get_next_price();
			r_max = p_index;
		}
	}
	if (feasible_flag == 0) {
		if (some_capable == 0) {
			LOG << "no capable provider, job "<<j->id;
			j->state = job_state::abort;
		}
		return ;
	}
	//next: don't bid over budget, inc/decr bids.
	if (min_p > j->budget && min_p > 0) {//don't bid over budget
		//LOG << "can't bid over budget, job "<<j->id;
		skip = true;
	}
	if (min_p > j->value) {//don't bid over value
		LOG << "won't bid over value, job "<<j->id<<" val: "<<j->value<<" min_p "<<min_p;
		skip = true;
	}
	if (skip == true) {
		//LOG<<"skip was true";
		return;
	}

	/*for selecting cheapest*/
	final_bid = min_p;
	final_p = p[r];
	int tmp_assoc_next_price = 0;
	/*for selecting higest feasible*/
	//final_bid = max_p_under_val;
	//final_p = p[r_max];

	//if job associated with some provider already, get it's price and bid it if it's lower than min_p+migration_cost no higher than job value
	if (j->assoc_provider != NULL /*&& false*/) {
		tmp_assoc_next_price = j->assoc_provider->agent->get_next_price();
		if (min_p + (migration_cost*(j->mem/1024.0)) >= tmp_assoc_next_price && tmp_assoc_next_price <= j->value) {
			final_bid = tmp_assoc_next_price;
			final_p = j->assoc_provider;
			//LOG<<"avoiding migration, job "<<j->id;
		} else {
			j->assoc_provider = NULL;
			//LOG<<"attempting migration, job "<<j->id;
		}
	}
	//check if min_p < threshold to determine bidding/updating threshold
	//if ( min_p > threshold /*&& false*/) {
		//threshold++;
	//} else {
		LOG<<"bidding  "<<final_bid<<" job "<<j->id;//<<" min bid "<<p[r]->agent->get_price();
		bid(j, final_p, final_bid);
		j->state = job_state::wait;
		j->budget -= final_bid; //update remaining budget, value stays put.
		j->succrate_total++;
		//threshold = min_p;
		//}
	//return ret;
}

int client_agent::update_offer(offer &o)//todo:finish
{
  //LOG<<"DBG update_offer() enter job "<<o->j->id<<" jmsp "<<jmsp(o->j->market_status)<<" osp "<<osp(o->state)<<" jsp "<<jsp(o->j->state)<<" price "<<o->price;
	if(o.obsolete == false)
		return 0;

	/* quick abandonment */
	if(o.j->state == job_state::post_run ||
	   o.state == offer_state::init) {
		o.state = offer_state::abandoned;
		return 0;
	}

	switch (o.j->state) {
	case job_state::post_run:
	case job_state::done:
		o.state = offer_state::abandoned;
		return 0;
		break;
	default:
		break;
	};

	int tmp_next_price = 0;
	float ratio = o.j->succrate_win / o.j->succrate_total;

	switch (o.state) {
	case offer_state::leading:
	case offer_state::scheduled:
		o.obsolete = true; /*let provider keep this one*/
		//o->j->succrate_win++;
		return 0;
		break;
	case offer_state::rejected:
		LOG<<"ratio "<<ratio<<" priority "<<o.j->succrate_priority/100.0;	  
		tmp_next_price = o.p->agent->get_next_price();
	  if (tmp_next_price <= o.j->value && ratio*100 < o.j->succrate_priority) {
		  LOG<<"ratio update rejected bid";
		  //o->price++;
		  o.price = tmp_next_price;
		  o.state = offer_state::init;
		  o.obsolete = false; /*mark as fresh*/
		  o.p->agent->register_bid(o);
		  //return 0;
	  } else {
		  LOG<<"ratio abandon rejected bid";
		  o.state = offer_state::abandoned;
	  }
	  break;
	default:
		break;
	};

	switch (o.j->market_status) {
	case job_market_status::ready:
	  //o->state = offer_state::abandoned;
		break;
	default:
		break;
	};
	/* retrigger bid */
	return 0;
}

void client_agent::remove_offers()
{
	/*offers.erase(remove_if(offers.begin(), offers.end(),
			       [](offer x){return ((x.state == offer_state::abandoned && x.present_round != x.p->round_counter) ||
						   (x.p->round_counter - x.present_round > 4));}));
	*/
  
	//DBG<<"del offer "<<offers.size();
	/*if (offers.size()>0)
		
		offers.erase(remove_if(offers.begin(), offers.end(),
				       [](offer x){return (x.obsolete == true &&
							   x.state == offer_state::abandoned &&
							   abs(x.present_round - x.p->round_counter) >
							   2);}));*/
/*
	int tmp = offers.size();
	//vector<offer *> tmp_keep, tmp_del;
	//LOG<<"DBG remove_offers() start";//<<offers.size();
	del_offers.clear();
	for (int i = 0; i < offers.size(); i++) {
	  //LOG<<"DBG remove_offers() job "<< offers[i]->j->id<<" obsolete: "<<offers[i]->obsolete;
	  //LOG<<"DBG remove_offers() job "<< offers[i]->j->id<<" offer_state: "<<osp(offers[i]->state);
		//if (offers[i]->state == offer_state::abandoned) {// ||
		if ((offers[i]->state == offer_state::abandoned && offers[i]->present_round != offers[i]->p->round_counter) ||
		    (offers[i]->p->round_counter - offers[i]->present_round > 4)) {
		    //offers[i]->state == offer_state::post_run) {
			//LOG<<"DBG remove_offers() removing job "<< offers[i]->j->id;
			//delete(offers[i]);
			//offers[i] = NULL;
			//offers.erase(offers.begin() + i);
			//i = 0;
			del_offers.push_back(offers[i]);
		} else {
			tmp_offers.push_back(offers[i]);
		}
	}
	offers = tmp_offers;
	tmp_offers.clear();
	for (int i = 0; i < del_offers.size(); i++) {
		//LOG<<"DBG remove_offers() del job "<<del_offers[i]->j->id<<" i "<<i<<" size "<<del_offers.size();
		delete(del_offers[i]);
	}
	//del_offers.erase(del_offers.begin() + del_offers.size());
	del_offers.clear();
	*/
}

void client_agent::bid_all()
{
	for (int i = 0; i < c->jobs.size(); i++) {
		class job &j = c->jobs[i];
		offer *tmpo = NULL;

		//skip jobs by state
		if (/*j->state == job_state::done ||*/
		    j.state == job_state::run ||
		    j.state == job_state::abort)
			continue;
		if (j.arrival_time > ticks)
			continue;
		//todo:clear dead offers here
		//remove_offers();
		//vector<offer *> oj = find_offer(&j);
		//for(int t = 0;t<oj.size();t++) {
			//LOG<<"DBG bid_all() find_offer() updating for job "<<j->id<<" "<<jsp(j->state);
		//	if (update_offer(*oj[t]) < 0) {
		//	}
		//} 
		//if (oj.size() == 0) {
		//	first_offer(&j);
			//LOG<<"DBG bid_ all() find_offer() nulled for job "<<j->id;
			/*if (tmpo !=NULL) {
				//LOG<<"DBG first_offer() for job "<<tmpo->j->id;
				//offers.push_back(tmpo);
				//LOG<<"DBG first_offer() pushed job "<<offers[offers.size()-1]->j->id;
			} else {
			//LOG<<"DBG bid_ all() find_offer() nulled for job "<<j->id;
			}*/
		//}
		if (offers.count(j.id) == 0)
			first_offer(&j);
		else {
			
			//update_offer(offers[j.id]);
			if (offers[j.id].state == offer_state::abandoned ||
			    offers[j.id].present_round < offers[j.id].p->round_counter) {
				//offers.erase(j.id);
				first_offer(&j);
				}
		}
		}
	//remove_offers();
	for (int i = 0; i < c->jobs.size(); i++) {
		class job &j = c->jobs[i];
		if (j.state == job_state::post_run) {
			j.state = job_state::ready;
			//offers.erase(j.id);
		}
		//if (offers[j.id].present_round <= offers[j.id].p->round_counter) {
		//	offers.erase(j.id);
		//}
	}
}

class ely_client:public client_agent {
public:
	virtual void bid_one(job *j) {
		vector<provider*> candidates;
		for (auto i : providers) {
			if (is_feasible(i, j->mem, j->ncpu ) &&
			    i->market_status == provider_market_status::bid &&
			    i->agent->get_next_price() <= j->value) {	
				candidates.push_back(i);
			}
		}
		if (candidates.size() == 0)
			return;

		sort(candidates.begin(),candidates.end(),
		     [](provider* a, provider* b){return a->agent->get_next_price() < b->agent->get_next_price();});

		offers[j->id] = offer(j, this, candidates[0], candidates[0]->agent->get_next_price());
		//LOG<<"ely_client::bid_one() job "<<j->id<<" price "<<offers[j->id].price;
		candidates[0]->agent->register_bid(offers[j->id]);
	}

	virtual void bid_one_until_leading_or_outcompeted(job *j) {
		if (offers.count(j->id) == 0) {
			bid_one(j);
		}
		if (offers.count(j->id) == 0) {
			return;
		}
		//if (offers[j->id].state == offers[j->id].state)
		//	LOG<<"ely_client::bid_one_until() job "<<osp(offers[j->id].state);
		//if (offers[j->id].next_price >= 0  || j->value != 99)
		//	LOG<<"ely_client::bid_one_until() job "<<offers[j->id].next_price;
		while (offers.count(j->id) > 0 &&
		       offers[j->id].next_price <= j->value &&
		       offers[j->id].state != offer_state::leading) {			
			bid_one(j);
		}
		//LOG<<"ely_client::bid_one_until() job "<<j->id<<" price "<<offers[j->id].next_price<<" state "<<osp(offers[j->id].state);
		if (offers.count(j->id) > 0 && (offers[j->id].state != offer_state::leading ||
						offers[j->id].next_price > j->value)) {
			offers.erase(j->id);
		}
	}
	
	virtual void bid_all() {
		for (auto& j : c->jobs) {
			//LOG<<"ely_client::bid_all() job "<<j.id<<" state "<<jsp(j.state);
			//if (j.state != job_state::ready) {
				//LOG<<"ely_client::bid_all() job "<<j.id<<" state "<<jsp(j.state);
			//	continue;
			//}
			if (j.arrival_time > ticks) {
				LOG<<"Ticks: "<<ticks << " arrival "<<j.arrival_time;
				continue;
			}
			if (offers.count(j.id) == 0 /*&& j.arrival_time >= ticks*/) {
				if (j.state == job_state::ready /*&& j.arrival_time >= ticks*/) {
					bid_one_until_leading_or_outcompeted(&j);
				} else {
					//LOG<<"Ticks: "<<ticks << " arrival "<<j.arrival_time;
				}
			} else {
				
				if (j.state == job_state::post_run) {
					//LOG<<"ely_client::bid_all() job "<<j.id<<" state "<<jsp(j.state);
					offers.erase(j.id);
					j.state = job_state::ready;
				}
			}
		}
	}

	virtual void register_lead(offer o) {

	}

	virtual void register_rejection(offer o) {
		offers[o.j->id].state = offer_state::rejected;
		offers[o.j->id].next_price = o.p->agent->get_next_price();
		bid_one_until_leading_or_outcompeted(o.j);
		//LOG<<"register_rejection() job "<<o.j->id<< " num offers " <<offers.count(o.j->id);
		//offers.erase(o.j->id);
		
	}
	
	virtual void register_post_run(int j) {
		return;
		if (offers[j].j->state == job_state::post_run) {
			//offers[j].j->state = job_state::ready;
		}
		//offers.erase(j);
	}
};

class ely_provider:public provider_agent {
public:
ely_provider(int i, int d):provider_agent(i,d){}
	
	virtual void register_bid(offer &o) {
		if (leading_valid == false){
			o.state = offer_state::leading;
			leading_offer_mtx.lock();
			leading_valid = true;
			leading_offer = o;
			leading_offer_mtx.unlock();
		} else if (o.price > leading_offer.price) {
			o.state = offer_state::leading;
			leading_offer_mtx.lock();
			offer tmp = leading_offer;
			leading_offer = o;
			leading_offer_mtx.unlock();
			
			tmp.ca->register_rejection(tmp);
		} else {
			o.state = offer_state::rejected;
			o.next_price = leading_offer.price + incparam;
		}
		//LOG<<"ely_provider::register_bid() job id  "<<leading_offer.j->id;
		next_price = leading_offer.price + incparam;
	}
};

enum class event_type {evict, load};

class event {
	public:
	client *c;
	provider *p;
	job *j;
	event_type t;
	int completion_tick;
	int duration;
	int completion_tick_evict;
	int duration_evict;

	event(client *_c, provider *_p, job *_j, int _c_t, event_type _t, int _d, int _cte, int _de):
	      c(_c), p(_p), j(_j), completion_tick(_c_t), t(_t), duration(_d), completion_tick_evict(_cte), duration_evict(_de)
	{
	}
	~event()
	{
	}
};

class comp
{
	public:
	comp() {}
	bool operator() (const event& lhs, const event& rhs) const
	{
		return (lhs.completion_tick>rhs.completion_tick);
	}
};

//priority queue for job simulation
priority_queue<event, vector<event>, comp> pq;
//mutex to protect priority queue
mutex pq_mtx;

//init providers
void p_init( XMLHandle *x)
{
	XMLNode *e = x->FirstChild().ToNode();
	while ( e )
	{
		vector<resource* > r;
		provider_agent *a;
		int incparam,decparam;
		XMLElement *tmp_element = e->ToElement();

		//parse resources
		XMLNode *tmp_resource = tmp_element->FirstChild();
		while ( tmp_resource )
		{
			XMLElement *t_r_e = tmp_resource->ToElement();
			r.push_back(new resource(t_r_e->IntAttribute("ncpu"), t_r_e->IntAttribute("mem")));

			tmp_resource = tmp_resource->NextSibling();
		}
		//select provider_agent
		a = NULL;
		//if (tmp_element->Attribute("agent", "NONE"))
		//	a = new(trivial_pagent);
		//if (tmp_element->Attribute("agent", "NO_INC"))
		//  a = new no_inc_pagent(tmp_element->IntAttribute("incparam"), tmp_element->IntAttribute("decparam"));
		//a = new provider_agent(tmp_element->IntAttribute("incparam"), tmp_element->IntAttribute("decparam"));
		a = new ely_provider(tmp_element->IntAttribute("incparam"), tmp_element->IntAttribute("decparam"));
//incparam = tmp_element->IntAttribute("incparam");
		//decparam = tmp_element->IntAttribute("decparam");
		provider * tmp_p = new provider(r, a);
		//set name
		a->name = tmp_element->Attribute("name");
		a->p = tmp_p;
		providers.push_back(tmp_p);

		e = e->NextSibling();
	}
}

//init clients
void c_init( XMLHandle *x )
{
	XMLNode *e = x->FirstChild().ToNode();
	while ( e )
	{
		vector<job> j;
		client_agent *a;

		XMLElement *tmp_element = e->ToElement();

		//parse resources
		XMLNode *tmp_job = tmp_element->FirstChild();
		while ( tmp_job )
		{
			XMLElement *t_r_e = tmp_job->ToElement();
			j.push_back(job(t_r_e->IntAttribute("value"),
					t_r_e->IntAttribute("ncpu"),
					t_r_e->IntAttribute("mem"),
					t_r_e->IntAttribute("arrival"),
					t_r_e->IntAttribute("remaining"),
					    t_r_e->IntAttribute("budget"),
					    t_r_e->IntAttribute("succrate")));
			tmp_job = tmp_job->NextSibling();
			DBG<<"last job added remaining "<< j.back().remaining_time;
		}
		//select client_agent
		a = NULL;
		//if (tmp_element->Attribute("agent", "NONE"))
		//	a = new(trivial_cagent);
		//if (tmp_element->Attribute("agent", "OBLIV"))
		//	a = new(obliv_cagent);
		//if (tmp_element->Attribute("agent", "AVOID_MIGRATION"))
		//	a = new(avoid_migrate_cagent);
		//a = new(client_agent);
		a = new(ely_client);
		client *tmp_c = new client(j, a);
		a->c = tmp_c;
		//set name
		a->name = tmp_element->Attribute("name");

		for (int i = 0; i < providers.size(); i++) {
			i=i;
		}
		clients.push_back(tmp_c);

		e = e->NextSibling();
	}
}

bool some_provider_still_accepts_bids(vector<provider*> p)
{
	for (int i = 0; i < p.size(); i++)
		if (p[i]->market_status == provider_market_status::bid)
			return true;
	return false;
}

//bidding loop
void bid_loop()
{
	while (clients.size() > 0) {
		ticks_mtx.lock();
		ticks++;
		ticks_mtx.unlock();
	for (int i = 0; i < clients.size(); i++) {
		//cout<<"SHARON: name "<< clients[i]->agent->name<<" size "<<clients[i]->agent->offers.size()<<endl;
		clients[i]->agent->bid_all();
		//this_thread::sleep_for(chrono::milliseconds(10));
	}
	for (int i = 0; i < providers.size(); i++) {
		//cout<<"timeout for "<<providers[i]->agent->name<<"\n";
		if(providers[i]->check_timeout()) {
			providers[i]->agent->schedule_bids();
		}
	}

	for (int i = 0; i < clients.size(); i++) {
		/*
		  for (int j = 0; j < clients[i]->agent->offers.size(); j++) {
			if(clients[i]->agent->offers[j]==NULL) {
				//delete(clients[i]->agent->offers[j]);
				clients[i]->agent->offers.erase(clients[i]->agent->offers.begin() + j);
				j = 0 ;
	       		}
       	       	}
		*/
		if (clients[i]->all_done()) {
			//todo: delete offers in client agent code
			/*for (int j = 0; j < clients[i]->agent->offers.size(); j++) {
				//delete(clients[i]->agent->offers[j]);
				clients[i]->agent->offers.erase(clients[i]->agent->offers.begin() + j);
x				j = 0 ;
				//clients[i]->agent->offers[j] = NULL;
				}*/
			SIM_LOG<<"delete client "<<clients[i]->agent->name<<" "<<clients.size()-1<<" clients left";
			//delete(clients[i]->agent);
			//clients[i]->agent = NULL;
			//delete(clients[i]);
			clients.erase(clients.begin() + i);
			i = 0;
		} else {
			
		}
	}
	}
}

void provider_agent::schedule_bids()
{
	int min_remaining = quantum;
	int total_cpus = 0, utilized_cpus = 0;

	for (int i = 0; i < p->resources.size(); i++)
	  total_cpus += p->resources[i]->ncpu;
	
	//LOG<<"schedule_bids() called ";
	curr_price = next_price;
	p->round_counter++;
	leading_offer_mtx.lock();
	if (leading_valid == true) {
		LOG<<"schedule_bids() leading "<<leading_offer.j->id;
	  if (leading_offer.obsolete == true || true) {
			p->market_status = provider_market_status::protect;

			leading_offer.ca->pay(&leading_offer);
			
			//leading_offer->obsolete = true;
			//todo: should job state/status be updated here?
			next_price = max(next_price, leading_offer.price) + incparam;
			LOG<<"scheduled "<<leading_offer.price;
			LOG<<"got offers, next_price "<<next_price<<" job "<<leading_offer.j->id;
			utilized_cpus = leading_offer.j->ncpu;
			leading_offer.state = offer_state::scheduled;
			pq_mtx.lock();
			min_remaining = min(quantum, leading_offer.j->remaining_time);
			event e1 = event(leading_offer.ca->c, leading_offer.p, leading_offer.j, ticks, event_type::load, 0, ticks + min_remaining, min_remaining);
			pq.push(e1);
			pq_mtx.unlock();
			leading_valid = false;
		} else {
		  //LOG<<"LEADING OFFER ISNT OBSOLETE";
		}
	} else {
		next_price = max(next_price - decparam, 0);
		if (decparam == 0)
		  next_price = 0;
		//next_price = 1;
		LOG<<"no offers, next_price "<<next_price;
		
		p->market_status = provider_market_status::bid;
		p->update_timeout();
	}
	LOG<<"utilizing "<<utilized_cpus<<" from "<<total_cpus;
	leading_offer_mtx.unlock();
}

mutex handlers_mtx;

int count_jobs_left()
{
	int ret = 0;
	for (int i = 0; i < clients.size(); i++) {
		for (int j = 0; j < clients[i]->jobs.size(); j++) {
			if (clients[i]->jobs[j].state != job_state::done && clients[i]->jobs[j].state != job_state::abort) {
				ret++;
			}
		}	
	}
	return ret;
}

void evict_handler(event e)
{
	//EVICT_LOG << "job "<<e.j->id<<" evicted";
	int flag = 0;
	if (e.t != event_type::evict) //sanity
		return;
	handlers_mtx.lock();
	for (int i = 0; i < e.p->resources.size(); i++) {
		flag = 0;
		for (int j = 0; j < e.p->resources[i]->cpus.size(); j++) {
			if (e.p->resources[i]->cpus[j].job == e.j->id) {
				e.p->resources[i]->cpus[j].job = -1;
				flag = 1;
			}
		}
		if (flag == 1)
			e.p->resources[i]->free_mem = min(e.p->resources[i]->free_mem + e.j->mem, e.p->resources[i]->mem);
	}
	//update job
	e.j->remaining_time -= e.duration;
	e.j->market_status = job_market_status::ready;
	//EVICT_LOG << "job "<<e.j->id<<" market status becomes ready";
	if (e.j->remaining_time <= 0) {
		e.j->state = job_state::done;
		e.j->completion_time = e.completion_tick;
		EVICT_LOG << "job "<<e.j->id<<" done jobs left "<<count_jobs_left();
	} else {
		e.j->state = job_state::post_run;
		EVICT_LOG << "job "<<e.j->id<<" evicted from "<<e.p->agent->name<<" remaining "<<e.j->remaining_time;
	}
	//update provider
	e.p->market_status = provider_market_status::bid;
	e.p->update_timeout();
	//update client
	e.c->agent->register_post_run(e.j->id);
	handlers_mtx.unlock();
}

int count_free_cpus(resource *r)
{
	int ret = 0;

	for (int i = 0; i < r->cpus.size(); i++)
		if (r->cpus[i].job < 0)
			ret++;
	return ret;
}

resource *find_free(provider *p, int mem, int ncpu)
{
	resource *ret = NULL;
	for (int i = 0; i < p->resources.size(); i++) {
		if (p->resources[i]->free_mem >= mem && 
		    count_free_cpus(p->resources[i]) >= ncpu) {
			ret = p->resources[i];
			break;
		}
	}
	return ret;
}

void load_handler(event e)
{
	int i = 0;
	resource *tmp;
	vector<cpu*> revert;

	if (e.t != event_type::load) //sanity
		return;
	handlers_mtx.lock();
	event e2 = event(e.c, e.p, e.j, e.completion_tick_evict, event_type::evict, e.duration_evict, 0, 0);
	i = e.j->ncpu;
	tmp = find_free(e.p, e.j->mem, i);
	if (tmp == NULL) {
		LOAD_LOG << "can't fit job "<<e.j->id;
		e.j->state = job_state::ready;
		goto unlock; //ERROR
	}
	//update provider
	e.p->market_status = provider_market_status::protect;
	e.p->agent->curr_price = e.p->agent->next_price;
	//update resource
	for (int j = 0 ; j < tmp->cpus.size() && i > 0; j++) {
		if (tmp->cpus[j].job < 0) {
			tmp->cpus[j].job = e.j->id;
			revert.push_back(&(tmp->cpus[j]));
			i--;
		}
	}
	if (i > 0) { //ERROR, revert assignment
		for (int j = 0; j < revert.size(); j++) {
			LOAD_LOG << "reverting";
			revert[j]->job = -1;
		}
		goto unlock;
	}
	//update job
	LOAD_LOG << "job "<<e.j->id<<" loaded on "<<e.p->agent->name;
	e.j->state = job_state::run;
	e.j->market_status = job_market_status::protect;
	e.j->assoc_provider = e.p;
	pq_mtx.lock();
	//LOAD_LOG << "job "<<e.j->id<<" loaded on "<<e.p->agent->name<<" pq locked";
	pq.push(e2);
	pq_mtx.unlock();
unlock:
	handlers_mtx.unlock();
	//LOAD_LOG << "job "<<e.j->id<<" loaded on "<<e.p->agent->name<<" unlocked";
}

//simulation loop
void sim_loop()
{
	while (clients.size() > 0) {
		pq_mtx.lock();
		if (pq.empty()) {
			pq_mtx.unlock();
			//this_thread::sleep_for(chrono::milliseconds(5));
		} else {
			event e = pq.top();
			pq.pop();
			pq_mtx.unlock();
			if (e.t == event_type::evict) {
				evict_handler(e);
			} else if (e.t == event_type::load) {
				load_handler(e);
			}
			ticks_mtx.lock();
			ticks++;
			ticks_mtx.unlock();
		}
	}
	for (int i = 0; i < providers.size(); i++) {
		for (int j = 0; j < providers[i]->resources.size(); j++) {
		  //for (int k = 0; k < providers[i]->resources[j]->cpus.size();k++)
			  //delete(providers[i]->resources[j]->cpus[k]);
			delete(providers[i]->resources[j]);
		}
		delete(providers[i]->agent);
		delete(providers[i]);
	}
}

int main(int argc, char **argv)
{

	XMLDocument simxml;
	simxml.LoadFile( argv[1] );
	if ( simxml.ErrorID() != 0) {
		cout<<"Error loading xml "<<simxml.ErrorID()<<"\n";
		return -1;
	}

	XMLHandle simhandle( &simxml );
	delta = simhandle.FirstChildElement().ToElement()->IntAttribute("delta");
	migration_cost = simhandle.FirstChildElement().ToElement()->IntAttribute("migration");
	quantum = simhandle.FirstChildElement().ToElement()->IntAttribute("quantum");
	bid_window = simhandle.FirstChildElement().ToElement()->IntAttribute("bid_window");
	noise_max = simhandle.FirstChildElement().ToElement()->IntAttribute("noise");
	XMLHandle xmlproviders = simhandle.FirstChildElement().FirstChildElement( "providers" );
	XMLHandle xmlclients = simhandle.FirstChildElement().FirstChildElement( "clients" );

	//init providers
	p_init( &xmlproviders );
	//init clients
	c_init( &xmlclients );

	//run simulation
	//bidding loop thread
	thread bid(bid_loop);
	//job simulation thread
	thread sim(sim_loop);

	bid.join();
	sim.join();
	return 0;
}
