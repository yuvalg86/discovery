<?php
$file = rawurlencode('http://www.cs.huji.ac.il/~lior/sorma/sd.status');
$showAdvance = false;
$refresh_count = 0;
$maxcount = 20;

if (isset($_COOKIE["refresh"])) {
    $refresh_count = $_COOKIE["refresh"];
}

$refresh_count++;
if ($refresh_count > $maxcount ) {
    $refresh_count = 0;
}

setcookie("refresh",$refresh_count , time()+60*60*24*30);

$xml = simplexml_load_file($file);
//echo "<pre>";
//print_r($xml);
//echo "</pre>";
function doCaption($id, $caption) {
          $sign =  (array_key_exists($id, $_COOKIE)?($_COOKIE[$id]=='none' ? "- " : "+ "):"- ");
          echo "<caption onclick=\"javascript:toggleItem('".$id."');\" onmouseover=\"this.style.cursor='pointer'\">"
            .$sign.
            "".$caption."</caption>";
}

function doTbody($id) {
   if (array_key_exists($id, $_COOKIE)) {
      echo '<tbody id="'.$id.'" style="display: '.$_COOKIE[$id].'">';
   } else {
      echo '<tbody id="'.$id.'" style="display: table-row-group">';
   }
}


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
                      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">   
     <head>

    <?php
    if ($refresh_count != $maxcount) {
        echo '<meta http-equiv="refresh" content="15" />';
    }
?>
    
      <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
      <link rel="stylesheet" href="smoochi.css" type="text/css" />
      <title>MEI information page</title>
      <script src="sorttable.js" type="text/javascript" ></script>
      <script src="collapse.js" type="text/javascript" ></script>
     </head>
<body>



<div class="header">
<table>
<tr>
<td>
<h1>MOSIX Economy Infrastructure <br /> Information Page</h1>
</td>
<td>
<a rel="external" href="http://www.iw.uni-karlsruhe.de/sormang/index.php?id=31">
<img src="SORMA_logo_small.gif" alt="SORMA logo" />
</a>
</td>
</tr>
</table>
</div>

<div class="update">
<h2>
<?php
echo "Last updated: <script type=\"text/javaScript\">showTime(".(int)$xml->sormadStatus->lastUpdated.");</script>";
?>
</h2>      

<?php
if ($refresh_count == $maxcount) {
    echo "<h3> Press reload to update </h3>";
 }
?>
      
</div>

<table>
<caption>Sormad Status</caption>
<thead>
<tr>
<th class="thtext">Sormad Host</th>
<th class="thtext">Assignd Port</th>
<th class="thtext">Control Port</th>     
<th class="thtext">Assignds</th>
<th class="thtext">Providers</th>
<th class="thtext">Clusters</th>
</tr>
</thead>

<tbody>
<tr>
<td><?php echo $xml->sormadStatus->sormadHost ?></td>
<td><?php echo $xml->sormadStatus->assignPort ?></td>
<td><?php echo $xml->sormadStatus->ctlPort ?></td>
<td><?php echo $xml->sormadStatus->assigndNum ?></td>
<td><?php echo $xml->sormadStatus->providersNum ?></td>
<td><?php echo $xml->sormadStatus->clustersNum ?></td>
</tr>
</tbody>

</table>

<table>
<caption>Economy Status</caption>
<thead>
<tr>
<th class="thtext">Solver Name</th>     
<th class="thtext">Solver Version</th>
<th class="thtext">Computation Time</th>
<th class="thtext">Consumers' Surplus</th>
<th class="thtext">Providers' Surplus</th>
<th class="thtext">Social Welfare</th>
<th class="thtext">Status</th>

</tr>
</thead>

<tbody>
<tr>
<td><?php echo $xml->sormadStatus->economyStatus->solverName ?></td>
<td><?php echo $xml->sormadStatus->economyStatus->solverVersion ?></td>
<td><?php echo $xml->sormadStatus->economyStatus->computeTime ?></td>
<td><?php echo $xml->sormadStatus->economyStatus->consumersSurplus ?></td>
<td><?php echo $xml->sormadStatus->economyStatus->providersSurplus ?></td>
<td><?php echo $xml->sormadStatus->economyStatus->socialWelfare ?></td>
<td><?php echo $xml->sormadStatus->economyStatus->marketStatus ?></td>
</tr>
</tbody>

</table>

<table>
<caption>Jobs</caption>
<thead>
<tr>
<th class="thtext">Run</th>
<th class="thtext">Wait</th>
<th class="thtext">Suspend</th>
<th class="thtext">No Budget</th>
<th class="thtext">Total</th>
</tr>
</thead>

<tbody>
<?php
   echo '<tr>';
   echo '<td>' . $xml->sormadStatus->jobs->run . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->wait . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->suspend . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->nobudget . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->total . '</td>';
   echo '</tr>';
?>
</tbody>
</table>

<table>
<caption>Statistics</caption>
<thead>
<tr>
<th class="thtext">Finished Jobs</th>
</tr>
</thead>

<tbody>
<?php echo '<tr>';
   echo '<td>' . $xml->sormadStatus->jobs->finish . '</td>';
   echo '</tr>';
?>
</tbody>
</table>

<<<<<<< index.php
<br/>

<table>
<caption>Jobs Total</caption>
<tr>
<th>Run</th>
<th>Wait</th>
<th>Suspend</th>
<th>Out of money</th>
<th>Total</th>
</tr>
<?php
   echo '<tr>';
   echo '<td>' . $xml->sormadStatus->jobs->run . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->wait . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->nobudget . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->suspend . '</td>';
   echo '<td>' . $xml->sormadStatus->jobs->total . '</td>';
   echo '</tr>';
?>
</table>

<br/>
=======
>>>>>>> 1.6
<table class="sortable" id="jobsStatus">

<?php doCaption('jobBody',"Job Status"); ?>
<thead>
<tr>
<th>Id</th>
<th>Status</th>
<th>User</th>
<th>Location</th>
<th>Current Payment</th>
<th>Maximal Payment</th>
<th>Total Payment</th>
<th>Budget</th>
</tr>
</thead>

<?php
doTbody('jobBody');
foreach ($xml->submissions->job as $job) {

    echo '<tr>';
    echo '<td>' . $job['id'] . '</td>';
    echo '<td>' . $job->status . '</td>';
    echo '<td>' . $job->user . '</td>';
    echo '<td>' . $job->where . '</td>';
    printf("<td>%01.2f</td>",$job->{"curr-pay"});
    printf("<td>%01.2f</td>",$job->{"max-pay"});
    printf("<td>%01.2f</td>",$job->{"total-pay"});
    printf("<td>%01.2f</td>",$job->{"max-budget"});
    
    echo '</tr>';

}
?>
<<<<<<< index.php
=======
</tbody>
</table>
>>>>>>> 1.6

<<<<<<< index.php

=======
>>>>>>> 1.6
<table class="sortable" id="providersStatus" >
<?php doCaption('provBody',"Provider Status"); ?>
<thead>
<tr>
<th>Name</th>
<th>CPUs</th>
<th>Memory (MB)</th>
<th>Minimum Price</th>
<th>Current Price</th>
</tr>
</thead>

<?php
doTbody('provBody');

foreach ($xml->providers->provider as $pro) {

    echo '<tr>';
    echo '<td>' .$pro['name'] . '</td>';
    echo '<td>' .$pro->{"cpu-num"} . '</td>';
    printf("<td>%01d</td>",$pro->mem);
    printf("<td>%01.2f</td>",$pro->{"min-price"});
    printf("<td>%01.2f</td>",$pro->{"curr-price"});
    echo '</tr>';
}
?>
</tbody>
</table>

<?php if (! $showAdvance) { 
  echo '</body>';
  echo '</html>';
  exit(0);
}
?>
<table class="sortable" id="clustersStatus">
<?php doCaption('clusterBody',"Cluster Status"); ?>
<thead>
<tr>
<th>Name</th>
<th>Representatives</th>
</tr>
</thead>

<?php
doTbody('clusterBody');
foreach ($xml->clusters->cluster as $clusters) {
   echo '<tr>';
   echo '<td>'.$clusters['name'].'</td>';
   echo '<td>';
   foreach ($clusters->rep as $rep) {
     echo "$rep ";
   }
   echo '<td>';
   echo '</tr>';
}
?>
</tbody>
</table>

<table>
<?php doCaption('assignBody',"Assignd Status"); ?>
<thead>
<tr>
<th class="thtext">Name</th>
</tr>
</thead>

<?php
doTbody('assignBody');
foreach ($xml->assignds->assignd as $ass) {
   echo '<tr><td>' . htmlspecialchars($ass['name']) . '</td></tr>';
}
?>

</tbody>
</table>

</body>
</html>
