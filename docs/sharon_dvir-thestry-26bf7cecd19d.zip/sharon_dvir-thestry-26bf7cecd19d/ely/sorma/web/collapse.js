function getItem(id)
{
    var itm = false;
    if(document.getElementById)
        itm = document.getElementById(id);
    else if(document.all)
        itm = document.all[id];
    else if(document.layers)
        itm = document.layers[id];

    return itm;
}

function toggleItem(id)
{

    var item = getItem(id);

    if(!item)
        return false;

    var caption = item.parentNode.getElementsByTagName("CAPTION")[0];
    var text = caption.childNodes[0].data;

    // cut arrow if needed
    if (!text.match(/^[a-zA-Z0-9 ]*$/))
        text = text.substr(1);

    if (item.style.display == 'none') {
        if (navigator.appName == "Netscape")
            item.style.display = 'table-row-group';
        else {
            item.style.display = 'inline-block';
        }
    } else {
        item.style.display = 'none';
    }
    
    setCookie(id, (item.style.display)); 

    if (item.style.display == 'none')
        caption.innerHTML = '-' + text;
    else
        caption.innerHTML = '+' + text;
    
    return false;
}

addEvent(window, "load", externalLinks );

function externalLinks() { 
    if (!document.getElementsByTagName) return; 
    var anchors = document.getElementsByTagName("a"); 
    for (var i=0; i<anchors.length; i++) { 
        var anchor = anchors[i]; 
        if (anchor.getAttribute("href") && 
            anchor.getAttribute("rel") == "external") 
            anchor.target = "_blank"; 
    } 
} 

function showTime(utc) {
    var d = new Date();
    d.setTime(utc * 1000);
    document.write(d);
} 
