
#  ProviderCtl $Id: SormaCtl.pm,v 1.8 2007-01-23 16:31:22 lior Exp $ #  
# 

#****c* sormad/SormaCtl
# FUNCTION
# 
# This module is used to interface the sorma market for queirying it and 
# settint (ctl) varios parameters

package sormad::SormaCtl;

use strict;
use Socket;
use IO::Socket::INET;
use File::Basename;
use Data::Dumper;
use XML::Simple;

use Util::Net; 
use Util::Debug; 
use Util::Misc;
use sormad::SormadParam; 
use providerd::ProviderParam;
#################### Functions from this class ############################
sub new;
sub getStatus;
sub getSormadStatus;
sub getAssigndStatus;
sub getJobsStatus;
sub getProviderStatus;
############################################################################


my $filename = basename $0;

#****m* sormad/SormaCtl->new
# FUNCTION
#   Constractor for the SormaCtl object
# SYNOPSIS
#   $sCtl = new SormaCtl(prog_name   => "program name");
# ARGUMENTS
#   prog_name        The program name for syslog
# RETURN VALUE
#  undef    On error
#  A reference to a SormaCtl object on success
#******
sub new 
{
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    my $timeout = 10;
     
    $self->{sdPort} = $sdCtlPort;
    $self->{errMsg} = "";
    
    debug_lb(SD_CTL_DBG, "Port: $self->{sdPort}\n");
    bless($self, $class);
    return $self;
}

sub close {
    my $self = shift;
    
}

sub initTCPSock {
    my $self = shift;
    my $machineName = shift;
    
    my $tcpSock = new IO::Socket::INET->new(PeerAddr => $machineName,
                                            PeerPort => $self->{sdPort},
                                            Proto    => 'tcp');
    if (!$tcpSock) {
        debug_lr(PVD_CTL_DBG, "Error generating tcp sock to $machineName\n");
        $self->{errMsg} = "Error generating tcp socket:  $!\n";
        return undef;
    }
    
    return $tcpSock;
}

sub errorMsg {
    my $self = shift;
    return  $self->{errMsg};
}

sub sendMessage {
    my $self = shift;
    my $machine = shift;
    my $msgTypeTag = shift;
    my $msgH  = shift;
    my $resRef  = shift;
    my $xml = new XML::Simple(NoAttr=>1, RootName=>$msgTypeTag);
    
    # Generate the XML query from the hash
    my $msgXml = $xml->XMLout($msgH);
    debug_lg(SD_CTL_DBG, "XML:\n$msgXml\n");

    # Generate the tcp sock and send the query
    my $tcpSock = $self->initTCPSock($machine);
    return 0 if(!$tcpSock);
    $tcpSock->send($msgXml);

    # First reading the header to learn about the size of the data
    my $hdr;
    $tcpSock->recv($hdr, $ctlResultHeaderSize);
    chomp($hdr);
    if(!$hdr) { 
        debug_lr(SD_CTL_DBG, "Error reading header\n");
        return 0;
    }
    if(! ($hdr =~ /\s*(\d+)\s*/)) {
        debug_lr(SD_CTL_DBG, "Error parsing header ($hdr)\n");
        return 0;
    }
    my $len = $1;
    debug_lg(SD_CTL_DBG, "Data len: $len\n");

    # Recieve the result of the query
    my $response = recvData($tcpSock, $len, 5);
    if(!$response) {
        $self->{errMsg} = "Nothing recieved from providerd";
        return 0;
    }
    debug_lg(SD_CTL_DBG, "Response length:".length($response)."\n");
    $tcpSock->close();
    
    #my $resHash  = $xml->XMLin($response);
    $$resRef = $response;
    return 1;
}


sub getStatus {
    my $self = shift;
    my $type = shift;
    my $machine = shift;
    my $statusResult = shift;
    my $retVal = 0;
    my $ctlH = {};
    my $resH;
    
    $ctlH->{$ctlTypeTag} = $type;
    my $res = $self->sendMessage($machine, $ctlMsgTag, $ctlH, \$resH);
    return 0 if(!$res);
    
    $retVal = 1;
    $$statusResult = $resH;
    return $retVal;
}

sub xmlToHash {
    my $self = shift;
    my $xmlStr = shift;
    my $forceArray = shift;
    my $keyAttr = shift;
    
    #debug_lg(SD_CTL_DBG, "XML:\n$xmlStr\n");
    my $h = eval { XMLin($xmlStr,  
                         SuppressEmpty => "",  
                         ForceArray => $forceArray, 
                         KeyAttr => $keyAttr );
               };
    
    if($@) {
        debug_lr(SD_CTL_DBG, "Error converting xml to hash\n$@\n");
        #debug_lr(SD_CTL_DBG, $xmlStr);
        return undef;
    }
    debug_ly(SD_CTL_DBG, Dumper($h));
    return $h;
}

sub getSormadStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;
    my $res = $self->getStatus($ctlTypeSormadStatus, $machine, $statusResult);
    return 0 if (!$res);
    
    my $h = $self->xmlToHash($$statusResult, [$assigndTag], {$assigndTag => "name"});
    return 0 if(!defined($h));
    $$statusResult = $h;
    return 1;
}

sub getAssigndStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    my $res = $self->getStatus($ctlTypeAssigndStatus, $machine, $statusResult);
    return 0 if(!$res);

    my $h = $self->xmlToHash($$statusResult, [$assigndTag], {$assigndTag => "name"});
    return 0 if(!defined($h));
    
    # Taking the part we need
    if(exists($h->{$assigndListTag}) and ref($h->{$assigndListTag})) {
        $h = $h->{$assigndListTag}->{$assigndTag};
    } else {
        $h = {};
    }

    my $str = "Assignds\n";
    $str .= "--------------------\n";

    foreach my $name (keys %$h) {
        $str .= "$name\n";
    }

    $$statusResult = $str;
    debug_ly(SD_CTL_DBG, Dumper($h));
    return 1;

}
sub getJobsStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    my $res = $self->getStatus($ctlTypeJobsStatus, $machine, $statusResult);
    return 0 if(!$res);

    my $h = $self->xmlToHash($$statusResult, [$jobTag], {$jobTag => "id"});
    return 0 if(!defined($h));

    
    # Taking the part we need
    if(exists($h->{$jobListTag}) and  ref($h->{$jobListTag})) {
        $h = $h->{$jobListTag}->{$jobTag};
    } else {
        $h = {};
    }

    debug_ly(SD_CTL_DBG, Dumper($h));
    my $str = sprintf("%-10s%-10s%-12s%-6s\t%-6s\t%-6s\t%-6s\t%-10s\n", 
                      "ID", "User", "Status", "MaxPay", "CurrPay", "Total", "Budget", 
                      "Where");
    foreach my $id (sort {$a <=> $b} (keys %$h)) {
        my $jobH    = $h->{$id};
        my $maxPay  = $jobH->{$allJobFields->{"max-pay"}};
        my $status  = $jobH->{$allJobFields->{"status"}};
        my $where   = " - ";
        my $currPay = "0";
        if(exists($jobH->{$allJobFields->{where}})) {
            $where   =  $jobH->{$allJobFields->{where}};
            $currPay =  $jobH->{$allJobFields->{"curr-pay"}};
        }
        my $totalPay = $jobH->{$allJobFields->{"total-pay"}};
        my $budget  = " - ";
        if(exists($jobH->{$allJobFields->{"max-budget"}})) {
            $budget = $jobH->{$allJobFields->{"max-budget"}};
        }
        my $user = $jobH->{$allJobFields->{"user"}};
        $str .= sprintf("%-10s%-10s%-12s%-6.2f\t%-6.2f\t%-6.2f\t%-6.2f\t%-10s\n", 
                        $id, $user, $status, $maxPay, $currPay, $totalPay, $budget, $where);
    }

    $$statusResult = $str;
    return 1;
    
}

sub mSortOp { return Util::Misc::machines_sort_func($b , $a); }

sub getProvidersStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    my $res = $self->getStatus($ctlTypeProvidersStatus, $machine, $statusResult);
    return 0 if(!$res);

    my $h = $self->xmlToHash($$statusResult, [$providerTag], {$providerTag => "name"});
    return 0 if(!defined($h));
    
    # Taking the part we need
    $h = $h->{$providerListTag}->{$providerTag};
    debug_ly(SD_CTL_DBG, Dumper($h));
    
    my $str = sprintf("%-12s %-12s %-12s\n", 
                      "Provider", "Min-Price", "Curr-Price");  

    foreach my $n (sort mSortOp keys %$h) {
        my $p = $h->{$n};
        $str .= sprintf("%-12s %-12.2f %-12.2f\n", $n, $p->{$minPriceTag}, $p->{$currPriceTag});;
    }
    $$statusResult = $str;

    return 1;
}


sub getClustersStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    my $res = $self->getStatus($ctlTypeClustersStatus, $machine, $statusResult);
    return 0 if(!$res);
    
    my $h = $self->xmlToHash($$statusResult, [$clusterTag], {$clusterTag => "name"});
    return 0 if(!defined($h));
    
    # Taking the part we need
    $h = $h->{$clustersListTag}->{$clusterTag};
    debug_ly(SD_CTL_DBG, Dumper($h));
    
    my $str;
    $str  .=  "Cluster\tRepresentatives\n";
    foreach my $c (keys %$h) {
        $str .= "$c\t@{$h->{$c}->{$repTag}}\n";
    }
    $$statusResult = $str;
    return 1;
}

sub setDebug {
    my $self = shift;
    my $machine = shift;
    my $type = shift;
    my $listRef = shift;
    
    my $ctlH;
    my $resH;
    $ctlH->{$ctlTypeTag} = $type; 
    $ctlH->{levels} = [];
    
    foreach my $l (@$listRef) {
        push @{$ctlH->{levels}}, $l."_DBG"; 
    }
    my $res = $self->sendMessage($machine, $ctlMsgTag, $ctlH, \$resH);
    return $res;
}

sub addDebug {
    my $self = shift;
    my $machine = shift;
    my $listRef = shift;
    return $self->setDebug($machine, $ctlTypeAddDebug, $listRef);
}

sub removeDebug {
    my $self = shift;
    my $machine = shift;
    my $listRef = shift;
    return $self->setDebug($machine, $ctlTypeRemoveDebug, $listRef);
}

sub listDebug {
    my $self = shift;
    my $machine = shift;
    my $resultStr = shift;

    my $ctlH;
    my $resXml;
    $ctlH->{$ctlTypeTag} = $ctlTypeListDebug; 
    my $res = $self->sendMessage($machine, $ctlMsgTag, $ctlH, \$resXml);
    
    my $h = $self->xmlToHash($resXml, ["levels"], {});
    return 0 if(!defined($h));
    
    my $str = "sormad debug levels:\n";
    foreach my $l (@{$h->{levels}}) {
        $str .= "$l\n";
    }
    $$resultStr = $str;
    return $res;
} 

1;


    
