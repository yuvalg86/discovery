#  JobManager $Id: JobManager.pm,v 1.9 2007-01-23 16:31:21 lior Exp $ #  


#****c* sormad/JobManager
# FUNCTION
# 
# This module is a data-structure for managing the current jobs in the cluster.
# The jobs are kept and are accessible via the interface functions

package sormad::JobManager;

use strict;

use Sys::Syslog;
use Data::Dumper; 
use XML::Simple;

use Util::Debug;
use sormad::SormadParam;

sub new;
sub getTotalJobNum;
sub getRunableJobNum;
sub getWaitingJobNum;
sub getNoBudgetJobNum;
sub getJobsAtState;
sub getJobsXml;
sub addJob;
sub removeJob;
sub removeJobsByNode;
sub updateJob;
sub getStatusStr;
sub setJobStatus;
sub getJobInfo;
#****m* sormad/JobManager->new
# FUNCTION
#   Constractor for the JobManager object
# SYNOPSIS
#   $jMgr = new ProviderD();
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to a JobManager object on success
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };
    
    $self->{totalJobNum} = 0;    # The number of registerd job
    $self->{jobsAtState}->{JOB_RUN_STAT()} = 0;
    $self->{jobsAtState}->{JOB_WAIT_STAT()} = 0;
    $self->{jobsAtState}->{JOB_SUSPEND_STAT()} = 0;
    $self->{jobsAtState}->{JOB_NO_BUDGET_STAT()} = 0;
    $self->{jobsAtState}->{JOB_ABORT_STAT()} = 0;
    $self->{jobsAtState}->{JOB_FINISH_STAT()} = 0;

    $self->{jobH} = {};
    $self->{jobLog} = "";
    $self->{logFileHndl} = undef;

    $self->{f} = {};

    
    bless($self, $class);
    $self->setFieldsNames();
    return $self;
}

sub setFieldsNames {
    my $self = shift;
    
    foreach my $name (keys %$mandatoryJobFields) {
        $self->{f}->{$name} = $mandatoryJobFields->{$name};
    }
    foreach my $name (keys %$additionalJobFields) {
        $self->{f}->{$name} = $additionalJobFields->{$name};
    }
}

sub verifyJobHash {
    my $self = shift;
    my $jH = shift;

    foreach my $k (keys(%$mandatoryJobFields)) {
        if(!exists($jH->{$k})) {
            debug_lr(JMGR_DBG, "Missing field $k\n");
            return 0;
        }
        # Removing spaces 
        $jH->{$k} =~ s/^\s+//;
        $jH->{$k} =~ s/\s+$//;
    }
    return 1;
}

sub setLogFileHandle {
    my $self = shift;
    my $hndl = shift;

    $self->{logFileHndl} = $hndl;
}


sub getTotalJobNum {
    my $self = shift;
    return $self->{totalJobNum};
}

sub getRunableJobNum {
    my $self = shift;
    
    my $total = $self->getTotalJobNum();
    my $noBudget = $self->getJobsAtState(JOB_NO_BUDGET_STAT);

    return $total - $noBudget;
}

sub getJobsAtState {
    my $self = shift;
    my $state = shift;
    
    if(exists($self->{jobsAtState}->{$state})) {

        return $self->{jobsAtState}->{$state};
    }
    debug_lr(JMGR_DBG, "Error no such state $state\n");
    return -1;
    
    #return exists($self->{jobsAtState}->{$state}) ? 
    #  $self->{jobsAtState}->{$state} : -1
}

sub jobXmlToHash {
    my $self = shift;
    my $jobInfo = shift;
    
    if(! ref($jobInfo)) {
        debug_lg(JMGR_DBG, "Got string converting to xml\n");
        my $jobH = XMLin($jobInfo);
        if(!$jobH) {
            debug_lr(JMGR_DBG, "Failed converting string to job info hash\n");
            return 0;
        }
        $jobInfo = $jobH;
    }
    return $jobInfo;
}
    

sub addJob {
    my $self = shift;
    my $jobInfo = shift;  # A hash ref
    my $noVerify = 0;
    $noVerify = shift  if(@_);
    
    # If we get a scalar we treat is as xml string
    return 0 if(!($jobInfo = $self->jobXmlToHash($jobInfo)));
    
    # A special flags tell the method not to verify
    unless($noVerify) {
        return 0 if(!$self->verifyJobHash($jobInfo));
    }
    
    if(exists($self->{jobH}->{$jobInfo->{id}})) {
        debug_ly(JMGR_DBG, "Job already exists only updating\n");
        return $self->updateJob($jobInfo, 1);
    }

    my $id = $jobInfo->{id};
    $self->{jobH}->{$id} = $jobInfo;
    $self->{totalJobNum}++;
    
    # Setting the status of the job
    my $jh = $self->{jobH}->{$id};
    my $c;
    if(exists($jobInfo->{$self->{f}->{where}})) {
        $self->setJobStatus($id, JOB_RUN_STAT, $jobInfo->{$self->{f}->{where}}, \$c);
    } else {
        $self->setJobStatus($id, JOB_WAIT_STAT, "", \$c);
    }
    #print "DDDDDDDDD", Dumper($self->{jobsAtState});
    $jh->{$self->{f}->{where}} = ""
      if(!exists($jh->{$self->{f}->{where}}));
         
    # Setting the user field from the uid field
    if(!exists($jobInfo->{$self->{f}->{user}})) {
        if(exists($jh->{$self->{f}->{uid}})) {
            $jh->{$self->{f}->{user}} = getpwuid($jh->{$self->{f}->{uid}});
        }
        else {
            $jh->{$self->{f}->{user}} = $jh->{$self->{f}->{from}};
        }
    }

    # Setting a default cpu-num usage to 1 (if non was given)
    $jh->{$self->{f}->{'cpu-num'}} = 1
      if(!exists($jobInfo->{$self->{f}->{'cpu-num'}}));
    
    
    $jh->{$self->{f}->{'total-pay'}} = 0;
    $jh->{$self->{f}->{'curr-pay'}}  = 0;
    $jh->{$self->{f}->{'prev-update'}} = time(); # Taking the time of the addition
    
    debug_ly(JMGR_DBG, "Successfully added job: $jobInfo->{id}\n");
    return 1;
}


sub removeJob {
    my $self = shift;
    my $jobID = shift;  # A hash ref
    
    if(!exists($self->{jobH}->{$jobID})) {
        debug_lr(JMGR_DBG, "Job $jobID does not exists\n");
        return 0;
    }
    debug_lr(JMGR_DBG, "Removing job $jobID\n");
    
    my $c;
    $self->setJobStatus($jobID, JOB_FINISH_STAT, "", \$c);
    $self->{totalJobNum}--;
    delete($self->{jobH}->{$jobID});
    return 1;
}

sub removeJobsByNode {
    my $self = shift;
    my $addr = shift;

    debug_lb(JMGR_DBG, "Removing all jobs of node: $addr\n");
    # In the future this will be optimize, now a simple linear search
    foreach my $id (keys(%{$self->{jobH}})) {
        $self->removeJob($id)
          if($addr eq $self->{jobH}->{$id}->{$self->{f}->{from}});
    }
    return 1;
}

sub updateJob {
    my $self = shift;
    my $jobInfo = shift;

    my $noVerify = 0;
    $noVerify = shift if(@_);
    
    # If we get a scalar we treat is as xml string
    return 0 if(!($jobInfo = $self->jobXmlToHash($jobInfo)));
    
    # A special flags tell the method not to verify
    unless($noVerify) {
        return 0 if(!$self->verifyJobHash($jobInfo->{id}));
    }
    
    if(!exists($self->{jobH}->{$jobInfo->{id}})) {
        debug_lr(JMGR_DBG, "Job $jobInfo->{id} does not exists cant update\n");
        return 0;
    }

    $self->{jobH}->{$jobInfo->{id}} = $jobInfo;
    return 1;
}

sub getJobInfo {
    my $self = shift;
    my $jobID = shift;
    
    if(!exists($self->{jobH}->{$jobID})) {
        return undef;
    }
    return $self->{jobH}->{$jobID};
}

sub getJobXml {
    my $self = shift;
    my $id = shift;
    my $marketXml = shift;
    
    return "" if(!exists($self->{jobH}->{$id}));
    
    my $j = $self->{jobH}->{$id};
    my $str = "<$jobTag id=\"$id\">\n";
    
    # Placing only the tags supported by the market
    if($marketXml) {
        foreach my $mk (keys %$jobMarketFields) {
            next if($mk eq "id");
            if($jobMarketFields->{$mk} and !exists($j->{$mk})) {
                debug_lr(JMGR_DBG, "Error a mandatory market field $mk is not present in job $id\n");
                return undef;
            }
            
            # If the budget is 0 or less we dont send this process to the market
            if($mk eq $self->{f}->{"max-budget"} and exists($j->{$mk})) {
                return "" 
                  if($j->{$mk} <= 0 );
            }
            
            if(exists($j->{$mk})) {
                if(exists($jobFieldsFmt->{$mk})) {
                    $str .= sprintf("\t<$mk>". $jobFieldsFmt->{$mk} . "</$mk>\n", 
                                    $j->{$mk});
                }
                else {
                    $str .= "\t<$mk>$j->{$mk}</$mk>\n"
                }
            }
        }
    }
    # Placing all current tags in the xml
    else {
        foreach my $k (keys %$j) {
            next if($k eq "id");
            
            if(exists($jobFieldsFmt->{$k})) {
                $str .= sprintf("\t<$k>". $jobFieldsFmt->{$k} . "</$k>\n", 
                                $j->{$k});
            }
            else {
                $str .= "\t<$k>$j->{$k}</$k>\n";
            }
        }
    }
    
    $str .= "</$jobTag>\n";
    return $str;
}

sub getJobsXml {
    my $self = shift;
    my $marketXml = 0;
    $marketXml = shift
      if(@_);
        
    my $xmlStr = "<$jobListTag>\n";
    foreach my $j (keys %{$self->{jobH}}) {
        my $jStr = $self->getJobXml($j, $marketXml);
        $xmlStr .= $jStr;
    }
    $xmlStr .= "</$jobListTag>\n";
    return $xmlStr;
}

sub getJobsMarketXml {
    my $self = shift;
    return $self->getJobsXml(1);
}

sub getStatusStr {
    my $self = shift;
    my $str;

    $str .= sprintf("%-10s\t%-8s\t%-6s\t%-6s\t%-10s\n", 
                    "ID", "Status", "MaxPay", "CurrPay", "Where");
    foreach my $id (sort {$a <=> $b} (keys %{$self->{jobH}})) {
        my $jobH    = $self->{jobH}->{$id};
        my $maxPay  = $jobH->{$self->{f}->{"max-pay"}};
        my $status  = $jobH->{$self->{f}->{"status"}};
        my $where   = " - ";
        my $currPay = "0";
        if(exists($jobH->{$self->{f}->{where}})) {
            $where   =  $jobH->{$self->{f}->{where}};
            $currPay = $jobH->{$self->{f}->{"curr-pay"}};
        }
        $str .= sprintf("%-10s\t%-8s\t%-6.2f\t%-6.2f\t%-10s\n", 
                        $id, $status, $maxPay, $currPay, $where);
    }
    return $str;
}

sub setJobStatus {
    my $self = shift;
    my $job  = shift;
    my $status = shift;
    my $provider = shift;
    my $changed = shift;

    my $c = 0;
    return 0 
      if(!exists($self->{jobH}->{$job}));
   
    my $jobH = $self->{jobH}->{$job};
    
    # The status
    my $prevStatus = exists($jobH->{$self->{f}->{status}}) ? $jobH->{$self->{f}->{status}} : ""; 
    my $newStatus;
    # In case of a wating job, it remains in wait if new status is suspended.
    if($prevStatus eq JOB_WAIT_STAT and 
       $status eq JOB_SUSPEND_STAT) {
        $newStatus = JOB_WAIT_STAT;
    } else {
        $newStatus = $status;
    }
    #debug_lr(JMGR_DBG, "prevStat $prevStatus newStat $newStatus\n");
    $jobH->{$self->{f}->{status}} = $newStatus; 
    
    # If there was a change in the job status we update the statistics
    if($newStatus ne $prevStatus) {
        $c = 1;
        # Previous status is decremented if it is not the first time the job
        # added
        $self->{jobsAtState}->{$prevStatus} --
          if($self->{jobsAtState}->{$prevStatus});
        $self->{jobsAtState}->{$newStatus} ++;
    }
    
    # The where (or which provider should run this job)
    if($provider) {
        $c = 1
          if($jobH->{$self->{f}->{where}} ne $provider);
        $jobH->{$self->{f}->{where}} = $provider;
    }

    
    if($newStatus eq JOB_SUSPEND_STAT||
       $newStatus eq JOB_NO_BUDGET_STAT) 
      {
          $jobH->{$self->{f}->{where}}="";
          $jobH->{$self->{f}->{'curr-pay'}} = 0;
      }
    
    # Adding a log entry
    $self->addJobLogLine($job) if($c);

    $$changed = $c;
    return 1;
}


sub addJobLogLine {
    my $self = shift;
    my $id = shift;

    my $jh = $self->{jobH}->{$id};
    
    my $timeStr = time();
    my $status = $jh->{$self->{f}->{status}};
    my $logLine =  "$timeStr $id $status ";
    my $jobDetails = "";
    # First time the job was submitted
    if($status eq JOB_WAIT_STAT) {
        my $maxPay = $jh->{$self->{f}->{'max-pay'}};
        my $maxBudget = $jh->{$self->{f}->{'max-budget'}};
        my $from = $jh->{$self->{f}->{'from'}};
        
        $jobDetails = sprintf("%.2f %.2f $from ", $maxPay, $maxBudget);
    }
    elsif ($status eq JOB_RUN_STAT) {
        my $where = $jh->{$self->{f}->{'where'}};
        my $currPay = $jh->{$self->{f}->{'curr-pay'}};
        
        $jobDetails = sprintf("%.2f %s ",$currPay, $where);
    }
    

    $logLine .= $jobDetails . "\n";
    if(defined($self->{logFileHndl})) {
        print {$self->{logFileHndl}} $logLine;
    }
}

sub setJobPayment {
    my $self = shift;
    my $job  = shift;
    my $payment = shift;

    return 0 
      if(!exists($self->{jobH}->{$job}));
    
    my $jobH = $self->{jobH}->{$job};
    $jobH->{$self->{f}->{'curr-pay'}} = $payment; 
    return 1;
}

# It is possible to supply the currTime via a parameter. This is very usefull 
# for testings
sub updateTotalPay {
    my $self = shift;

    my $currTime;
    $currTime = $@ ? shift : time();

    my @noBudgetJobs = ();
    
    debug_lb(JMGR_DBG, "Updating total pay\n");

    foreach my $id ((keys %{$self->{jobH}})) {
        my $jh = $self->{jobH}->{$id};
        
        # The job is running 
        if($jh->{$self->{f}->{status}} eq JOB_RUN_STAT) {
            my $prevUpdate = $jh->{$self->{f}->{"prev-update"}};
            my $secRunning = $currTime - $prevUpdate;
            my $currPay = $jh->{$self->{f}->{"curr-pay"}};
            
            my $payAddition = ($currPay/3600)*$secRunning;
            $jh->{$self->{f}->{"total-pay"}} += $payAddition;
            debug_lg(JMGR_DBG, "Time $currTime $prevUpdate ($secRunning)\n");
            debug_lg(JMGR_DBG, "Adding $payAddition to job $id ($currPay $secRunning)\n");
            if(exists($jh->{$self->{f}->{"max-budget"}})) {

                $jh->{$self->{f}->{"max-budget"}} -= $payAddition;
                my $b = $jh->{$self->{f}->{"max-budget"}};
                debug_lg(JMGR_DBG, "Budget $b\n");
                
                # The job spent more than the budget !!!!!
                if($jh->{$self->{f}->{"max-budget"}} <= 0) {
                    my $c;
                    $self->setJobStatus($id, JOB_NO_BUDGET_STAT, "", \$c);
                    push @noBudgetJobs, $id;
                }
            }
        }
        $jh->{$self->{f}->{"prev-update"}} = $currTime;
    }
    return @noBudgetJobs;
}

sub foreachJob {
    my $self = shift;
    my $func = shift;
    my $data = shift;

    #print Dumper $self->{jobH};
    foreach my $j (keys %{$self->{jobH}}) {
     #   print "Doing $j\n";
        &{$func}($self->{jobH}->{$j}, $data);
    }
}

1;
