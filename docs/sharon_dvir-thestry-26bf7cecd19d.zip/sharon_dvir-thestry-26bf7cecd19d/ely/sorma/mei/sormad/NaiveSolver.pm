#  NaiveSolver $Id: NaiveSolver.pm,v 1.3 2007-01-10 11:47:33 lior Exp $ #  


#****c* sormad/NaiveSolver
# FUNCTION
# 
# The NaiveSolver object solve the market assignment problem in a simple naive
# way.

package sormad::NaiveSolver;


use strict;
use sormad::SormadParam;
use providerd::ProviderParam;
use XML::Simple;
use Data::Dumper;

use Util::Debug;

#****m* sormad/NaiveSolver->new
# FUNCTION
#   Constractor for the NaiveSolver object
# SYNOPSIS
#   $pvd = new NaiveSolver()
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to a NaiveSolver object on success
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    my %params = @_;
    
    bless($self, $class);

    $self->{jobsInfo} = {};
    $self->{providersInfo} = {};
    $self->{assignmenInfo} = {};
    $self->{assignmenInfoXml} = "";
    $self->{pricingInfoXml} = "";


    $self->setJobsInfo($params{jobsXml})
      if(exists($params{jobsXml}));

    $self->setProvidersInfo($params{providersXml})
      if(exists($params{providersXml}));

    return $self;
}

sub xmlToHash {
    my $self = shift;
    my $info = shift;
    
    if(! ref($info)) {
        debug_lg(NAIVE_DBG, "Got string converting to xml\n");
        
        my $h = eval { XMLin($info, 
                             ForceArray => [$jobTag, $providerTag],
                             KeyAttr => {$providerTag => "name",
                                         $jobTag => "id"} );};
        
        if($@) {
            debug_lr(NAIVE_DBG, "Error converting xml to hash\n$@\n");
            return 0;
        }
        #print Dumper($h);
        $info = $h;
    }
    return $info;
}


sub setJobsInfo {
    my $self = shift;
    my $jobsInfo = shift;
    
    my $h = $self->xmlToHash($jobsInfo);
    return 0 if(!$h);
    $self->{jobsInfo} = $h->{$jobTag};
    return 1;
}


sub setProvidersInfo {
    my $self = shift;
    my $providersInfo = shift;
    
    my $h = $self->xmlToHash($providersInfo);
    return 0 if(!$h);
    $self->{providersInfo} = $h->{$providerTag};
    return 1;
}



sub getAssignmentXml {
    my $self = shift;
    return $self->{assignmenInfoXml};
}

sub getPricingXml {
    my $self = shift;
    return $self->{pricingInfoXml};
}

sub getAssignmentInfo {
    my $self = shift;
    return $self->{assignmenInfo};
}

sub addRunAssignment {
    my $self = shift;
    my $job = shift;
    my $provider = shift;
    my $price = shift;
    
    $self->{assignmenInfo}->{$job}->{$statusTag} = JOB_RUN_STAT;
    $self->{assignmenInfo}->{$job}->{$providerTag} = $provider;
    $self->{assignmenInfo}->{$job}->{$priceTag} = $price;
}

sub addSuspendAssignment {
    my $self = shift;
    my $job = shift;
    
    $self->{assignmenInfo}->{$job}->{$statusTag} = JOB_SUSPEND_STAT;
}

sub sellProvider {
    my $self = shift;
    my $provider = shift;
    my $jobsLeft = shift;

    my $providerMinPrice = $self->{providersInfo}->{$provider}->{$minPriceTag};
    my $maxPrice = 0;
    my $secondMaxPrice = 0;
    my $winingJob = "";
    foreach my $j (keys %$jobsLeft) {

        my $jobMaxPay = $self->{jobsInfo}->{$j}->{$allJobFields->{'max-pay'}};

        next unless $jobMaxPay > $providerMinPrice;
        
        if($jobMaxPay > $maxPrice) {
            $winingJob = $j;
            $maxPrice = $jobMaxPay;
        }
        else {
            if($jobMaxPay > $secondMaxPrice) {
                $secondMaxPrice = $jobMaxPay;
            }
        }
    }
    $secondMaxPrice = $providerMinPrice
      if($secondMaxPrice <  $providerMinPrice);
    return ($winingJob, $secondMaxPrice);
}

sub produceAssignmentXml {
    my $self = shift;
    
    my $xml;
    $xml .= "<$allocationListTag>\n";
    foreach my $j (keys %{$self->{assignmenInfo}}) {
        my $status = $self->{assignmenInfo}->{$j}->{$statusTag};
        if($status eq JOB_RUN_STAT) {
            my $provider = $self->{assignmenInfo}->{$j}->{$providerTag};
            $xml .= "\t<$jobTag $allJobFields->{id}=\"$j\"  $statusTag=\"$status\" >\n";
            $xml .= "\t\t<$jobAllocationTag>\n";
            $xml .= "\t\t   <$providerTag>$provider</$providerTag>\n";
            $xml .= "\t\t</$jobAllocationTag>\n";
            $xml .= "\t</$jobTag>\n";
        } else {
            $xml .= "\t<$jobTag $allJobFields->{id}=\"$j\"  $statusTag=\"$status\"/>\n";
        }
        
    }
    $xml .= "</$allocationListTag>\n";

    $self->{assignmenInfoXml} = $xml;


}
    
sub solve {
    my $self = shift;
    
    debug_lb(NAIVE_DBG, "Solver Starting\n");
    if(!$self->{providersInfo} ||
       !$self->{jobsInfo}) {
        debug_lr(NAIVE_DBG, "Error jobInfo or providerInfo is not set\n");
        return 0;
    }
    
    
    # Sorting the providers by price
    my $pHash = $self->{providersInfo};
    my @pList = sort {
        $pHash->{$a}->{$minPriceTag} <=> $pHash->{$b}->{$minPriceTag} 
    }
      keys(%{$self->{providersInfo}} );
    debug_lg(NAIVE_DBG, "After sort @pList\n");

    # Selling the providers starting with the one with the lowest price
    my $jobsLeft = {};
    foreach my $j (keys(%{$self->{jobsInfo}})) {
        $jobsLeft->{$j} = 1;
    }
    
    foreach my $p (@pList) {
        my ($winingJob, $price) = $self->sellProvider($p, $jobsLeft);
        if($winingJob) {
            debug_lg(NAIVE_DBG, "Job $winingJob won provider $p\n");
            delete($jobsLeft->{$winingJob});
            $self->addRunAssignment($winingJob, $p, $price);
        }
        else {
            debug_ly(NAIVE_DBG, "No job won provider $p\n");
            
        }
    }
    
    foreach my $j (keys(%$jobsLeft)) {
        $self->addSuspendAssignment($j);
    }
    
    debug_lg(NAIVE_DBG, Dumper($self->{assignmenInfo}));
    $self->produceAssignmentXml();
    return 1;
}

1;
