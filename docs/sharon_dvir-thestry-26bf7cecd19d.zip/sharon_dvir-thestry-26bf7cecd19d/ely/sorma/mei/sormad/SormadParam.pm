
package sormad::SormadParam;

#use strict;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw( $sdAssigndPort $sdCtlPort
                  $sdConfFile
                  $confProvidersTag $confClusterTag 
                  $confExternalMarketTag $confSolverProgTag
                  $confStatusFileTag  $confLogFileTag

                  $mandatoryJobFields $additionalJobFields $allJobFields
                  $jobFieldsFmt
                  $ctlMsgTag $ctlTypeTag $ctlResultTag  $ctlResultErrorTag 

                  $ctlTypeSormadStatus $ctlTypeAssigndStatus $ctlTypeJobsStatus
                  $ctlTypeProvidersStatus $ctlTypeClustersStatus
                  $ctlTypeAddDebug  $ctlTypeRemoveDebug $ctlTypeListDebug
                  $ctlResultHeaderSize


                  $registerTag $registerTypeTag $registerTypeVal
                  $assigndListTag $assigndTag
                  $jobTag $jobStatusTag $jobAssignTag
                  $idTag $jobFinishedValue

                  $jobListTag $providerListTag $allocationListTag
                  $jobAllocationTag
                  $providerTag $statusTag $priceTag
                  
                  $jobMarketFields $providerMarketFields

                  $defaultInfodClientProg $defaultInfodClientTimeout
                  $clustersListTag $clusterTag $repTag 


                  EM_DEF_TMP_DIR 
                  EM_DEF_JOB_FILE 
                  EM_DEF_PROVIDER_FILE
                  EM_DEF_ASSIGNMENT_FILE
                  EM_DEF_PRICING_FILE 

                  $solverJobsFlag $solverProvidersFlag $solverAssignmentFlag
                  $solverPricingFlag
);

# The default port of the provider daemon
$sdAssigndPort = "9004";
$sdCtlPort     = "9006";

# Sormad configuration file
$sdConfFile            = "/etc/mosix/sormad.conf";

$confProvidersTag      = "providers";
$confClusterTag        = "cluster";

$confExternalMarketTag = "external-market";
$confSolverProgTag     = "solver-program";
$confStatusFileTag     = "status-file";
$confLogFileTag        = "log-file";

####### Ctl part #######
$ctlMsgTag         = "ctl";
$ctlTypeTag        = "type";
$ctlResultTag      = "ctl-result";
$ctlResultErrorTag = "error";

# Ctl types
#
# <ctl type="status"></ctl>
#

$ctlTypeSormadStatus      = "status";
$ctlTypeAssigndStatus     = "assignd-status";
$ctlTypeJobsStatus        = "jobs-status";
$ctlTypeProvidersStatus   = "providers-status";
$ctlTypeClustersStatus    = "clusters-status";
$ctlTypeAddDebug          = "add-debug";
$ctlTypeRemoveDebug       = "remove-debug";
$ctlTypeListDebug         = "list-debug";


# When sending a ctl response the size of the response may be very large.
# Due to that we first send a short header containing the size of the data.
# The size of the header is described in the above variable
$ctlResultHeaderSize    = 40;

# ###### Assignd Part #######
# $registerTag     = "client";
# $registerTypeTag = "type";
# $registerTypeVal = "assignd";

# $assigndListTag  = "assignds";
# $assigndTag      = "assignd";

# $jobTag          = "job";
# $jobStatusTag    = "job-status";
# $jobAssignTag    = "assign-job";


# ####### Job fields and tags #####
# $mandatoryJobFields = {
#                        'id'           => "id",
#                        'max-pay'      => "max-pay",
#                        'from'         => "from",
#                       };

# $additionalJobFields = {
#                         'cpu-num'     => "cpu-num",
#                         'user'        => "user",
#                         'max-budget'  => "max-budget",
#                         'mem'         => "mem",
#                         'finish'      => "finish",
#                         'where'       => "where",
#                         'status'      => "status",
#                         'curr-pay'    => "curr-pay",
#                         'total-pay'   => "total-pay",
#                         'prev-update' => "prev-update",
#                         'uid'         => "uid",
#                        };

# $allJobFields = {
#                  %$mandatoryJobFields,
#                  %$additionalJobFields,
#                 };


# $jobFieldsFmt = {
#                  'max-pay'      => "%.4f",
#                  'max-budget'   => "%.4f",
#                  'mem'          => "%.2f",
#                  'curr-pay'     => "%.4f",
#                  'total-pay'    => "%.4f",
# };

# $idTag = "id";
# $jobFinishedValue = "finished";

# $statusTag   = "status";
# $priceTag    = "price";

###### Market part ########
$jobListTag        = "submissions";
$providerListTag   = "providers";
$providerTag       = "provider";
$allocationListTag = "allocations";
$jobAllocationTag  = "allocation";


### Jobs statuses
# use constant  'JOB_WAIT_STAT'     => "wait";
# use constant  'JOB_RUN_STAT'      => "run";
# use constant  'JOB_SUSPEND_STAT'  => "suspend";
# use constant  'JOB_NO_BUDGET_STAT'=> "no budget";
# use constant  'JOB_ABORT_STAT'    => "abort";
# use constant  'JOB_FINISH_STAT'   => "finish";


### Solver Arguments
$solverJobsFlag        = "--jobs";
$solverProvidersFlag   = "--providers";
$solverAssignmentFlag  = "--assignment";
$solverPricingFlag     = "--pricing";

$jobMarketFields = { 
                    "id"          => 1,
                    "max-pay"     => 1,
                    "user"        => 1, 
                    "cpu-num"     => 1,
                    "max-budget"  => 0,
                    "mem"         => 0,
                   };

use providerd::ProviderParam;
$providerMarketFields = {
                         "name"    => 1,
                         "IP"      => 1,
                         "$minPriceTag"  => 1,
                         "cpu-num" => 1,
                         "mem"     => 0,
                        };

###### External Market #####

use constant  'EM_DEF_TMP_DIR'          => "/tmp";
use constant  'EM_DEF_JOB_FILE'         => "externalMarket-jobs.xml";
use constant  'EM_DEF_PROVIDER_FILE'    => "externalMarket-providers.xml";
use constant  'EM_DEF_ASSIGNMENT_FILE'  => "externalMarket-assignment.xml";
use constant  'EM_DEF_PRICING_FILE'     => "externalMarket-pricing.xml";


###### Provider Part ######
# $defaultInfodClientProg     = "infod-client";
# $defaultInfodClientTimeout  = "4";

# $clustersListTag      = "clusters";
# $clusterTag           = "cluster";
# $repTag               = "rep";


1;
