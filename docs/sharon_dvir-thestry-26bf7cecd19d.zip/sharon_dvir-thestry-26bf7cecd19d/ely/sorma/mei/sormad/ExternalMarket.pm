#  ExternalMarket $Id: ExternalMarket.pm,v 1.4 2007-01-14 16:56:10 lior Exp $ #  


#****c* sormad/ExternalMarket
# FUNCTION
# 
# The ExternalMarket package runs an external program which performs the 
# market calculations.

package sormad::ExternalMarket;


use strict;
use Data::Dumper;
use sormad::SormadParam;
use sormad::MarketManager;
use Util::Debug;


use vars qw(@ISA);

@ISA = qw(sormad::MarketManager);



#****m* sormad/ExternalMarket->new
# FUNCTION
#   Constractor for the ExternalMarket object
# SYNOPSIS
#   $pvd = new ExternalMarket(
#             market_prog   => "The path to the external marekt
#             tmp_dir       => "Temporary directory to use"               
#                       );
# ARGUMENTS
#   market_prog      The market program to use
#   tmp_dir          Where to write jobs+provider files
# RETURN VALUE
#  undef    On error
#  A reference to an ExternalMarket object on success
#******
sub new {

    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    my %params = @_;
    
    
    if ( !exists($params{market_prog}) ) {
        debug_lr(MMGR_DBG, "Error no market_prog argument was given\n");
        return undef;
    }
    $self->{marketProg} = $params{market_prog};
    $self->{marketVersionStr} = "";
    
    # Additional flags to the market program when running the market
    $self->{runMarketFlags} = 
      exists($params{run_market_flags}) ? $params{run_market_flags} : "";
    
    # Flags to use when querying the market solver for version
    $self->{versionFlags} = 
      exists($params{version_flags}) ? $params{version_flags} : "--version";

        
    
    # Setting the external program flags
    $self->{jobsFlag} = 
      exists($params{jobs_flag}) ? $params{jobs_flag} : $solverJobsFlag;
    $self->{providersFlag} = 
      exists($params{providers_flag}) ? $params{providers_flag} : $solverProvidersFlag;
    $self->{assignmentFlag} = 
      exists($params{assignment_flag}) ? $params{assignment_flag} : $solverAssignmentFlag;
    $self->{pricingFlag} = 
      exists($params{pricing_flag}) ? $params{pricing_flag} : $solverPricingFlag;

    # Setting the external files to use
    $self->{tmpDir} = 
      exists($params{tmp_dir}) ? $params{tmp_dir} : EM_DEF_TMP_DIR;
    
    $self->{tmpDir} .= "/";
    $self->{jobsFile} = $self->{tmpDir} .
      (exists($params{jobs_file}) ? $params{jobs_file} : EM_DEF_JOB_FILE);
    $self->{providersFile} = $self->{tmpDir} .
      (exists($params{providers_file}) ? $params{providers_file} : EM_DEF_PROVIDER_FILE);
    $self->{assignmentFile} = $self->{tmpDir} .
      (exists($params{assignment_file}) ? $params{assignment_file} : EM_DEF_ASSIGNMENT_FILE);
    $self->{pricingFile} = $self->{tmpDir} .
      (exists($params{pricing_file}) ? $params{pricing_file} : EM_DEF_PRICING_FILE);
    


    # !!!! Note:  The base class performs the fork so all variables 
    # ($self->{xxx} declared after will not be present in both processes.
    $self = $class->SUPER::new(%$self);
    return undef if(!defined($self));
    
    # Getting the version (done in the main process not in the worker)
    return undef if(!$self->obtainSolverVersion());
    
    debug_lb(MMGR_DBG, "External: finished new() $self->{tmpDir}\n");
    #print Dumper($self);
    return $self;
}				   

sub DESTROY {
    my $self = shift;
    
    $self->SUPER::DESTROY();

    # Removing external files
    unlink $self->{jobsFile}, $self->{providersFile}, $self->{assignmentFile},
      $self->{pricingFile};
}

sub prepareInputFiles {
    my $self = shift;

    debug_lb(MMGR_DBG, "Preparing input files $self->{tmpDir}\n");
    if(!open(TMP_JOBS, ">$self->{jobsFile}")) {
        debug_lr(MMGR_DBG, "Error opening jobsFile: $self->{jobsFile} : $!\n");
        return 0;
    }
    if(!open(TMP_PROVIDERS, ">$self->{providersFile}")) {
        debug_lr(MMGR_DBG, "Error opening providersFile: $self->{providersFile} : $!\n");
        close TMP_JOBS;
        return 0;
    }
    
    print TMP_JOBS $self->{jobsXml};
    print TMP_PROVIDERS $self->{providersXml};
    close TMP_JOBS;
    close TMP_PROVIDERS;
    return 1;
}

sub readResultFiles {
    my $self = shift;
    
    if(!open(IN, "$self->{assignmentFile}")) {
        debug_lr(MMGR_DBG, "Error reading assignmentFile $self->{assignmentFile} : $!\n");
        $self->setResultError("reading assignment file $self->{assignmentFile}");
        return 0;
    }
    my @in = <IN>;
    
    $self->{resultAssignmentXml} = join '', @in;
    close IN;
    
    if(!open(IN, "$self->{pricingFile}")) {
        debug_lr(MMGR_DBG, "Error reading pricingFile $self->{pricingFile} : $!\n");
        $self->setResultError("reading assignment file $self->{pricingFile}");
        return 0;
    }
    
    @in = ();
    @in = <IN>;
    
    $self->{resultPricingXml} = join '', @in;
    close IN;
    
    return 1;
}

sub workerRunMarket {
    my $self = shift;
    
    debug_lb(MMGR_DBG, "External market workerRunMarket\n");
    
    # Writing the input files to the market
    if(!$self->prepareInputFiles()) {
        $self->setResultError("preparing solver input files");
        return 0;
    }
    
    my @cmd;
    push @cmd, split /\s+/, $self->{marketProg};
    push @cmd, split /\s+/, $self->{runMarketFlags};
    push @cmd, "$self->{jobsFlag}", "$self->{jobsFile}";
    push @cmd, "$self->{providersFlag}", "$self->{providersFile}";
    push @cmd, "$self->{assignmentFlag}",  "$self->{assignmentFile}";
    push @cmd, "$self->{pricingFlag}", "$self->{pricingFile}";
    
    push @cmd, "--debug"
      if(isDebugLevelOn(MMGR_DBG));
    
    debug_lg(MMGR_DBG, "External command:\n@cmd\n");
    system(@cmd);
    if($? == -1) {
        debug_lr(MMGR_DBG, "Failed to execute external program: $!\n");
        $self->setResultError("running solver");
        return 0;
    }
    elsif ($? & 127) {
        my $err = sprintf("program died with signal %d, %s coredump",
                          ($? & 127),  ($? & 128) ? 'with' : 'without');
        debug_lr(MMGR_DBG, $err);
        $self->setResultError($err);
        return 0;
    }
    else {
        my $progExitVal = $? >> 8;
        debug_lg("Program exited with $progExitVal\n");
        $self->setResultError("Program exited with $progExitVal");
        return 0 if($progExitVal != 0);
    }
    # At this point program finished with exit status 0
    $self->readResultFiles();
    return 1;
}

sub obtainSolverVersion {
    my $self = shift;
    
    my $cmd = "$self->{marketProg} $self->{versionFlags} ";
    debug_lb(MMGR_DBG, "External obtain solver version: $cmd\n");
    my $out = `$cmd`;
 
    if($? == -1) {
        debug_lr(MMGR_DBG, "Failed to execute external program: $!\n");
        $self->setResultError("geting solver version");
        return 0;
    }
    elsif ($? & 127) {
        my $err = sprintf("program died with signal %d, %s coredump",
                          ($? & 127),  ($? & 128) ? 'with' : 'without');
        debug_lr(MMGR_DBG, $err);
        $self->setResultError($err);
        return 0;
    }
    else {
        my $progExitVal = $? >> 8;
        debug_lg("Program exited with $progExitVal\n");
        $self->setResultError("Program exited with $progExitVal");
        return 0 if($progExitVal != 0);
    }
    chomp($out);
    $self->{marketVersionStr} = $out;
    #print "Got out $out res: $?\n";
    debug_lg(MMGR_DBG, "Solver version: $self->{marketVersionStr}\n");
    return 1;
}

sub getSolverVersion {
    my $self = shift;
    
    return $self->{marketVersionStr};
}

1;
