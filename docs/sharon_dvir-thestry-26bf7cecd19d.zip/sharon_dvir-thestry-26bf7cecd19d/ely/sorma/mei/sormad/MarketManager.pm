#  MarketManager $Id: MarketManager.pm,v 1.4 2007-01-14 16:56:11 lior Exp $ #  


#****c* sormad/MarketManager
# FUNCTION
# 
# The MarketManager object is responsible for running the market object and
# monitoring it during its run. The MarketManager should not block.

package sormad::MarketManager;

use strict;
use sormad::SormadParam;
use Util::Debug;

use Socket;
use IO::Handle;     # thousands of lines just for autoflush :-(
use IO::Select;
use IO::Socket;
#use Data::Dumper;
use Config;
defined $Config{sig_name} || die "No sigs?";

############# Functions declarations ##########################

sub new;
sub runMarket;
sub getMarketStatus;
sub getAssignmentXml;
sub getMarketFH;
sub isMarketFH;
sub handleMarketMsg;
sub getComputeTime;
sub getSolverName;
sub getSolverVersion;


require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw( 
   MARKET_STAT_NOT_READY
   MARKET_STAT_READY
   MARKET_STAT_RUNNING
   MARKET_STAT_ERROR
);		

############ Defines and globals ##############################
use constant MARKET_STAT_NOT_READY  => "NotReady";
use constant MARKET_STAT_READY      => "Ready";
use constant MARKET_STAT_RUNNING    => "Running";
use constant MARKET_STAT_ERROR      => "Error"; 
   

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };
    
    $self->{marketStatus} = MARKET_STAT_NOT_READY;
    bless($self, $class);

    # Set signal names 

    my $i=0;
    my @signame;
    foreach my $name (split(' ', $Config{sig_name})) {
        $self->{signo}->{$name} = $i;
        $i++;
    }
    
    $self->{isWorker} = 0;
    $self->{isManager} = 1;

    $self->{assignmentXml} = "";
    $self->{pricingXml} = "";
    $self->{jobsXml} = "";
    $self->{providersXml} ="";

    $self->{errorXml} = "";
    $self->{resultAssignmentXml} = "";
    $self->{resultPricingXml} = "";
    
    $self->{marketComputeTime} = 0;
    return undef if(!$self->initWorkerProcess());

    $self->{marketStatus} = MARKET_STAT_READY;
   
    return $self;
}

sub DESTROY {
    my $self = shift;

    #print STDERR "In destory\n";
    #debug_lb(MMGR_DBG, "In destructor\n");
    if($self->{isManager}) {
        kill $self->{signo}->{INT}, $self->{workerPid};
    }
}
    

sub initWorkerProcess {
    my $self = shift;

    if(!socketpair($self->{workerFH}, $self->{parentFH}, AF_UNIX, SOCK_STREAM, PF_UNSPEC)) {
        debug_lr(MMGR_DBG, "Error creating socketpair: $!\n");
        return 0;
    };
        
    $self->{workerFH}->autoflush(1);
    $self->{parentFH}->autoflush(1);
    
    my $pid;
    my $line;
    
    # Manager part
    if ($pid = fork) {
        close $self->{parentFH};
        #print {$self->{workerFH}}  "Parent Pid $$ is sending this\n";
        #$line = $self->{workerFH}->getline();
        #chomp($line);
        #print "Parent Pid $$ just read this: `$line'\n";
        $self->{workerPid} = $pid;
        return 1;
    } 
    # Worker (child) part
    else {
        unless(defined $pid) {
            debug_lr(MMGR_DBG, "Error while forking worker\n");
            return 0;
        }
        $self->{isWorker} = 1;
        $self->{isManager} = 0;
        close $self->{workerFH};
        $self->workerLoop();
        exit;
    }
    
}

sub getMarketStatus {
    my $self = shift;
    return $self->{marketStatus};
}

# Returning the market cumputation time in seconds
sub getComputeTime {
    my $self = shift;
    return $self->{marketComputeTime};
}

sub getSolverName {
    my $self = shift;
    return "JMarket";
}

sub getSolverVersion {
    my $self = shift;
    return "un-implemented";
}

sub getMarketFH {
    my $self = shift;
    return undef if($self->{isWorker});
    return $self->{workerFH};
}

sub isMarketFH {
    my $self = shift;
    my $fh = shift;

    return undef if($self->{isWorker});
    
    return 1 if($self->{workerFH} == $fh);
    return 0;
}

sub getAssignmentXml {
    my $self = shift;

    if($self->{marketStatus} ne MARKET_STAT_READY) {
        return undef;
    }
    return $self->{assignmentXml};
}

sub getPricingXml {
    my $self = shift;
    
    if($self->{marketStatus} ne MARKET_STAT_READY) {
        return undef;
    }
    return $self->{pricingXml};
}

sub runMarket {
    my $self = shift;
    my $jobsXml = shift;
    my $providersXml = shift;

    my $pLen = length($providersXml);
    my $jLen = length($jobsXml);
    my $len = $pLen + $jLen;
    
    debug_lb(MMGR_DBG, "Manager: Running market len $len\n");
    print {$self->{workerFH}} $jLen."  ".$pLen."\n";
    $self->{workerFH}->write($jobsXml, $jLen);
    $self->{workerFH}->write($providersXml, $pLen);
    $self->{marketStatus} = MARKET_STAT_RUNNING;
    $self->{startTime} = time();
    return 1;
}


sub handleMarketMsg {
    my $self = shift;
    
    debug_lb(MMGR_DBG, "Manager reading data from worker\n");
    my $hdr = $self->{workerFH}->getline();
    chomp($hdr);
    
    if(!$hdr) { 
        debug_lr(MMGR_DBG, "Error reading header\n");
        return 0;
    }
    
    my $assignmentLen;
    my $pricingLen;
    if(! ($hdr =~ /\s*(\w+)\s+(\d+)\s+(\d+)\s*/)) {
        debug_lr(MMGR_DBG, "Error parsing header ($hdr)\n");
        return 0;
    }
    my $workerStatus = $1;
    my $len1 = $2;
    my $len2 = $3;

    if($workerStatus eq MARKET_STAT_READY) {
        
        $assignmentLen = $len1;
        $pricingLen = $len2;
        my $assignmentXml = "";
        my $pricingXml = "";
        
        if($assignmentLen > 0) {
            my $res = $self->{workerFH}->read($assignmentXml, $assignmentLen);
        }
        
        if($pricingLen > 0) {
            my $res = $self->{workerFH}->read($pricingXml, $pricingLen);
        }
        
        
        debug_lg(MMGR_DBG, "XML: $assignmentXml\n$pricingXml");
        $self->{marketStatus} = MARKET_STAT_READY;
        $self->{assignmentXml} = $assignmentXml;
        $self->{pricingXml} = $pricingXml;
        
        my $currTime = time();
        $self->{marketComputeTime} = $currTime - $self->{startTime};

    } 
    else {
        $self->{marketStatus} = MARKET_STAT_ERROR;
        my $errorXml; 
        my $res = $self->{workerFH}->read($errorXml, $len1);
        $self->{marketErrorXml} = $errorXml;
        debug_lr(MMGR_DBG, $errorXml);
    }
    
    debug_ly(MMGR_DBG, "Worker $workerStatus $len1 $len2\n");
    return 1;
}


sub setResultError {
    my $self = shift;
    my $err  = shift;

    $self->{errorXml} = "<error>$err</error>";
}

sub workerClearResults {
    my $self = shift;

    $self->{resultAssignmentXml} = "";
    $self->{resultPricingXml} = "";
}

sub workerReadData {
    my $self = shift;
    my $res;

    debug_lb(MMGR_DBG, "Worker reading data\n");
    my $hdr = $self->{parentFH}->getline();
    chomp($hdr);
    
    my ($jLen, $pLen);
    if(! ($hdr =~ /\s*(\d+)\s+(\d+)/)) {
        debug_lr(MMGR_DBG, "Error parsing header ($hdr)\n");
        return 0;
    }
    $jLen = $1;
    $pLen = $2;

    my ($jobsXml, $providersXml);
    $res = $self->{parentFH}->read($jobsXml, $jLen);
    $res = $self->{parentFH}->read($providersXml, $pLen);
    
    debug_lg(MMGR_DBG, "XML: $jobsXml\n$providersXml");
    $self->{jobsXml} = $jobsXml;
    $self->{providersXml} = $providersXml;
    return 1;
}

# Possibly the only function that should be overide
sub workerRunMarket {
    my $self = shift;



    return 1;

}

sub workerReportResults {
    my $self = shift;
    
    my $hdr;
    if($self->{workerRunStatus} eq MARKET_STAT_READY) { 
        my $resultAssignmentLen = length($self->{resultAssignmentXml});
        my $resultPricingLen = length($self->{resultPricingXml});

        
        $hdr = "$self->{workerRunStatus} $resultAssignmentLen $resultPricingLen\n";
    
        print {$self->{parentFH}} $hdr;
        if($resultAssignmentLen > 0) {
            $self->{parentFH}->write($self->{resultAssignmentXml}, $resultAssignmentLen);
        }
        if($resultPricingLen > 0) {
            $self->{parentFH}->write($self->{resultPricingXml}, $resultPricingLen);
        }
    }
    # Case of error
    else {
        my $errorStrLen = length($self->{errorXml});
        $hdr = MARKET_STAT_ERROR." $errorStrLen 0\n";
        print {$self->{parentFH}} $hdr;
        $self->{parentFH}->write($self->{errorXml}, $errorStrLen);
    }
    
    return 1;
}

sub workerLoop {
    my $self = shift;
    my $line;
    
    debug_lb(MMGR_DBG, "Worker: Starting loop\n");
    #$line = $self->{parentFH}->getline();
    #chomp($line);
    #print "Child Pid $$ just read this: `$line'\n";
    #print {$self->{parentFH}} "Child Pid $$ is sending this\n";
    $self->{ppid} = getppid();
    
    my $sel = new IO::Select( $self->{parentFH} );
    my $res;
    while(1) {
        my @ready =  $sel->can_read();
        foreach my $f (@ready) {
            if($f == $self->{parentFH}) {

                # Reading the first line
                $self->workerReadData();
                $self->workerClearResults();
                $res = $self->workerRunMarket();
                # The workerRunStatus indicate if there was an error during run
                $self->{workerRunStatus} = $res ? MARKET_STAT_READY : MARKET_STAT_ERROR;
                $self->workerReportResults();
                #  print @lines;
            }
        }
    }
}

1;

