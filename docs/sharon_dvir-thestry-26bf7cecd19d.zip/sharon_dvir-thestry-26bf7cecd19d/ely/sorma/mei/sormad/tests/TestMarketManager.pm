#!/usr/bin/perl -w

package TestMarketManager;

use base qw(Test::Unit::TestCase);

use strict;

use sormad::MarketManager;
use sormad::SormadParam;
use providerd::ProviderParam;
use Util::Debug;
use Data::Compare;
use Data::Dumper;
use XML::Simple;

sub new {
    my $self = shift()->SUPER::new(@_);
    # your state for fixture here
    return $self;
}

my $jobsXml_1 = "
<$jobListTag>
<job id=\"1\">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay> 10.2 </max-pay>
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from>11.11.11.11</from>
</job>
<job id=\"2\">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay> 10.2 </max-pay>
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from> 11.11.11.11</from>
</job>
<job id=\"3\">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay> 10.2 </max-pay>
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from>11.11.11.11</from>
</job>
</$jobListTag>
";

my $providersXml_1 = "
<$providerListTag>
<$providerTag name=\"sorma1\">
  <mem>1000</mem>
  <$minPriceTag>10</$minPriceTag>
  <IP>1.1.1.1<IP>
</$providerTag>

<$providerTag name=\"sorma2\">
  <mem>1000</mem>
  <$minPriceTag>10</$minPriceTag>
  <IP>1.1.1.2<IP>
</$providerTag>

</$providerListTag>
";



sub test_market {
    my $self = shift;
    my $res;

    #addDebugLevel(MMGR_DBG);
    debug_lg(MMGR_DBG, "\n");
    
    
    my $mm = new sormad::MarketManager();
    $self->assert_not_null($mm, "Unable to create MarketManager object");
    
    $mm->runMarket($jobsXml_1, $providersXml_1);
    my $stat = $mm->getMarketStatus();
    $self->assert($stat eq MARKET_STAT_RUNNING, "Market status is not correct");
    
    my $sel = new IO::Select( $mm->getMarketFH() );
    
    my @ready =  $sel->can_read();
    
    if($mm->isMarketFH($ready[0])) {
        $res = $mm->handleMarketMsg();
        $self->assert($res, "Failed to handle message on market fh");
    }
    else {
        $self->assert(0, "Problem with the select");
    }
    $stat = $mm->getMarketStatus();
    $self->assert($stat eq MARKET_STAT_READY, "Market status is not correct");
    
    
    clearDebugLevel();
}
