#!/usr/bin/perl -w

package TestJobManager;

use base qw(Test::Unit::TestCase);

use strict;

use sormad::JobManager;
use sormad::SormadParam;
use Util::Debug;
use Data::Compare;
use Data::Dumper;
use XML::Simple;

sub new {
    my $self = shift()->SUPER::new(@_);
    # your state for fixture here
    return $self;
}

my $jobXml_1 = '
<job id="1">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay> 100 </max-pay>
        <max-budget> 10 </max-budget>
        <where> 11.22.33.44 </where> 
        <curr-pay>10</curr-pay>
        <from>11.11.11.11</from>
</job>
';


my $jobXml_2 = '
<job id="2">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay>100</max-pay>
        <max-budget> 100</max-budget>
        <where> 11.22.33.44 </where> 
        <curr-pay>10</curr-pay>
        <from> 11.11.11.11</from>
</job>
';

my $jobXml_3 = '
<job id="3">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay>100 </max-pay>
        <max-budget>1000 </max-budget>
        <curr-pay>10</curr-pay>
        <from>11.11.11.11</from>
</job>
';


sub test_addJob {
    my $self = shift;
    
    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
    
    # ContentKey=>"content",
    # 'KeyAttr' => {'job'=> "id"}
    # ForceArray => 1 ,
    my $jobH = XMLin($jobXml_1,  'KeyAttr' => 'id');
    debug_ly(JMGR_DBG, "Got job:\n", Dumper([$jobH], ["job"]));
    
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    
    my $res = $jm->addJob($jobH);
    $self->assert($res, "Failed adding job");
    
    $res = $jm->getTotalJobNum();
    $self->assert($res == 1, "Job number should be 1");
    
    $res = $jm->addJob($jobXml_1);
    $self->assert($res, "Failed adding job again");
    
    $res = $jm->getTotalJobNum();
    $self->assert($res == 1, "Job number should be 1");

    $res = $jm->addJob($jobXml_2);
    $self->assert($res, "Failed adding job 2");
    
    $res = $jm->addJob($jobXml_3);
    $self->assert($res, "Failed adding job 3");
    
    $res = $jm->getTotalJobNum();
    $self->assert($res == 3, "Job number should be 3");
    clearDebugLevel();
}


sub test_removeJob {
    my $self = shift;
    
    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    
    $jm->addJob($jobXml_1);
    $jm->addJob($jobXml_2);
    $jm->addJob($jobXml_3);
    
    my $res = $jm->removeJob(1);
    $self->assert($res, "Failed removing job 1");
    
    $res = $jm->getTotalJobNum();
    $self->assert($res == 2, "Job number should be 2");
    
    $res = $jm->removeJob(1);
    $self->assert($res == 0, "Error removing job 1 (which was already removed)");
    
    
    $res = $jm->removeJob(2);
    $self->assert($res, "Failed removing job 2");
    $res = $jm->removeJob(3);
    $self->assert($res, "Failed removing job 3");
    $res = $jm->getTotalJobNum();
    $self->assert($res == 0, "Job number should be 0");
    
    clearDebugLevel();
}


sub test_removeJobByNode {
    my $self = shift;
    my $res;
  
    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    
    $jm->addJob($jobXml_1);
    $jm->addJob($jobXml_2);
    $jm->addJob($jobXml_3);
    
    $res = $jm->removeJobsByNode("11.11.11.11");
    $self->assert($res != 0, "Failed to remove all jobs of node 11.11.11.11");
    
    $res = $jm->getTotalJobNum();
    $self->assert($res == 0, "After removal by node, job number should be 0");
    
    clearDebugLevel();
}

# No max-pay
my $illegalXml_1 = '
<job id="3">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from>11.11.11.11</from>
</job>
';

# No id 
my $illegalXml_2 = '
<job >
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from>11.11.11.11</from>
</job>
';

# No id 
my $illegalXml_3 = '
<job >
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from>11.11.11.11</from>
</job>
';


sub test_illegalJobs {
    my $self = shift;
    
    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    
    my $res = $jm->addJob($illegalXml_1);
    $self->assert($res == 0, "Ilegal xml1 as accepted");
    
    $res = $jm->addJob($illegalXml_2);
    $self->assert($res == 0, "Ilegal xml2 as accepted");
    
    $res = $jm->addJob($illegalXml_3);
    $self->assert($res == 0, "Ilegal xml3 as accepted");

    
    clearDebugLevel();

}



sub test_getJobXml {
    my $self = shift;
    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
 
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    my $res;
    $res = $jm->addJob($jobXml_1);
    $res = $jm->addJob($jobXml_2);
    $res = $jm->addJob($jobXml_3);
    
    my $str = $jm->getJobsXml();
    my $jobH =  eval { XMLin($str, KeyAttr => 'id'); };

    if(isDebugOn()) {
        print "Xml: $str\n";
        #print "Result:", Dumper($jobH);
    }
    
    $self->assert(!$@, "Error parsing the getJobsXml back to hash");

    
    $str = $jm->getJobsXml(1);
    $jobH =  eval { XMLin($str, ForceArray => [$jobTag], KeyAttr => {$jobTag => "id"}); };

    if(isDebugOn()) {
        print "XmlMarket:\n$str\n";
        print "Result:", Dumper($jobH);
    }
    
    $self->assert(!$@, "Error parsing the getJobsXml back to hash");
    clearDebugLevel();
}


my $jobXml_new_1 = '
<job id="1">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay> 10.2 </max-pay>
        <max-budget> 100.3 </max-budget>
        <from>11.11.11.11</from>
</job>
';


sub test_setJobStatus {
    my $self = shift;

    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    my $res;
    $res = $jm->addJob($jobXml_new_1);
    
    my $c;
    $res = $jm->setJobStatus(1, JOB_SUSPEND_STAT, "", \$c);
    $self->assert($res, "Result of setJobStatus is $res");
    $self->assert($c == 0, "$c A waiting job moved to suspend should not change");
    clearDebugLevel();
}


sub test_getJobsAtState {
    my $self = shift;
    
    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    my $res;
    $res = $jm->addJob($jobXml_1);
    $res = $jm->addJob($jobXml_2);
    $res = $jm->addJob($jobXml_3);
    
    my $c;
    $res = $jm->setJobStatus(1, JOB_RUN_STAT, "a1", \$c);
    $res = $jm->setJobStatus(2, JOB_RUN_STAT, "a2", \$c);
    $res = $jm->setJobStatus(3, JOB_WAIT_STAT, "a3", \$c);
    
    
    $res = $jm->getTotalJobNum();
    $self->assert($res == 3, "Total number of jobs is not 3\n");
    
    $res = $jm->getJobsAtState(JOB_WAIT_STAT);
    $self->assert($res == 1, "Number of WAITING jobs is not 1\n");
    $res = $jm->getJobsAtState(JOB_RUN_STAT);
    $self->assert($res == 2, "Number of RUNNING jobs is not 2 ($res)\n");
    

    $res = $jm->setJobStatus(3, JOB_RUN_STAT, "a3", \$c);
    $res = $jm->setJobStatus(2, JOB_SUSPEND_STAT, "a2", \$c);
    
    $res = $jm->getJobsAtState(JOB_WAIT_STAT);
    $self->assert($res == 0, "Number of WAITING jobs is not 0\n");
    $res = $jm->getJobsAtState(JOB_RUN_STAT);
    $self->assert($res == 2, "Number of RUNNING jobs is not 2 ($res)\n");
    
    $res = $jm->removeJob(1);
    $res = $jm->getJobsAtState(JOB_WAIT_STAT);
    $self->assert($res == 0, "Number of WAITING jobs is not 0\n");
    $res = $jm->getJobsAtState(JOB_RUN_STAT);
    $self->assert($res == 1, "Number of RUNNING jobs is not 1 ($res)\n");
    

    clearDebugLevel();
}

sub countJobsFunc {
    my $jh = shift;
    my $data = shift;
    
 #   print "Counting $jh->{user}\n";
    $$data++;
}
sub test_foreachJob {
    my $self = shift;

    #addDebugLevel(JMGR_DBG);
    debug_lg(JMGR_DBG, "\n");
    
    my $jm = new sormad::JobManager();
    $self->assert_not_null($jm, "Unable to create JobManager object");
    my $res;
    $res = $jm->addJob($jobXml_1);
    $res = $jm->addJob($jobXml_2);
    $res = $jm->addJob($jobXml_3);
    
    my $n;
    $jm->foreachJob(\&countJobsFunc, \$n);
    $self->assert($n == 3, "After counting job with foreachJob $n!=3");
}

1;

package main;

use Test::Unit::TestRunner;

my $testrunner = Test::Unit::TestRunner->new();
$testrunner->start("TestJobManager");
