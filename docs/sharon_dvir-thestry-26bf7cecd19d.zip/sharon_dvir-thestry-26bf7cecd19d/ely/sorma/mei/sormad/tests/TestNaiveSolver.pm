#!/usr/bin/perl -w

package TestNaiveSolver;

use base qw(Test::Unit::TestCase);

use strict;

use sormad::NaiveSolver;
use sormad::SormadParam;
use providerd::ProviderParam;
use Util::Debug;

sub new {
    my $self = shift()->SUPER::new(@_);
    # your state for fixture here
    return $self;
}

my $jobsXml_1 = "
<$jobListTag>
<job id=\"1\">
        <mem> 1234MB </mem>                             
        <finish> 10.5 </finish>                         
        <max-pay> 15 </max-pay>
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from>11.11.11.11</from>
</job>
<job id=\"2\">
        <mem> 1234MB </mem>                             
        <finish> 12 </finish>                         
        <max-pay> 13 </max-pay>
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from> 11.11.11.11</from>
</job>
<job id=\"3\">
        <mem> 1234MB </mem>                             
        <finish> 11 </finish>                         
        <max-pay> 10.2 </max-pay>
        <max-budget> 100.3 </max-budget>
        <where> 11.22.33.44 </where> 
        <from>11.11.11.11</from>
</job>
</$jobListTag>
";

my $providersXml_1 = "
<$providerListTag>

<$providerTag name=\"sorma1\">
  <mem>1000</mem>
  <$minPriceTag>9</$minPriceTag>
  <IP>1.1.1.1</IP>
</$providerTag>

<$providerTag name=\"sorma2\">
  <mem>1000</mem>
  <$minPriceTag>8</$minPriceTag>
  <IP>1.1.1.2</IP>
</$providerTag>

</$providerListTag>
";



sub test_simpleCase_1 {
    my $self = shift;
    my $res;

    addDebugLevel(NAIVE_DBG);
    debug_lg(NAIVE_DBG, "\n");
    
    
    my $s = new sormad::NaiveSolver(jobsXml=> $jobsXml_1, 
                                    providersXml => $providersXml_1);
    $self->assert_not_null($s, "Unable to create NaiveSolver object");
    
    $res = $s->solve();
    $self->assert($res, "Error while solving simpleCase_1");
    
    my $ah = $s->getAssignmentInfo();
    
    $self->assert($ah->{1}->{$statusTag} eq JOB_RUN_STAT, "Job 1 status is not run");
    $self->assert($ah->{2}->{$statusTag} eq JOB_RUN_STAT, "Job 2 status is not run");
    $self->assert($ah->{3}->{$statusTag} eq JOB_SUSPEND_STAT, "Job 3 status is not run");

    my $xml = $s->getAssignmentXml();
    debug_ly(NAIVE_DBG, $xml);
}


1;
