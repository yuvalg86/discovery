#!/usr/bin/perl -w

package TestAllocationManager;

use base qw(Test::Unit::TestCase);

use strict;

use sormad::AllocationManager;
use sormad::SormadParam;
use Util::Debug;
use Data::Compare;
use Data::Dumper;
use XML::Simple;

sub new {
    my $self = shift()->SUPER::new(@_);
    # your state for fixture here
    return $self;
}



my $simple_assignment_1 = 
'<?xml version="1.0" encoding="UTF-8"?>
<allocations xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="allocations.xsd">
        <job id="65586" status="run">
                <allocation>
                        <provider>132.65.175.122</provider>
                </allocation>
        </job>
</allocations>
';

my $simple_pricing_1 = 
'<?xml version="1.0" encoding="UTF-8"?>
<pricing xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="pricing.xsd">
        <submissions>
                <job id="65586">10.0</job>
        </submissions>
        <providers>
                <provider name="sorma21">12.5</provider>
        </providers>
</pricing>';


sub test_SimpleAlloc {
    my $self = shift;
    my $res;

    addDebugLevel(ALLOC_MGR_DBG);
    debug_lg(ALLOC_MGR_DBG, "\n");
    
    my $am = new sormad::AllocationManager("jobMgr" => undef,
                                          "assignMgr" => undef,
                                          "providerMgr" => undef);
    $self->assert_not_null($am, "Unable to create AllocationManager object");
    
    $res = $am->setAssignmentXml($simple_assignment_1);
    $self->assert($res, "Error while setting assignment xml\n");

    $res = $am->setPricingXml($simple_pricing_1);
    $self->assert($res, "Error while setting pricing xml\n");
    clearDebugLevel();
}

1;
