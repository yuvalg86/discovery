#  AllocationManager $Id: AllocationManager.pm,v 1.3 2007-01-08 04:12:32 lior Exp $ #  


#****c* sormad/JobAllocation
# FUNCTION
# 
# This module is a data-structure for managing the current jobs in the cluster.
# The jobs are kept and are accessible via the interface functions

package sormad::AllocationManager;

use strict;

use Sys::Syslog;
use Data::Dumper; 
use XML::Simple;

use Util::Debug;
use sormad::SormadParam;
use providerd::ProviderCtl;

sub new;
sub setAssignmentXml;
sub setPricingXml;
sub doAllocation;


#****m* sormad/AllocationManager->new
# FUNCTION
#   Constractor for the AllocationManager object
# SYNOPSIS
#   $allocMgr = new AllocationManager();
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to an AllocationManager object on success
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    if(!exists($params{"jobMgr"})) {
        debug_lr(ALLOC_MGR_DBG, "Error no jobManager was given\n");
        return undef;
    }
    if(!exists($params{"providerMgr"})) {
        debug_lr(ALLOC_MGR_DBG, "Error no providerManager was given\n");
        return undef;
    }
    
    my $self = {
                %params,
               };

    $self->{assignmentXml} = undef;
    $self->{assignmentH}   = undef;
    $self->{pricingXml}    = undef;
    $self->{pricingH}      = undef;
    bless($self, $class);
    return $self;
}

sub setAssignmentXml {
    my $self = shift;
    my $xml = shift;
    
    $self->{assignmentXml} = $xml;
    
    debug_lg(ALLOC_MGR_DBG, "The assignment xml:\n$xml\n");
    my $h = eval { XMLin($xml, 
                         ForceArray => [$jobTag],
                         KeyAttr => {$jobTag => "id"} );};
    if($@) {
        debug_lr(ALLOC_MGR_DBG, "Error converting xml to hash\n$@\n");
        return 0;
    }
    debug_ly(ALLOC_MGR_DBG, Dumper($h));
    if(exists($h->{error})) {
        debug_lr(ALLOC_MGR_DBG, "Error: market run: $h->{error}\n");
        return 0;
    }
    $self->{assignmentH} = $h;
    return 1;
}

sub setPricingXml { 
    my $self = shift;
    my $xml  = shift;

    $self->{pricingXml} = $xml;

    debug_lg(ALLOC_MGR_DBG, "The pricing xml:\n$xml\n");
    my $h = eval { XMLin($xml, 
                         ForceArray => [$jobTag, $providerTag],
                         KeyAttr => {$jobTag => "id",
                                     $providerTag => "name"}, 
                         ContentKey => '-content',

                        );};
    if($@) {
        debug_lr(ALLOC_MGR_DBG, "Error converting xml to hash\n$@\n");
        return 0;
    }
    debug_ly(ALLOC_MGR_DBG, Dumper($h));
    if(exists($h->{error})) {
        debug_lr(ALLOC_MGR_DBG, "Error: market run: $h->{error}\n");
        return 0;
    }
    $self->{pricingH} = $h;
    return 1;
}

sub doAllocation {
    my $self = shift;
    
    debug_lb(ALLOC_MGR_DBG, "Doing allocation\n");
    my $jH = $self->{assignmentH}->{$jobTag};

    my $jpH = $self->{pricingH}->{$jobListTag}->{$jobTag};
    # Iterating on each job and assinging it to the proper place
    foreach my $id (keys %$jH) {
        debug_lg(ALLOC_MGR_DBG, "Assigning job: $id status: $jH->{$id}->{$statusTag}\n");

        # This small fix is needed since the jmarket currently use the status suspended 
        # but the mei uses the status suspend.
        $jH->{$id}->{$statusTag} = JOB_SUSPEND_STAT
          if($jH->{$id}->{$statusTag} eq "suspended");

        my $status = $jH->{$id}->{$statusTag};
        my $provider;
        if($status eq JOB_RUN_STAT) {
            $provider = $jH->{$id}->{$jobAllocationTag}->{$providerTag};
        }
        my $changed;
        $self->{jobMgr}->setJobPayment($id, $jpH->{$id});
        $self->{jobMgr}->setJobStatus($id, $status, $provider, \$changed);
        debug_ly(ALLOC_MGR_DBG, "Job $id changed $changed Price $jpH->{$id}\n");
        $self->{assignMgr}->assignJob($id)
          if($changed);
    }

    # Iterating over the providers in the pricing file and updating thier price.
    my $ppH = $self->{pricingH}->{$providerListTag}->{$providerTag};
    foreach my $p (keys(%$ppH)) {
        $self->{providerMgr}->setProviderCurrPrice($p, $ppH->{$p});
    }
}

#sub jobFinished

1;
