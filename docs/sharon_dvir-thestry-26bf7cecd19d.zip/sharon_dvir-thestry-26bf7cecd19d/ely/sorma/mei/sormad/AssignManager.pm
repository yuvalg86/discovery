#  $Id: AssignManager.pm,v 1.5 2007-01-02 10:39:56 lior Exp $ #  


#****c* sormad/AssignManager
# FUNCTION
# 
# Managing the assignd connection: Registering jobs, removing them and sending
# assignments orders

package sormad::AssignManager;

use strict;

use Sys::Syslog;
use Data::Dumper; 
use Socket;
use Carp;
use IO::Socket::INET;
use IO::Select;
use XML::Simple;

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use sormad::SormadParam;
use sormad::JobManager;


sub new;
sub newConnection;
sub handleMessage;
sub assignJob;
sub getStatusStr;

#****m* sormad/AssignManager->new
# FUNCTION
#   Constractor for the AssignManager object
# SYNOPSIS
#   $pm = new AssignManager();
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to a AssignManager
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    
    my $self = {
                %params,
               };
    
    if ( !exists($self->{jobMgr})) {
        return undef;
    }
    
    $self->{cfg}          = {};
    $self->{assignH}      = {};
    $self->{msg_len}      = 1024;
    $self->{recv_timeout} = 3;
    bless($self, $class);
    return $self;
}


sub free {
    my $self = shift;
    foreach my $a (keys(%{$self->{assignH}})) {
        $self->{assignH}->{$a}->{sock}->close();
    }
}
sub getAssignNum {
    my $self = shift;
    my $n = keys(%{$self->{assignH}});
    return $n;
}


sub validateAssigndAddr {
    my $self = shift;
    my $addrStr = shift;

    return 1;
}


#****m* sormad/AssignManager->addNewConnection
# FUNCTION
#   Manage a new connection made to the main socket
# SYNOPSIS
#   $pm = new AssignManager();
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to a AssignManager
#******
sub addAssignConnection {
    my $self = shift;
    my $socket = shift;
    
    my $newconn = $socket->accept();
    
    my $sockaddr        = $newconn->peername();
    my ($port, $iaddr)  = sockaddr_in($sockaddr);
    my $rhostname       = gethostbyaddr($iaddr, AF_INET); 
    my $rhostaddr       = inet_ntoa($iaddr);
    debug_lg(AMGR_DBG, "Got connection on tcp: $rhostname $rhostaddr\n");
    
    # it is now possible to perform IP based validation
    if(!$self->validateAssigndAddr($rhostaddr)) {
        $newconn->close();
        return 0;
    }
    
    # IP is valid we continue
    if(exists($self->{assignH}->{$rhostaddr})) {
        debug_lr(AMGR_DBG, "Already has connection from $rhostname\n");
        $newconn->close();
        return 0 ;
    }

    debug_lb(AMGR_DBG, "Adding new assignd at address $rhostname\n");
    $self->{assignH}->{$rhostaddr}->{sock}     = $newconn;
    $self->{assignH}->{$rhostaddr}->{verified} = 0;
    $self->{assignH}->{$rhostaddr}->{jobs}     = 0;
    return 1;
}


#****m* sormad/AssignManager->deleteAssignConnection
# FUNCTION
#   An assignd disconnected and its connection + jobs are removed
# SYNOPSIS
#   $res = $am->deleteAssignConnection($addr, $readSet);
# ARGUMENTS
#   $addr      The address of the disconnecting assignd
#   $readSet   It is neccesary to remove the connection from the readset before
#              closing the connection (should be fixed)
# RETURN VALUE
#  0        In the connection does not exists
#  1        If the deletion was ok.
#******
sub deleteAssignConnection {
    my $self = shift;
    my $addr = shift;
    my $readSet = shift;
    
    if(!exists($self->{assignH}->{$addr})) {
        debug_lr(AMGR_DBG, "Error $addr conenction does not exists\n");
        return 0;
    }
    
    debug_lb(AMGR_DBG, "Deleting assignd on address $addr\n");
    $readSet->remove($self->{assignH}->{$addr}->{sock});
    $self->{assignH}->{$addr}->{sock}->close();
    $self->{jobMgr}->removeJobsByNode($addr);
    delete($self->{assignH}->{$addr});
    return 1;
}

sub getAssignSock {
    my $self = shift;
    
    my @sockList = ();
    foreach my $a (keys %{$self->{assignH}}) {
        push @sockList, $self->{assignH}->{$a}->{sock};
    }
    return @sockList;
}


sub isAssignSock {
    my $self = shift;
    my $sock = shift;

    debug_ly(AMGR2_DBG, "Checking if sock is from assignd\n");
    my $aH = $self->{assignH};
    foreach my $a (keys(%$aH)) {
        #debug_ly(AMGR_DBG, "\tcheckng addr $a\n");
        
        if($sock == $aH->{$a}->{sock}) {
            debug_ly(AMGR2_DBG, "\tFound matching $a\n");
            return $a;
        }
    }
    return undef;
}

sub isAssigndExists {
    my $self = shift;
    my $addr = shift;
    
    return exists($self->{assignH}->{$addr});
}


sub verifyAssignConnection {
    my $self = shift;
    my $msgH = shift;

    return 0 if(!exists($msgH->{$registerTag}));
    return 0 if(!exists($msgH->{$registerTag}->{$registerTypeTag}));
    return 0 if($msgH->{$registerTag}->{$registerTypeTag} ne $registerTypeVal);
    return 1;
}

sub handleJobMsg {
    my $self = shift;
    my $msgH = shift;
    my $addr = shift;
    
    foreach my $id (keys %$msgH) {
        debug_lb(AMGR_DBG, "Job message ID: $id\n");
        $msgH->{$id}->{$mandatoryJobFields->{from}} = $addr;
        if(!$self->{jobMgr}->addJob($msgH->{$id})) {
            debug_lr(AMGR_DBG, "Failed to add job ($id) to job manager\n");
        }
    }
    
    return 1;
}

sub handleJobStatusMsg {
    my $self = shift;
    my $msgH = shift;
    
    foreach my $id (keys %$msgH) {
        debug_lb(AMGR_DBG, "Job status message ID: $id $msgH->{$id}->{content}\n");
        if( $msgH->{$id}->{'content'} =~ /\s+$jobFinishedValue\s+/ ) {
            if(!$self->{jobMgr}->removeJob($id)) {
                debug_lr(AMGR_DBG, "Failed to add job ($id) to job manager\n");
            }
        }
    }
    return 1;
}

sub handleAssignMsg {
    my $self = shift;
    my $assigndAddr = shift;
    my $readSet = shift;
    
    if(!$self->isAssigndExists($assigndAddr)) {
        debug_lr(AMGR_DBG, "Error $assigndAddr does not exists in AssignMgr object\n");
        return 0;
    }
    my $assign = $self->{assignH}->{$assigndAddr};
    my $msg = recvAllData($assign->{sock}, $self->{msg_len}, $self->{recv_timeout});
    
    
    if($msg) {
        $msg = "<msg>$msg</msg>";
        debug_lg(AMGR_DBG, "Client message:\n$msg\n");
        # Converting the XML message to a hash
        my $msgH =  eval { XMLin($msg,  ForceArray => [$jobTag, $jobStatusTag], 
                                 KeyAttr => {"$jobTag" =>"+$idTag",
                                             "$jobStatusTag" => "+$idTag"}
                                );
                       };
        if($@) {
            debug_lr(AMGR_DBG, "Error failed to translate message to XML\n");
            return 0;
        }
        
        debug_lg(AMGR_DBG, Dumper($msgH));
        if(1) { #if($assign->{verified}) {
            return $self->handleJobMsg($msgH->{$jobTag}, $assigndAddr) 
              if(exists($msgH->{$jobTag}));
            return $self->handleJobStatusMsg($msgH->{$jobStatusTag}) 
              if(exists($msgH->{$jobStatusTag}));
            
        } else {
            if(!$self->verifyAssignConnection($msgH)) {
                debug_lr(AMGR_DBG, "Connection was not verified in first message -> deleteing\n");
                $self->deleteAssignConnection($assigndAddr, $readSet);
                return 0;
            }
        }
    } else {
        $self->deleteAssignConnection($assigndAddr, $readSet);
        return 0;
    }
    return 1;
}

sub assignJob {
    my $self = shift;
    my $job  = shift;
    
    debug_lb(AMGR_DBG, "Assigning job $job\n");
    my $jobH = $self->{jobMgr}->getJobInfo($job);
    if(!$jobH) {
        debug_lr(AMGR_DBG, "Error: job !!$job!! does not exists\n");
        return 0;
    }
    my $jobStatus = $jobH->{$statusTag};
    my $from = $jobH->{$allJobFields->{from}};

    if(!exists($self->{assignH}->{$from})) {
        debug_lr(AMGR_DBG, "Error assignd $from does not exists\n");
        return 0;
    }
    
    # The were is used only if there is a run status
    my $where;
    if($jobStatus eq JOB_RUN_STAT) {
        $where = $jobH->{$allJobFields->{where}};
        my $addr = gethostbyname($where);
        $where = inet_ntoa($addr);
    }
     
    my $jobAssignAction = $jobStatus;
    $jobAssignAction = JOB_SUSPEND_STAT
      if($jobAssignAction eq JOB_NO_BUDGET_STAT);
    
    my $xml;
    $xml .= "<$jobAssignTag $idTag=\"$job\">\n";
    $xml .= "\t<$statusTag>$jobAssignAction</$statusTag>\n";
    $xml .= "\t<$providerTag>$where</$providerTag>\n"
      if($where);
    $xml .= "</$jobAssignTag>\n";
    
    debug_ly(AMGR_DBG, "assignd $from\n$xml\n");

    my $sock = $self->{assignH}->{$from}->{sock};
    $sock->send($xml);
    return 1;
}

#****m* sormad/AssignManager->getStatusStr
# FUNCTION
#   Returns a string containing the status of the assigndMgr object. 
#   This is used mainly for debugging 
# SYNOPSIS
#   $str = $am->getStatusStr();
# ARGUMENTS
# RETURN VALUE
#   A string with the status of the AssignManager
#******
sub getStatusStr {
    my $self = shift;
    
    my $str;

    $str .= "Connected assignd:\n";
    foreach my $addr (sort keys(%{$self->{assignH}})) {
        $str .= "$addr \n";
    }
    return $str;
}

sub getAssignXml {
    my $self = shift;

    my $xml;
    $xml .= "<$assigndListTag>\n";
    foreach my $addr (sort keys(%{$self->{assignH}})) {
        $xml .= "\t<$assigndTag name=\"$addr\"/>\n";
    }
    $xml .= "</$assigndListTag>\n";
    return $xml;
}

1;
    
