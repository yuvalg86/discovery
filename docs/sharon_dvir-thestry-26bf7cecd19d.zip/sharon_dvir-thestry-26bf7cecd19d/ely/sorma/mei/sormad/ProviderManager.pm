#  ProviderManager$Id: ProviderManager.pm,v 1.8 2007-01-23 16:31:21 lior Exp $ #  


#****c* sormad/ProviderManager
# FUNCTION
# 
# Manager communication to providers and maintain the list of available 
# providers and their status

package sormad::ProviderManager;

use strict;

use Sys::Syslog;
use Data::Dumper; 
use Socket;
use IO::Socket::INET;
use XML::Simple;

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::Misc;
use sormad::SormadParam;
use providerd::ProviderParam;

sub new;
sub update;
sub getProvidersXml;
sub setProviderEcoStatus;
sub getError;
sub getClusterNum;
sub getProviderNum;

sub mSortOp { return Util::Misc::machines_sort_func($b , $a); }

#****m* sormad/ProviderManager->new
# FUNCTION
#   Constractor for the ProviderManager object
# SYNOPSIS
#   $pm = new ProviderManager("providerConf" => $pv_conf
#                             "infodClientProg" => $infod_prog
#                             "timeout" => $timeout);
# ARGUMENTS
#   "providerConf"   The providers configuration, which is a hash describing 
#                    possible providers
#   "infodClientProg The name of the infod-client program to use
#   "timeout"        The timeout to use in the infod-client 
# RETURN VALUE
#  undef    On error
#  A reference to a ProviderManager object on success
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };
    
    $self->{cfg} = {};
    if(!exists($self->{infodClientProg})) {
        $self->{infodClientProg} = $defaultInfodClientProg;
    }
    if(!exists($self->{timeout})) {
        $self->{timeout} = $defaultInfodClientTimeout;
    }

    if(!($self->{providerCtl} =  providerd::ProviderCtl->new())) {
        debug_lr(PMGR_DBG, "Error while creating providerCtl object\n");
        return undef;
    }

    $self->{clusterH} = {};
    $self->{providerVec} = {};

    bless($self, $class);
    return $self;
}

sub getStatusStr {
    my $self = shift;
    
    my $str;
    $str .= "Provider Manager Status:\n";
    $str .= "--------------------------\n";
    $str .= "Cluster\t\tRepresentatives\n";
    foreach my $c (sort keys(%{$self->{clusterH}})) {
        my $list = $self->{clusterH}->{$c}->{repList};
        $str .= "$c\t\t@$list\n";
    }
    $str .= "\n\n";
    $str .= "Providers:\tReserv-price:\n";
    foreach my $n (sort mSortOp keys %{$self->{providerVec}}) {
        my $p = $self->{providerVec}->{$n};
        $str .= sprintf("%-10s\t%6.3f\n", $n, $p->{$minPriceTag});;
    }
    return $str;
}

sub getClusterNum {
    my $self = shift;
    return scalar keys %{$self->{clusterH}};
}

sub getProviderNum {
    my $self = shift;
    return scalar keys %{$self->{providerVec}};
}


#****m* sormad/ProviderManager->addClusterInfoRep
# FUNCTION
#   Add an information representative 
# SYNOPSIS
#   $res = $pm->addClusterInfoRep($name, $infoRepList);
# ARGUMENTS
#   $name          The name of the cluster
#   $infoRepList   A reference to a list of representatives e.g., ["mos1","mos2","mos3"]
# RETURN VALUE
#  0   on error
#  1   on success
#******
sub addClusterInfoRep {
    my $self = shift;
    my $clusterName = shift;
    my $infoRepList = shift;
    
    debug_lb(PMGR_DBG, "Adding info representatives to $clusterName reps: @$infoRepList\n");
    if(!exists($self->{clusterH}->{$clusterName})) {
        my @tmpList = @$infoRepList ;
        $self->{clusterH}->{$clusterName}->{repList} = \@tmpList;
    }else {
        my $rl = $self->{clusterH}->{$clusterName}->{repList};
        push @$rl, @$infoRepList;
    } 
    return 1;
}

sub removeClusterInfoRep {
    my $self = shift;
    my $clusterName;
    
    debyg_lb(PMGR_DBG, "Removing $clusterName representatives\n");
    delete($self->{clusterH}->{$clusterName}) 
      if(exists($self->{clusterH}->{$clusterName}));
    return 1;
}

#****m* sormad/ProviderManager->probeNode
# FUNCTION
#   Get the xml string of a cluster via a node
# SYNOPSIS
#   $res = $pm->probNode($node, $outRef);
# ARGUMENTS
#   $node          The node to prob (e.g., mos1);
#   $outRef        Reference to a scalar that should contain the output 
# RETURN VALUE
#  0   on error
#  1   on success
#******
sub probeNode {
    my $self = shift;
    my $node = shift;
    my $outputRef = shift;
    
    my $infodClient = $self->{infodClientProg};
    my $timeout = $self->{timeout};
    my $pid;    

    # Command used for probing
    my $command = "$infodClient --server=$node --timeout $timeout";
    
    my @output;
    return eval {
        
        if(!($pid = open CMDOUT, "$command|"))
          {
              debug_lr(PMGR_DBG, "Error opening pipe to infod-client failed: $!\n");
              return 0;
          };
        
        @output = <CMDOUT>;
        close (CMDOUT);
        my $infodClientRetVal = $? >> 8;
        if($infodClientRetVal != 0) {
            debug_lr(PMGR_DBG, "Error probing node $node (ret val $infodClientRetVal)\n");
            return 0;
        }
        
        # If got nothing...
        if (!@output eq -1){
            debug_lr(PMGR_DBG, "infod-client did not return output ($node)\n");
            return 0;
        }
        # Probing successed.
        $$outputRef = join("", @output);
        return 1;
    };
}


sub extractNodeInfo {
    my $self = shift;
    my $allInfo = shift;

    my $resInfo = {};
    
    #debug_ly(PMGR_DBG, Dumper($allInfo));
    return 0 if($allInfo->{infod_dead_str} ne "alive");
    return 0 if(!exists($allInfo->{$economyInfoTag}));
    return 0 if($allInfo->{$economyInfoTag} eq "error");
    return 0 if(!ref($allInfo->{$economyInfoTag}));
    return 0 if(exists($allInfo->{$economyInfoTag}->{error}));
    
    my $addr = gethostbyname($allInfo->{name});
    $resInfo->{IP}            = inet_ntoa($addr);
    $resInfo->{name}          = $allInfo->{name};
    $resInfo->{'cpu-num'}     = $allInfo->{ncpus};
    $resInfo->{mem}           = ($allInfo->{freepages} * 4096.0) / (1024*1024);
    
    my $ecoInfo = $allInfo->{$economyInfoTag};
    $resInfo->{$minPriceTag}  = $ecoInfo->{$minPriceTag};
    $resInfo->{$currPriceTag} = $ecoInfo->{$currPriceTag};
    $resInfo->{$statusTag}    = $ecoInfo->{$statusTag};
    $resInfo->{$onTimeTag}    = $ecoInfo->{$onTimeTag};
    
    return $resInfo;
}

sub extractClusterInfo {
    my $self = shift;
    my $clusterName = shift;
    my $vectorH = shift;

    #delete($self->{clusterH}->{$clusterName}->{vec});
    foreach my $n (keys %{$vectorH->{node}}) {
        #debug_lr(PMGR_DBG, Dumper($vectorH->{node}->{$n}));
        my $nodeInfo = $self->extractNodeInfo($vectorH->{node}->{$n});
        next if !$nodeInfo;
        $nodeInfo->{cluster} = $clusterName;
        $self->{providerVec}->{$n} = $nodeInfo; 
    }
    #debug_lg(PMGR_DBG, Dumper($newVec));
    #$self->{clusterH}->{$clusterName}->{vec} = $newVec;
    
}

sub probe {
    my $self = shift;
    
    delete($self->{providerVec});
    $self->{providerVec} = {};
    debug_lb(PMGR_DBG, "Probing clusters\n");
    foreach my $c (sort keys(%{$self->{clusterH}})) {
        my $clusterRep = $self->{clusterH}->{$c}->{repList}->[0];
        debug_lg(PMGR_DBG, "Probing $c using $clusterRep\n");
        my $vectorXml;
        if(! $self->probeNode($clusterRep, \$vectorXml)) {
            debug_lr(PMGR_DBG, "Error probing $clusterRep\n");
            # Here we should choose the next representative if any
            next;
        }
        # probing went well, taking the xml and converting it to a hash
        my $vectorH =  eval { XMLin($vectorXml,  ForceArray => ["node"],
                                    KeyAttr => {"node" => "+name"}); 
                          };
        if($@) {
            debug_lr(AMGR_DBG, "Error failed to translate vector to XML\n");
            next;
        }
        # Taking the hash an storing the relevant stuff
        $self->extractClusterInfo($c, $vectorH);
        
        debug_lg(PMGR_DBG, "Found " . $self->getProviderNum() . " Providers\n");
        debug_lg(PMGR_DBG, Dumper($self->{providerVec}));
        debug_lg(PMGR_DBG, $self->getProvidersXml());
    }
    return 1;
}


sub getProviderXml {
    my $self = shift;
    my $p    = shift;
    my $marketXml = shift;
    
    my $pInfo = $self->{providerVec}->{$p};

    my $xml;
    $xml .= "<$providerTag name=\"$p\" >\n";

    if($marketXml) {
        foreach my $mk (keys %$providerMarketFields) {
            next if($mk eq "name");
            if($jobMarketFields->{$mk} and !exists($pInfo->{$mk})) {
                debug_lr(JMGR_DBG, "Error a mandatory market field $mk is not present in provider $p\n");
                return undef;
            }
            
            if(exists($pInfo->{$mk})) {
                if(exists($providerFieldsFmt->{$mk})) {
                    $xml .= sprintf("\t<$mk>". $providerFieldsFmt->{$mk} . "</$mk>\n", 
                                    $pInfo->{$mk});
                }
                else {
                    $xml .= "\t<$mk>$pInfo->{$mk}</$mk>\n"
                }
            }
        }
    }
    else {
        foreach my $k (keys %$pInfo) {
            next if($k eq "name");
            if(exists($providerFieldsFmt->{$k})) {
                $xml .= sprintf("\t<$k>". $providerFieldsFmt->{$k} . "</$k>\n", 
                                $pInfo->{$k});
            }
            else {
                $xml .= "\t<$k>$pInfo->{$k}</$k>\n";
            }
        }
    }

    $xml .= "</$providerTag>\n";
    return $xml;
}


sub getProvidersXml {
    my $self = shift;
    my $marketXml = 0;
    $marketXml = shift
      if(@_);
    
    my $xml;
    

    $xml .= "<$providerListTag>\n";
    foreach my $p (keys %{$self->{providerVec}}) {
        my $providerXml = $self->getProviderXml($p, $marketXml);
        $xml .= $providerXml;
    }
    $xml .= "</$providerListTag>\n";
    return $xml;
}

sub getProvidersMarketXml {
    my $self = shift;
    return $self->getProvidersXml(1);
}



sub getClustersXml {
    my $self = shift;
    
    my $xml;
    
    $xml .= "<$clustersListTag>\n";
    
    foreach my $c (sort keys(%{$self->{clusterH}})) {
        my $list = $self->{clusterH}->{$c}->{repList};
        $xml .= "\t<$clusterTag name=\"$c\">\n";
        foreach my $rep (@$list) {
            $xml .= "\t\t<$repTag>$rep</$repTag>\n";
        }
        $xml .= "\t</$clusterTag>\n";
    }
    $xml .= "</$clustersListTag>\n";
    return $xml;
}

sub setProviderCurrPrice {
    my $self = shift;
    my $provider = shift;
    my $price = shift;
    
    if(exists($self->{providerVec}->{$provider})) {
        my $pH = $self->{providerVec}->{$provider};
        my $oldPrice = $pH->{$currPriceTag};
        if(!$oldPrice != $price) {
            debug_lg(PMGR_DBG, "Provider $provider price changed $oldPrice $price\n");
            
        }
        $pH->{$currPriceTag} = $price;
    }

    my $res = $self->{providerCtl}->setCurrPrice($provider, $price);
    return $res;
}


# Setting all providers curr-price to 0 and sending a message to those who had
# a >0 price before
sub clearCurrPrice {
    my $self = shift;

    foreach my $p (keys %{$self->{providerVec}}) {
        my $pH = $self->{providerVec}->{$p};
        my $oldPrice = $pH->{$currPriceTag};
        
        if($oldPrice != 0) {
            my $res = $self->{providerCtl}->setCurrPrice($p, 0);
            $pH->{$currPriceTag} = 0;
        }
    }
}

sub foreachProvider {
    my $self = shift;
    my $func = shift;
    my $data = shift;

    #print Dumper $self->{jobH};
    foreach my $p (keys %{$self->{providerVec}}) {
        #   print "Doing $j\n";
        &{$func}($self->{providerVec}->{$p}, $data);
    }
}


1;

