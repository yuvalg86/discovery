
package providerd::ProviderParam;

#use strict;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw( $pvdPort 
  $economyInfoTag $nextPriceTag
  $minPriceTag  $currPriceTag $statusTag $onTimeTag
  $schedPriceTag $incPriceTag $protectedTimeTag 
  $providerFieldsFmt 
  $queryType  $queryResultTag $statusQueryTag $allStatusQuery 
  $actionType $actionResultTag $pvdStatusActTag $minPriceActTag $currPriceActTag
  $resultType
  $providerOnVal $providerOffVal $providerHomeVal 
  $providerMarketFreeVal $providerMarketProtectedVal $providerMarketAvailableVal 
  $marketStatusTag $providerMarketBidVal

  $providerMarketTypeTag $providerDistMarketVal $providerCentralMarketVal

  $timeFrameTag  $singleFrameTag

  $incPriceTag $incMethodTag $incMethodParamTag
  $incPriceFix    
  $incPricePercent

  $decPriceTag $decMethodTag $decMethodParamTag $decPriceFix $decPriceMin 

  $bidActTag $bidValTag 


  $mosix_localProcNumFile
);

# The default port of the provider daemon
$pvdPort = "9000";

#  Communication protocol:
#
#  Queries:
#  ============ 
#  syntax: "<query>query-internal-xml</query> 
# 
#   status-query: <status-query>all</status-query>
#
#
#  Actions: 
#  ============
#  syntax: <action> action-internal-xml </action>
#    
#  provider-status     <set-prvider-status> open|close </set-provider-status>
#
#  set-min-price       <set-min-price> price </set-min-price>
#
#  set-curr-price      <set-curr-price> price </set-curr-price>
#
#  set-time-frame      In future

# Status tags

# The main info file tag
$economyInfoTag   = 'economy-status';

# Sub tags
$minPriceTag      = "min-price";
$currPriceTag     = "curr-price";
$schedPriceTag    = "sched-price";
$nextPriceTag     = "next-price";
$incPriceTag      = "inc-price";
$protectedTimeTag = "protect-time";
$statusTag        = "status";
$marketStatusTag  = "market-status";
$onTimeTag        = "on-time";


# market types
$providerMarketTypeTag    = "market";
$providerDistMarketVal    = "distributed";
$providerCentralMarketVal = "central";

$providerMarketFreeVal       = "free";
$providerMarketProtectedVal  = "protected";
$providerMarketAvailableVal  = "available";
$providerMarketBidVal        = "bid";

$providerOnVal        = "on";
$providerOffVal       = "off";
$providerHomeVal      = "home";


$providerFieldsFmt = {
                      "$minPriceTag"  => "%.3f",
                      "mem"           => "%.2f",
                     };


# Time frame
$timeFrameTag     = "time-frame";
$singleFrameTag   = "frame";

# Inc price
$incPriceTag        = "inc-price";
$incMethodTag       = "method";
$incMethodParamTag  = "param";

$incPriceFix        = "fix";
$incPricePercent    = "percent";

# Dec price
$decPriceTag        = "dec-price";
$decMethodTag       = "method";
$decMethodParamTag  = "param";

$decPriceFix        = "fix";
$decPriceMin        = "min";

# types
$queryType = "query";
$actionType = "action";
$resultType = "result";

# Queries
$statusQueryTag = "status-query";
$allStatusQuery = "all";

# Actions
$pvdStatusActTag = "provider-status";
$minPriceActTag  = "set-min-price";
$currPriceActTag = "set-curr-price";

$bidActTag       = "bid";
$bidValTag       = "value";


# MOSIX files
$mosix_localProcNumFile  = "/proc/mosix/locals";

1;
