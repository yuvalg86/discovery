
#  ProviderCtl $Id: ProviderCtl.pm,v 1.13 2007-10-23 18:26:20 elylevy Exp $ #  
# 


package providerd::ProviderCtl;

use strict;
use Socket;
use IO::Socket::INET;
use File::Basename;
use Data::Dumper;
use XML::Simple;

use Util::MarketProtocol;
use Util::Net; 
use Util::Debug; 
use providerd::ProviderParam; # qw ($pvdPort);
#################### Functions from this class ############################

my $filename = basename $0;

###############################################################################
# new - constructor
#
# Arguments:
#   o machine_name       The name of the current machine
#   o server_name        Name of remote bm server (should be taken from site)
#   o server_port
###############################################################################
sub new 
{
	my $proto = shift;
	my $class = ref($proto) || $proto;
	my $self = {};
	my $timeout = 10;
        
     

	$self->{pvd_port} = $pvdPort;
        $self->{errMsg} = "";

        debug_lb(PVD_CTL_DBG, "Port: $self->{pvd_port}\n");
	bless($self, $class);
	return $self;
}

sub close {
    my $self = shift;
    
}

sub initTCPSock {
    my $self = shift;
    my $machineName = shift;
    
    my $tcpSock = new IO::Socket::INET->new(PeerAddr => $machineName,
                                            PeerPort => $self->{pvd_port},
                                            Proto    => 'tcp');
    if (!$tcpSock) {
        debug_lr(PVD_CTL_DBG, "Error generating tcp sock to $machineName\n");
        $self->{errMsg} = "Error generating tcp socket:  $!\n";
        return undef;
    }
    debug_lg(PVD_CTL_DBG, "Done initing tcp sock to $machineName\n");
    return $tcpSock;
}

sub errorMsg {
    my $self = shift;

    return  $self->{errMsg};
}

sub sendMessage {
    my $self = shift;
    my $machine = shift;
    my $msgTypeTag = shift;
    my $msgH  = shift;
    my $resHRef  = shift;
    my $xml = new XML::Simple(NoAttr=>1, RootName=>"");

    $msgH->{$marketClassTag} = $providerCtlClass;
    $msgH->{$marketTypeTag}  = $msgTypeTag;

    # Generate the XML query from the hash
    my $msgXml = $xml->XMLout($msgH);
    debug_lg(PVD_CTL_DBG, "XML:\n$msgXml\n");

    # Adding the message envelop (header)
    #$msgXml = $self->addMsgEnvelop($msgXml);
    
    # Generate the tcp sock and send the query
    my $tcpSock = $self->initTCPSock($machine);
    return 0 if(!$tcpSock);
    sendMarketMsg($tcpSock, $msgXml);
    
    # Recieve the result of the query
    my $response = recvMarketMsg($tcpSock, 5);
    $tcpSock->close();
    if(!$response) {
        $self->{errMsg} = "Nothing recieved from providerd";
        return 0;
    }
    my $resHash  = $xml->XMLin($response);
    $$resHRef = $resHash;
    return 1;
}


sub status {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;
    
    my $retVal = 0;
    my $queryH = {};
    my $resH;
    
    $queryH->{$marketDataTag}->{$statusQueryTag} = $allStatusQuery;
    my $res = $self->sendMessage($machine, $queryType, $queryH, \$resH);
    return 0 if(!$res);

    $retVal = 1;

    $$statusResult = $self->printStatus(getData($resH));
    return $retVal;
}


sub printStatus {
    my $self = shift;
    my $resHash = shift;

    my $str;
    $str .= "Status:       $resHash->{$statusTag}\n";
    $str .= sprintf("On Time:      %.2f\n", $resHash->{$onTimeTag})
      if($resHash->{$onTimeTag} > 0);
    $str .= "Min Price:    $resHash->{$minPriceTag}\n";
    $str .= "Curr Price:   $resHash->{$currPriceTag}\n";
    $str .= "Next Price:   $resHash->{$nextPriceTag}\n";
}


sub setMinPrice {
    my $self = shift;
    my $machine = shift;
    my $minPrice = shift;

    my $retVal = 0;
    my $actionH = {};
    my $resH;

    $actionH->{$marketDataTag}->{$minPriceActTag} = $minPrice;
    my $res = $self->sendMessage($machine, $actionType, $actionH, \$resH);
    if(!$res) {
        return 0;
    }
    if(exists($resH->{$marketDataTag}->{$minPriceActTag})) {
        $retVal = 1;
    }
    return $retVal;
}

sub doBid {
  my $self = shift;
  my $machine = shift;
  my $price = shift;
  
  my $retVal = 0;
  my $actionH = {};
  my $resH;
  
  $actionH->{$bidActTag}->{$bidValTag} = $price;
  my $res = $self->sendMessage($machine, $actionType, $actionH, \$resH);
  if(!$res) {
      return 0;
  }
  if(exists($resH->{$actionResultTag}->{$bidActTag})) {
      if ($resH->{$actionResultTag}->{$bidActTag} eq "accepted") {
          $retVal = 0;
      } else {
          
          $retVal = 1;
      }
      return $retVal;
  }
}

sub setCurrPrice {
    my $self = shift;
    my $machine = shift;
    my $currPrice = shift;
    my $retVal = 0;
    my $actionH = {};
    my $resH;

    $actionH->{$marketDataTag}->{$currPriceActTag} = $currPrice;
    my $res = $self->sendMessage($machine, $actionType, $actionH, \$resH);
    if(!$res) {
        return 0;
    }
    if(exists($resH->{$marketDataTag}->{$currPriceActTag})) {
        $retVal = 1;
    }
    return $retVal;
}


sub setMarketStatus {
    my $self = shift;
    my $machine = shift;
    my $mode = shift;
    my $retVal = 0;
    my $actionH = {};
    my $resH;
    my $modeStr = $mode ? $providerOnVal : $providerOffVal;

    debug_lg(PVD_CTL_DBG, "Mode $mode $modeStr\n");
    $actionH->{$marketDataTag}->{$pvdStatusActTag} = $modeStr;
    my $res = $self->sendMessage($machine, $actionType, $actionH, \$resH);
    if(!$res) {
        return 0;
    }
    if(defined getData($resH)) {
        $retVal = 1;
    }
    return $retVal;
}


1;



