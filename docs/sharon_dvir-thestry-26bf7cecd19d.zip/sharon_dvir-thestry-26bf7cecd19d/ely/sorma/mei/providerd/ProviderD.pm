#  Providerd $Id: ProviderD.pm,v 1.37 2007-10-23 18:26:20 elylevy Exp $ #  

#****c* providerd/ProviderD
# FUNCTION
# 
# The provider is responsible for updating the economical parameters of 
# a node.
#
# 

package ProviderD;

use strict;

use Sys::Syslog;
use Data::Dumper; 
use Socket;
use Carp;
use File::Basename;
use IO::Socket::INET;
use IO::Select;
use XML::Simple;

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::TimeFrame;
use providerd::ProviderParam;
use Util::MarketProtocol;
use Util::DistMarketProtocol;

############# Functions declarations ##########################

sub run;
sub handle_msg;

#### handle the save/load procedure ###
sub save_state;
sub load_state;
sub clean_state;

sub run;

my $globExit = 0;

########### Global variables ####################################

my $logFile;

my $defaultInfoFile = "/tmp/provider.info";

my $defaultInitialStatus = $providerOnVal;
my $defaultMinPrice      = 0;

my $defaultConfFile       = "/etc/mosix/provider.conf";

#****m* providerd/ProviderD->new
# FUNCTION
#   Constractor for the ProviderD object
# SYNOPSIS
#   $pvd = new ProviderD(prog_name   => "program name",
#                        infoFile   => "info file for infod",
#                        confFile   => "configuration file",
#                        debug       => "debug level",
#                       );
# ARGUMENTS
#   prog_name        The program name for syslog
#   infoFile         The information file for infod.
#   confFile         Configuration file to use
#   debug            Debug level.
# RETURN VALUE
#  undef    On error
#  A reference to a ProviderD object on success
#******
sub new {
	my $proto = shift;
	my $class = ref($proto) || $proto;
	
	my %params = @_;
          
	my $self = {
	    %params,
	};

	if( !exists($self->{prog_name}) ) {
	    return undef;
	}
        
	if( !exists($self->{infoFile})) {
	    $self->{infoFile} = $defaultInfoFile;
	}
        if( !exists($self->{confFile})) {
            $self->{confFile} = $defaultConfFile;
        }
        
	$self->{listen} = 10;
	$self->{dbg_level} = 0;
	$self->{msg_len} = 1024;
	$self->{recv_timeout} = 3;
	$self->{port} = $pvdPort;
	$self->{cfg} = {};

        $self->{period} = 1;

        $self->{$providerMarketTypeTag} = $providerCentralMarketVal;

        $self->{cycles} = {
                           homeModeCheck => { cycle    => 5, 
                                              funcName => 'handleHomeNodeMode'},
                           infoUpdate    => { cycle    => 5,
                                              funcName => 'handleOnMode' },
                           #                           t1            => { cycle    => $T1Period,
                           #                                              funcName => 1'},
                           
                          };
        
        $self->{eco_info}->{$statusTag} = $defaultInitialStatus;
        $self->{eco_info}->{$onTimeTag}  = -1;
        $self->{eco_info}->{$minPriceTag}  = 0;
        $self->{eco_info}->{$currPriceTag} = 0;
        $self->{eco_info}->{$schedPriceTag} = 0;
        $self->{eco_info}->{$incPriceTag} = 1;
        $self->{eco_info}->{$protectedTimeTag} = 0;

        $self->{marketLastChanged} = time();
        $self->{eco_info}->{$marketStatusTag} = $providerMarketFreeVal;

        $self->{newconn} = undef;
        
        # Initializaing the log to empty one
	$self->{log} = {};

	## Handling the daemon log (not the log file of the machines)
	Sys::Syslog::setlogsock('unix');
	openlog($self->{prog_name},  'pid,cons', 'daemon');
        
	# Creating the tcp socket
        my $i = 0;
        while(1) {
            $self->{tcpSock} =
              new IO::Socket::INET->new(Proto     => 'tcp',
                                        Type      => SOCK_STREAM ,
                                        LocalPort => $self->{port},
                                        Listen    => $self->{listen});
            if(!$self->{tcpSock}) {
                if(exists($!{EADDRINUSE})) {
                    if($i< 61) {
                        print STDERR "." ; sleep 1;
                        next;
                    }
                }
                print STDERR "Can't create tcp socket: $!\n";
                return 0;
            } 
            else { last; }
        }
        
	# Creating the basic select object
	$self->{select} =  new IO::Select( $self->{tcpSock});
	if (!$self->{select}) {
	    print STDERR "Can't initialize select object \n";
	    return undef;
	}

        # Becoming an object
	bless($self, $class);
	
        if( ! $self->readConfFile() ) {
          print STDERR "Error reading conf file: $self->{confFile} : $!\n";
          return undef;
        }
        
        return undef if(!$self->stopAutomaticLB());
        
	return $self;
}

sub stopAutomaticLB {
    my $self = shift;

    `mosctl stay`;
    return 1;
}

sub sig_int_hndl {
    my $sig = shift;

    print STDERR "Got sig $sig, Going down\n";
    syslog("alert", "Got sig $sig, going down\n");
    $globExit = 1;
}


sub sig_pipe_hndl {
    my $sig = shift;

    print STDERR "Got sig $sig";
    syslog("alert", "Got sig $sig");
}

sub setSignalHandlers {
    my $self = shift;
    
    $SIG{INT} =  \&sig_int_hndl;
    $SIG{TERM} = \&sig_int_hndl;
    $SIG{PIPE} = \&sig_pipe_hndl;
}

sub doExit {
    my $self = shift;
    
    $self->{tcpSock}->close();
    unlink $self->{infoFile};

    if ( defined $self->{scheduledJob}) {
        $self->{scheduledJob}->{socket}->close();        
    }

    if ( defined $self->{runningJob}) {
        $self->{runningJob}->{socket}->close();        
    }

}

sub _addMsgHdr {
    my $self = shift;
    my $msg = shift;
   
    return $msg;
#    return "<message>".$msg."</message>";
}

sub setProviderMarketStatus {
    my $self = shift;
    my $status = shift;

    my $prevStatus = $self->{eco_info}->{$marketStatusTag};
    
    # Changing the market status only in on status
    return 0 if ($self->{eco_info}->{$statusTag} ne $providerOnVal);
    # If the status is the same as the previous status then we skeep
    return 1 if ($status eq $prevStatus);

    $self->{eco_info}->{$marketStatusTag} = $status; 
    $self->{marketLastChanged} = time();
    
    if ($status eq $providerMarketProtectedVal) {
        $self->{eco_info}->{$protectedTimeTag} = $protectedPeriod;
    } else {
        $self->{eco_info}->{$protectedTimeTag} = -1;
    }

    debug_ly(PVD_DBG, sprintf("===> Market Status:  %10s ---> %-10s\n",
                             $prevStatus, $status));
}

sub setMarketType {
    my $self = shift;
    my $type = shift;

    return 0 if ($type ne $providerDistMarketVal && $type ne $providerCentralMarketVal);

    $self->{$providerMarketTypeTag} = $type;

    debug_ly(PVD_DBG, "Entering $type market mode\n");
    
    return 1;
}

sub setProviderStatus {
    my $self = shift;
    my $status = shift;

    my $prevStatus = $self->{eco_info}->{$statusTag};
    return 1 if ($status eq $prevStatus);

    debug_lg(PVD_DBG, "+++++++++++++++++++ status change $prevStatus --> $status\n"); 

    if ($status eq $providerOnVal) {
        #        $self->setProviderMarketStatus($providerMarketFreeVal);
    } elsif ($status eq $providerOffVal) {
        $self->{eco_info}->{$onTimeTag} = 0;
        $self->unScheduleJob("off-mode");
        $self->unloadRunningJob();
    } elsif ($status eq $providerHomeVal) {
        $self->unScheduleJob("off-mode");
        $self->unloadRunningJob();
    } else {
        debug_re(PVD_DBG, "Illegal status $status\n");
        return 0;
    }

    $self->setProviderMarketStatus($providerMarketFreeVal);
    $self->{eco_info}->{$statusTag} = $status;   
    return 1;
}
#****m* providerd/ProviderD->performPeriodicAction
# FUNCTION
#   Decide which cycle to perform.
# SYNOPSIS
#   $self->performPeriodicAction();
#******
sub performPeriodicAction {
    my $self = shift;
    
    my $currTime = time();
    my $secPassed = $currTime - $self->{periodStart};
    my $secLeft = $self->{periodLeft} - $secPassed;

    
    return 
      if($secPassed <  $self->{period});
    
    # The basic time unit has passed so we check if there are expired cycles
    foreach my $c (keys(%{$self->{cycles}})) {
        my $prevCall = $self->{cycles}->{$c}->{prevCall};
        my $cycleVal = $self->{cycles}->{$c}->{cycle};
        # Running cycle
        if(($currTime - $prevCall) >= $cycleVal) {
            #debug_level(PVD_DBG, "Time to perform $c\n");
            my $func = $self->{cycles}->{$c}->{funcName};
            $self->$func();
            $self->{cycles}->{$c}->{prevCall}  = $currTime;
        }
    }
    
    $self->{periodStart} = $currTime;
    
    #    $period_start = $curr_time;
    #    $self->handleHomeNodeMode();
    #    $self->generateInfoFile();
}

sub _initCycleInfo {
    my $self = shift;

    my $currTime = time();
    $self->{periodStart} = $currTime;
    $self->{periodLeft} = $self->{period};
    
    foreach my $c (keys(%{$self->{cycles}})) {
        $self->{cycles}->{$c}->{prevCall} = $currTime;
    }
}

sub prepareFileHandles {
    my $self = shift;
    
    $self->{selectRead} = undef;
    $self->{selectWrite} = undef;
    $self->{selectException} = undef;

    $self->{selectRead} =  new IO::Select();
    $self->{selectWrite} = new IO::Select();
    $self->{selectException} = new IO::Select();
    
    # Adding the file handles
    $self->{selectRead}->add($self->{tcpSock});
    $self->{selectRead}->add($self->{runningJob}->{socket})
      if(defined($self->{runningJob}));

    $self->{selectRead}->add($self->{scheduledJob}->{socket})
      if(defined($self->{scheduledJob}));
    
  }

#****m* providerd/ProviderD->run
# FUNCTION
#   Daemon main loop. Function return only if an exit was requested
#   by receiving a signal or by an error
# SYNOPSIS
#   $self->run();
#******
sub run {
    my $self = shift;
    my $paddr;
    my @map;
    my $debug_level=0;
    my $recv = '';
    my ($command, $arguments);
    my $new_socket;

    $self->setSignalHandlers();
    $self->generateInfoFile();
  
    debug_ly(PVD_DBG, "server started on port $self->{port}\n");
    syslog("info", "server started on port $self->{port}");
    
    $self->_initCycleInfo();
    
    while(1) {
        # Preparing file handles for the select
        $self->prepareFileHandles();
        
        # Checking for a termination signal/event.
	return $self->doExit()
          if($globExit);
        
        my @ready = $self->{selectRead}->can_read($self->{periodLeft});
    
        # Checking if a termination signal/event happend during our sleep
        return $self->doExit()
          if($globExit);

        foreach my $fh (@ready) 
	{
	    # A connection on main TCP socket
	    if($fh == $self->{tcpSock}) {
                $self->handleNewConn();
            }
            # A message from the running job home node
            elsif(defined($self->{runningJob}) and $fh == $self->{runningJob}->{socket}) {
              debug_level(PVD_DBG, "Got message from running job\n");
              $self->handleRunningJobMsg();
            }
            # A message from the scheduled job home node
            elsif(defined($self->{scheduledJob}) and $fh == $self->{scheduledJob}->{socket}) {
              debug_level(PVD_DBG, "Got message from scheduled job\n");
              $self->handleScheduledJobMsg();
            }
            # Unsupported file handles or errors
            else {
              debug_lr(PVD_DBG, "Error un supported message\n");
            }
          }

        # The periodic action is called every timeout or when a message/conn
        # happens. 
	$self->performPeriodicAction();
    }
}

sub setIncPriceMethod {
    my $self = shift;
    my $confH = shift;

    if(!exists($confH->{$incPriceTag})) {
        print STDERR "Missing $incPriceTag in conf file\n";
        return 0;
    }
    my $priceInc = $confH->{$incPriceTag};
    
    return 0
      if(!exists($priceInc->{$incMethodTag}) || !exists($priceInc->{$incMethodParamTag}));
    
    if($priceInc->{$incMethodTag} eq $incPriceFix) {
        $self->{incPrice}->{method} = $incPriceFix;
        $self->{incPrice}->{incFuncName} = "fixIncPrice";
        $self->{incPrice}->{fixParam} = $priceInc->{$incMethodParamTag};
      }
    elsif($priceInc->{$incMethodTag} eq $incPricePercent) {
        $self->{incPrice}->{method} = $incPricePercent;
        $self->{incPrice}->{incFuncName} = "percentIncPrice";
        $self->{incPrice}->{percentParam} = $priceInc->{$incMethodParamTag};
    } 
    else {
        print STDERR "Increment price method $priceInc->{$incMethodTag} is not supported\n";
        return 0;
    }
    
    return 1;
}

sub getPriceInc {
    my $self = shift;
    my $funcName = $self->{incPrice}->{incFuncName};
    return $self->$funcName();
}

sub fixIncPrice {
    my $self = shift;

    return $self->{incPrice}->{fixParam};
}

sub percentIncPrice {
    my $self = shift;

    my $schedPrice = $self->{eco_info}->{$schedPriceTag};
    $schedPrice = $self->{eco_info}->{$minPriceTag}
      if($schedPrice == 0);
    
    my $percent = $self->{incPrice}->{percentParam};
    my $inc = ($percent/100) * $schedPrice;
    $inc = sprintf("%.0f", $inc);
    return $inc;
}


sub setDecPriceMethod {
    my $self = shift;
    my $confH = shift;

    if(!exists($confH->{$decPriceTag})) {
        print STDERR "Missing $decPriceTag in conf file\n";
        return 0;
    }
    my $priceDec = $confH->{$decPriceTag};
    
    return 0
      if(!exists($priceDec->{$decMethodTag}) || !exists($priceDec->{$decMethodParamTag}));
    
    if($priceDec->{$decMethodTag} eq $decPriceFix) {
        $self->{decPrice}->{method} = $decPriceFix;
        $self->{decPrice}->{decFuncName} = "fixDecPrice";
        $self->{decPrice}->{fixParam} = $priceDec->{$decMethodParamTag};
    }
    elsif($priceDec->{$decMethodTag} eq $decPriceMin) {
        $self->{decPrice}->{method} = $decPriceMin;
        $self->{decPrice}->{decFuncName} = "minDecPrice";
        $self->{decPrice}->{percentParam} = $priceDec->{$decMethodParamTag};
    } 
    else {
        print STDERR "Decrement price method $priceDec->{$decMethodTag} is not supported\n";
        return 0;
    }
    
    return 1;
}

sub getPriceDec {
    my $self = shift;
    my $funcName = $self->{decPrice}->{decFuncName};

    return $self->$funcName();
}

sub fixDecPrice {
    my $self = shift;

    return $self->{decPrice}->{fixParam};
}

sub minDecPrice {
    my $self = shift;

    return $self->{eco_info}->{$minPriceTag};
}


#****m* provider/ProviderD->readConfFile
# FUNCTION
#  Reading initial setup from /etc/mosix/sorma
# SYNOPSIS
#   $res = $self->readConf($dir);
# ARGUMENTS
#   $dir   The name of the configuration file to use 
# RETURN VALUE
#  0    On error
#  1    On success
#******
sub readConfFile {
    my $self = shift;
    my $confFile = shift;
    
    return 0 
      if(! -f $self->{confFile} );
    my $confH = XMLin($self->{confFile});
    return 0 if(! $confH);
    debug_ly(PVD_DBG, "Got conf:\n", Dumper([$confH], ["conf"]));
    
    if (! exists($confH->{$providerMarketTypeTag}) || 
        ! $self->setMarketType($confH->{$providerMarketTypeTag})) {
        print STDERR "Missing or invalid market type\n";
        return 0;
    }
    
    if($self->{$providerMarketTypeTag} eq $providerDistMarketVal) {

        $self->{eco_info}->{$incPriceTag} = 1;
        $self->{scheduledJob} = undef;
        $self->{runningJob} = undef;
        $self->{T1Period} = 8;
        $self->{inT1} = 0;


        $self->{cycles}->{marketStatus}  = { 
                                            cycle    => 2,
                                            funcName => 'handleMarketStatus',
                                           };
        
        if(!$self->setIncPriceMethod($confH))  {
            print STDERR "Price increment is not present or in bad format";
            return 0;
        }
        
        # Setting the inc price for the first time
        my $incFuncName = $self->{incPrice}->{incFuncName};
        $self->{eco_info}->{$incPriceTag} = $self->$incFuncName();

        if(!$self->setDecPriceMethod($confH))  {
            print STDERR "Price decrement is not present or in bad format";
            return 0;
        }
    }
    
    # verifying the configuration
    if(exists($confH->{$statusTag})) {
      if (! $self->setProviderStatus($confH->{$statusTag})) {
        print STDERR "Error $statusTag part contain illegal information\n";
        return 0;
      }
    }
    if(exists($confH->{$minPriceTag})) {
        if($confH->{$minPriceTag} =~ /\d+[\.\d+]?/) {
            $self->{eco_info}->{$minPriceTag} = $confH->{$minPriceTag};
        }
        else {
            print STDERR "Error $minPriceTag part contain illegal inforamtion\n";
            return 0;
        }
    }
    $self->{eco_info}->{$nextPriceTag} = $self->{eco_info}->{$minPriceTag};

    my $tfConf = undef;
    if(exists($confH->{$timeFrameTag})) {
        # buildTimeFrames($confH->{$timeFrameTag});
        $tfConf = $confH->{$timeFrameTag};
    }
    $self->{TF} = new Util::TimeFrame('conf' => $tfConf );
    if(!$self->{TF}) {
        print STDERR "Error generating TimeFrame object\n";
        return 0;
    }

    debug_lb(PVD_DBG, Dumper($self->{eco_info}, "Eco"));
    return 1;
}


sub handleOnMode {
  my $self = shift;
  
  my $onTime = $self->{TF}->getOpenStatus();
#  debug_lb(PVD2_DBG, "handling home node mode: $onTime\n");
  if($onTime > 0 || $onTime == -1) {
      $self->setProviderStatus($providerOnVal)
        if ($self->{eco_info}->{$statusTag} eq $providerOffVal);
      
      $self->{eco_info}->{$onTimeTag} = sprintf("%.3f", $onTime);
  } else {
      $self->setProviderStatus($providerOffVal);
  }
  
  $self->generateInfoFile();
}

#****m* providerd/ProviderD->generateInfoFile
# FUNCTION
#  Generating the information file.
# SYNOPSIS
#   $res = $self->generateInfoFile();
# ARGUMENTS
# RETURN VALUE
#  0    On error
#  1    On success
#******
sub generateInfoFile {
    my $self = shift;

    my $xmlStr = "<$economyInfoTag>\n";
    foreach my $k (keys(%{$self->{eco_info}})) {
        my $val = $self->{eco_info}->{$k};
        $xmlStr .= "   <$k>$val</$k>\n";
    }
    $xmlStr .= "</$economyInfoTag>\n";
    
    # Write XML string
#    my $xml = new XML::Simple(NoAttr=>1, RootName=> $economyInfoTag );
#    my $xmlStr = $xml->XMLout($self->{eco_info});
#    $xml = undef;
    open(INFO_FILE, ">$self->{infoFile}") or
      return 0;
    print INFO_FILE $xmlStr;
    debug_ly(PVD3_DBG, "Info File:\n $xmlStr\n");
    close(INFO_FILE);
}

#****m* providerd/ProviderD->handleNewConn
# FUNCTION
#  A connection on the main listening socket was detected.
#  This method handles such a new connection
# SYNOPSIS
#   $res = $self->handleNewConn();
# RETURN VALUE
#  0    On error
#  1    On success
#******
sub handleNewConn {
    my $self = shift;

    my $newconn = $self->{tcpSock}->accept();
    my ($rhostname, $rhostaddr) = getSockPeerInfo($newconn);

    debug_level(PVD_DBG, "Got new connection on TCP sock: $rhostname\n");
    
    my $msg = recvMarketMsg($newconn, $self->{recv_timeout});
    if ($msg) {
        # Keeping the socket so we can return an answer
        $self->{newconn} = $newconn;
        my $closeConn = 0;
        $self->handleNewConMsg($msg, $rhostname, \$closeConn);
        $self->{newconn}->close()
          if($closeConn);
    }
    else {
        debug_level(PVD_DBG, "Nothing received !!!\n");
        syslog("err", "Nothing received on tcp socket\n");
        $newconn->close();
    }
    
    return 1;
}
#****m* providerd/ProviderD->handleNewConMsg
# FUNCTION
#  Parase the protocol messages. The message can be in one of the formats stated
#  In the module description
# SYNOPSIS
#   $res = $self->handle_msg($message);
# ARGUMENTS
#   $message   The message got from the client
# RETURN VALUE
#  0    On error
#  1    On success
#******
sub handleNewConMsg {
    my $self = shift;
    my $message  = shift;
    my $remoteHost = shift;
    my $closeConn = shift;
    
    debug_lg(PVD2_DBG, "Message:\n$message\n");
    
    my $msgHash = XMLin($message);
    if(!$msgHash) {
        debug_lr(PVD_DBG, "Error parsing the message as xml\n");
        return 0;
    }
    
    print Dumper($msgHash, "aa")
      if(isDebugLevelOn(PVD3_DBG));
    

    my $handleResult = 0;
    # Handling the distributed market protocol, which handle its own result
    if(isMsgClass($distMarketClass, $msgHash)) {
        $self->handleDistMarket($msgHash, $remoteHost, $self->{newconn});
        $$closeConn = 0;
    } elsif (isMsgClass($providerCtlClass, $msgHash)) {
        $self->handleProviderCtl($msgHash, $remoteHost, $self->{newconn});
        $$closeConn = 1;
    }
    
    return 1;
}

sub handleProviderCtl {
    my $self = shift;
    my $msgHash = shift;
    my $remoteHost = shift;
    my $socket = shift;
    
    my $resultH;
    my $resultXml;
       
    # Queries hadling
    if (isMsgType($queryType, $msgHash)) {
        
        debug_ly(PVD_DBG, "Received query ".Dumper($msgHash)."\n");
        $self->handleQueries(getData($msgHash), \$resultH);
        
    } elsif(isMsgType($actionType, $msgHash)) {
        debug_ly(PVD_DBG, "Received action ".Dumper($msgHash)."\n");
        $self->handleActions(getData($msgHash), \$resultH);

    } else {
        debug_lr(PVD_DBG, "Error unsupported message\n $msgHash\n");
    }
    
    my $resH;
    $resH->{$marketDataTag}  = $resultH;
    $resH->{$marketClassTag} = $providerCtlClass;
    $resH->{$marketTypeTag}  = $resultType;

    my $xml = new XML::Simple(NoAttr=>1, RootName=>"");
    $resultXml = $xml->XMLout($resH);    

    debug_ly(PVD_DBG, "Result Message:\n$resultXml\n");

    sendMarketMsg($self->{newconn}, $resultXml); 
    
    return 1;
}

sub handleQueries {
    my $self = shift;
    my $queryH = shift;
    my $resultRef = shift;

    foreach my $q (keys(%$queryH)) {
        if($q eq $statusQueryTag) {
            $self->handleStatusQuery($queryH->{$q}, $resultRef);
        }
    }
    
#    $self->{queryResultXml} .= "</$queryResultTag>";
    return 1;
    
}

sub handleStatusQuery {
    my $self = shift;
    my $info = shift;
    my $resultHash = shift;

    if($info eq $allStatusQuery) {
        $$resultHash = $self->{eco_info};
    }

    return 1;
}


sub handleActions {
    my $self = shift;
    my $actionH = shift;
    my $result = shift;
    
 #   $self->{actionResultXml} = "<$actionResultTag>";

    foreach my $a (keys (%$actionH)) {
        debug_lg(PVD_DBG, "Handling action $a\n");
        if($a eq $minPriceActTag) {
            $self->handleMinPriceAction($actionH->{$a}, $result);
        }
        elsif($a eq $pvdStatusActTag) {
            $self->handleProviderStatusAction($actionH->{$a}, $result);
        }
        elsif($a eq $currPriceActTag) {
            $self->handleCurrPriceAction($actionH->{$a}, $result);
        }
        elsif($a eq $bidActTag) {
            $self->handleBidAction($actionH->{$a}, $result);
        }
    }
#    $self->{actionResultXml} .= "</$actionResultTag>";
    return 1;
}

sub handleMinPriceAction {
    my $self = shift;
    my $info = shift;
    my $resultHash = shift;
    my $retVal = 0;

    my $newMinPrice = $info;
    $newMinPrice = 0 if($newMinPrice < 0);
    
    $self->{eco_info}->{$minPriceTag} =  $newMinPrice;
    $$resultHash->{$minPriceActTag} = $resultOKTag;
#    $self->{actionResultXml} .= "<$minPriceActTag>ok</$minPriceActTag>";
    $self->generateInfoFile();
    $retVal = 1;
    return $retVal;
}

sub handleCurrPriceAction {
    my $self = shift;
    my $info = shift;
    my $resultHash = shift;
    my $retVal = 0;

    my $newCurrPrice = $info;
    $newCurrPrice = 0 if($newCurrPrice < 0);
    
    $self->{eco_info}->{$currPriceTag} =  $newCurrPrice;
#    $self->{actionResultXml} .= "<$currPriceActTag>ok</$currPriceActTag>";
    $$resultHash->{$marketDataTag}->{$currPriceActTag} = $resultOKTag;
    $self->generateInfoFile();
    $retVal = 1;
    return $retVal;
}

sub handleProviderStatusAction {
    my $self = shift;
    my $info = shift;
    my $resultHash = shift;
    my $retVal = 0;

    $retVal = $self->setProviderStatus($info);

    my $resStr =  $retVal ? $resultOKTag : $resultErrorTag;
    $$resultHash->{$pvdStatusActTag} = $resStr;
    $self->generateInfoFile();
    
    return $retVal;
}


sub handleDistMarket {
  my $self = shift;
  my $dmMsg = shift;
  my $remoteHost = shift;
  my $socket = shift;

  #debug_lg(PVD_DBG, "Handling Dist Market message\n");
 
  my $resultMsg = "";
  if(isMsgType($dmBidType, $dmMsg)) {
      $self->handleDMPBid($dmMsg, $remoteHost, $socket);
  } elsif(isMsgType($dmJobDoneType, $dmMsg)) {
      $self->handleJobDoneMsg($dmMsg, $remoteHost);
  } elsif(isMsgType($dmJobNoBgtType, $dmMsg)) {
      $self->handleJobNoBgtMsg($dmMsg, $remoteHost);
  } elsif(isMsgType($dmJobSwitchType, $dmMsg)) {
      $self->handleJobSwitchMsg($dmMsg, $remoteHost);
  }

  return 1;
}

sub isRunningEqualScheduled {
    my $self = shift;
    my $rj = $self->{runningJob};
    my $sj = $self->{scheduledJob};

    return 0 if(!defined($rj) || !defined($sj));

    return 1
      if(($rj->{info}->{host} eq $sj->{info}->{host}) &&
         ($rj->{info}->{jobId} eq $sj->{info}->{jobId}));
    return 0;
}



sub setScheduledJob {
    my $self = shift;
    my $jobInfo = shift;
    my $remoteHost = shift;
    my $socket = shift;


    $self->{scheduledJob}->{info} = $jobInfo;
    $self->{scheduledJob}->{host} = $remoteHost;
    $self->{scheduledJob}->{socket} = $socket;

    $self->{eco_info}->{$schedPriceTag} = $jobInfo->{val};
    $self->{eco_info}->{$incPriceTag} = $self->getPriceInc();
    $self->{eco_info}->{$nextPriceTag} = $jobInfo->{val} + $self->{eco_info}->{$incPriceTag};


    # If there is no running process or the scheduled is not equal running T1 
    # is started;
#    my $rj = $self->{runningJob};
#    if(!$rj || !$self->isRunningEqualScheduled()) {
#        $self->{inT1} = 1;
#        $self->{T1Start} = time();
#        debug_ly(PVD_DBG, "-----------> Starting T1\n");
#    }
    
}

sub clearScheduledJob {
    my $self = shift;
    
    return if(!defined($self->{scheduledJob}));

    $self->{scheduledJob}->{socket}->close() 
      if (defined($self->{runningJob}) &&
          ($self->{scheduledJob}->{socket} != $self->{runningJob}->{socket}));
    delete($self->{scheduledJob});
    $self->{scheduledJob} = undef;

    $self->{eco_info}->{$nextPriceTag} = $self->{eco_info}->{$schedPriceTag};
    $self->{eco_info}->{$schedPriceTag} = 0;
    $self->setProviderMarketStatus($providerMarketFreeVal);
}

sub unScheduleJob {
  my $self = shift;
  my $reason = shift;
  my $val = shift;

  return if(!defined($self->{scheduledJob}));
  
  my $jobId = $self->{scheduledJob}->{info}->{jobId};
  my $host  = $self->{scheduledJob}->{info}->{host};
  debug_lg(PVD_DBG, "Unscheduling a job $jobId from $host\n");

  createAndSendMarketMsg($self->{scheduledJob}->{socket}, $distMarketClass, $dmUnScheduleType, 
                         $jobId, $reason, $val);
#  my $xmlStr = Util::DistMarketProtocol::createDMMsg($dmScheduleType, $jobId, $reason, $val);
  
#  $xmlStr = $self->_addMsgHdr($xmlStr);
#  $self->{scheduledJob}->{socket}->send($xmlStr);
  $self->clearScheduledJob();
}


sub setRunningJob {
  my $self = shift;
  
  if (! $self->{scheduledJob}) {
    debug_lr(PVD_DBG, "Error: no scheduled job found");
    return 1;
  }

  # Copying the hash of the scheduled job
  %{$self->{runningJob}} =  %{$self->{scheduledJob}};
  return 0;
}

sub clearRunningJob {
    my $self = shift;
    my $reason = shift;

    return if(!defined($self->{runningJob}));
    $self->{runningJob}->{socket}->close();
    $self->{eco_info}->{$currPriceTag} = 0;
    delete($self->{runningJob});
    $self->{runningJob} = undef;
    $self->setProviderMarketStatus($providerMarketFreeVal);
}

#****m* providerd/ProviderD->unloadRunningJob
# FUNCTION
#  Send an unloadJob message to the client which is currently running
# SYNOPSIS
#   $res = $self->unloadRunningJob()
# RETURN VALUE
#  0    On error
#  1    On success
#******
sub unloadRunningJob {
  my $self = shift;
 
  if (!defined($self->{runningJob})) {
      return 1;
  }
  my $jobId = $self->{runningJob}->{info}->{jobId};
  my $host  = $self->{runningJob}->{info}->{host};
  debug_lg(PVD_DBG, "Unloading job $jobId from $host\n");
  

  createAndSendMarketMsg($self->{runningJob}->{socket}, $distMarketClass, $dmUnloadJobType, 
                         $self->{runningJob}->{info}->{jobId});
#  my $msg = Util::DistMarketProtocol::createDMMsg($dmUnloadJobType, 
#                                                  $self->{runningJob}->{info}->{jobId});
#  $msg = $self->_addMsgHdr($msg);
  
  
#  my $socket = $self->{runningJob}->{socket};
#  $socket->send($msg);
  $self->clearRunningJob();

  return 1;
}


sub handleDMPBid {
    my $self = shift;
    my $info = shift;
    my $remoteHost = shift;
    my $socket = shift;
    my $resultHash = {};
    my $retVal = 0;
    
    my $bidVal = $info->{val};
    
    # Returning schedule message
    my $xmlStr;
    
    my $p = $self->{eco_info}->{$nextPriceTag};
      
    debug_lg(PVD_DBG, "--------> Handling bid $bidVal from $remoteHost next price is $p\n");

    my $schedule = 0;
    # Off mode or home node mode
    if($self->{eco_info}->{$statusTag} eq $providerOffVal 
       || $self->{eco_info}->{$statusTag} eq $providerHomeVal) {
        debug_lg(PVD_DBG, "Rejecting bid $self->{eco_info}->{$statusTag}\n");
        createAndSendMarketMsg($socket, $distMarketClass, $dmRejectType, 
                               $info->{jobId}, $self->{eco_info}->{$statusTag}, 0);
    }
    # In protected mode
    elsif($self->{eco_info}->{$marketStatusTag} eq $providerMarketProtectedVal) {
        debug_lg(PVD_DBG, "Rejecting bid in protected mode\n");
        createAndSendMarketMsg($socket, $distMarketClass, $dmRejectType, $info->{jobId}, 
                               $self->{eco_info}->{$statusTag}, $self->{eco_info}->{$protectedTimeTag});
    }
    # Bid value is too low
    elsif($bidVal < $p) {
        debug_lg(PVD_DBG, "Rejecting bid price is too low\n");
        createAndSendMarketMsg($socket, $distMarketClass, $dmRejectType, 
                               $info->{jobId}, "price", $p); 
    } 
    # Accepting Bid, making the job the scheduled job
    else {
        debug_lg(PVD_DBG, "Accepting bid $bidVal of job: $info->{jobId} from $remoteHost\n");
        createAndSendMarketMsg($socket, $distMarketClass, $dmScheduleType,
                               $info->{jobId}, "price", $bidVal);

        $schedule = 1;
    }
    
    if($schedule) {
        # If there is already a scheduled job we should send it an un-schedule 
        if(defined($self->{scheduledJob})) {
            $self->unScheduleJob("outbid", $bidVal);
        }
        $self->setScheduledJob($info, $remoteHost, $socket);
        $self->{newconn} = undef
          if (defined($self->{newconn}) && ($socket == $self->{newconn})); 

        $self->setProviderMarketStatus($providerMarketBidVal);
    } else {
      $socket->close()
        if (! defined($self->{runningJob}) ||  $socket != $self->{runningJob}->{socket});
    }
        
    return 1;
}

sub handleMarketStatus {
    my $self = shift;
    
  
    return 0 if ($self->{eco_info}->{$statusTag} ne $providerOnVal);
    my $timeInStatus = time() - $self->{marketLastChanged};
#    debug_lg(PVD_DBG, "handling market status ($timeInStatus)\n");    

    my $change = 0;
    if ($self->{eco_info}->{$marketStatusTag} eq $providerMarketFreeVal) {
        if ($timeInStatus > $freePeriod) {
            
            $self->decreasePrice();
            $change = 1;
        }
    } elsif ($self->{eco_info}->{$marketStatusTag} eq $providerMarketProtectedVal) {
        my $protectedTimeLeft = $protectedPeriod - $timeInStatus;
        
        $self->{eco_info}->{$protectedTimeTag} = $protectedTimeLeft;
        if($protectedTimeLeft < 0) {
            $self->setProviderMarketStatus($providerMarketAvailableVal); 

            my $jobId = $self->{runningJob}->{info}->{jobId};
            my $host  = $self->{runningJob}->{info}->{host};
            debug_lg(PVD_DBG, "Unprotecting a job $jobId from $host\n");
            createAndSendMarketMsg($self->{runningJob}->{socket}, $distMarketClass, 
                                   $dmJobUnprotectType, $jobId);

            $change = 1;
        }
    } elsif ($self->{eco_info}->{$marketStatusTag} eq $providerMarketBidVal) {
        if ($timeInStatus > $bidPeriod) {
            
            # Unloading the currently running job if schedule != running
            my $protected = 0;
            if (!$self->isRunningEqualScheduled()) {
                $protected = 1;
                if(!$self->unloadRunningJob()) {
                    debug_ly(PVD_DBG, "Unload failed!!!\n");
                }
            }
            
            # Sending a bidOver message to the scheduled job in any case
            my $jobId = $self->{scheduledJob}->{info}->{jobId};
            my $host  = $self->{scheduledJob}->{info}->{host};
            my $schedPrice = $self->{eco_info}->{$schedPriceTag};

            createAndSendMarketMsg($self->{scheduledJob}->{socket}, $distMarketClass, 
                                   $dmBidOverType, $jobId, $schedPrice);

            $self->{eco_info}->{$currPriceTag} = $self->{scheduledJob}->{info}->{val};
            if ($protected) {
                $self->setProviderMarketStatus($providerMarketProtectedVal);
                $self->setRunningJob();
            } else {
                $self->setProviderMarketStatus($providerMarketAvailableVal);
            }

            #if(!$self->loadScheduledJob()) {
            #    $self->unScheduleJob("error in socket\n");
            #}
           
            $change = 1;
        }
    }

    $self->{marketLastChanged} = time()
      if($change == 1);
}

sub decreasePrice {
    my $self = shift;
    my $res;

    my $oldprice = $self->{eco_info}->{$nextPriceTag};
    return 1 if ($oldprice == $self->{eco_info}->{$minPriceTag});

    $res = $self->{eco_info}->{$nextPriceTag} - $self->getPriceDec();
    
    $res = $self->{eco_info}->{$minPriceTag} if ( $res < $self->{eco_info}->{$minPriceTag});

    $self->{eco_info}->{$nextPriceTag} = $res;
    debug_lr(PVD_DBG, "Decreasing price:  $oldprice ---> $self->{eco_info}->{$nextPriceTag}\n");

    return 1;
}

sub handleHomeNodeMode {
    my $self = shift;
    
    # FIXME and option should be added to the providerd specifing if the
    # home-node mode should be detected


    #my $h = $self->isHomeNodeMode();
    #debug_lb(PVD2_DBG, "Home node check: $h\n");
    #if($h) {
    #    $self->setProviderStatus($providerHomeVal);
    #} else {
    #    # First changing to on status; and then calling the handleOnMode which 
    #    # will take care of the on/off case (according to times)
    #    $self->setProviderStatus($providerOnVal);
    #    $self->handleOnMode();
    #}
}

sub isHomeNodeMode {

    if(!open(LOCAL, $mosix_localProcNumFile)) {
        return 0;
    }
    my $line = <LOCAL>;
    chomp($line);
    if($line == 0) {
        return 0;
    }
    # Running mosps -L to see if there are local processes
    my @mospsOut = `mosps -L`;
    debug_ly(PVD2_DBG, "mosps output:\n@mospsOut\n");

    # There are real local processes
    if(@mospsOut > 1) {
        return 1;
    }
    # Hmm we have the /proc/mosix/local > 0 but no locals
    # So we might have a linux process or guest processes from the cluster
    @mospsOut = `mosps -V`;
    
    # In this we have guests so this is not a native linux process, but guests
    # so we are not running a home node
    if(@mospsOut > 1) {
        return 0;
    } 
    # In this case it must be a linux process
    else {
        return 1;
    }

    return 0;
}


#****m* providerd/ProviderD->loadScheduledJob
# FUNCTION
#  Send a loadJob message to the client which is currently scheduled
# SYNOPSIS
#   $res = $self->loadScheduledJob()
# RETURN VALUE
#  0    On error
#  1    On success
#******
sub loadScheduledJob {
    my $self = shift;

    # Checking if for some reason the scheduled job was canceled since 
    # T1 has started
    return 0
      if(!defined($self->{scheduledJob}));

    my $sock = $self->{scheduledJob}->{socket};

    my $jobId = $self->{scheduledJob}->{info}->{jobId};
    my $host  = $self->{scheduledJob}->{info}->{host};

    debug_lg(PVD_DBG, "Loading a job $jobId from $host\n");
    createAndSendMarketMsg($sock, $distMarketClass, $dmLoadJobType, $jobId);

    #set the current running job to the scheduled job
    $self->setRunningJob();

    # Setting current price
    $self->{eco_info}->{$currPriceTag} = $self->{scheduledJob}->{info}->{val};

    # Going into protected mode
    $self->setProviderMarketStatus($providerMarketProtectedVal);  
  
    return 1;
}



sub handleRunningJobMsg {
  my $self = shift;

  my $rhost = $self->{runningJob}->{host};
  my $sock = $self->{runningJob}->{socket};
  
  my $msg = recvMarketMsg($sock, $self->{recv_timeout});
  
  if(!$msg) {
      debug_lr(PVD_DBG, "Error receiving message from running job home\n");
      if($self->isRunningEqualScheduled()) {
          debug_lg(PVD_DBG, "Running job and scheduled job are the same\n");
          $self->clearScheduledJob();
      }
      $self->clearRunningJob();
      return 0;
  }
  
  debug_ly(PVD2_DBG, "Message from running job home ($rhost):\n$msg\n");
  
  my $msgHash = XMLin($msg);
  
  if(!$msgHash) {
      debug_lr(PVD_DBG, "Error parsing the message as xml\n");
      $self->clearRunningJob();
      return 0;
  }
  
  if(! isMsgClass($distMarketClass, $msgHash)) {
      debug_lr(PVD_DBG, "Error: message from running job home is not a dist-market msg\n");
      return 0;
  }
  
  return $self->handleDistMarket($msgHash, $rhost, $sock);
}

sub handleJobDoneMsg {
    my $self = shift;
    my $doneH = shift;
    my $rhost = shift;

    debug_ly(PVD_DBG, "-----------> Handling jobDoneMessage($doneH->{jobId}) from $rhost\n");
    # The job is the running job
    
    if(defined($self->{runningJob}) &&
       $doneH->{jobId} == $self->{runningJob}->{info}->{jobId} &&
       $rhost eq $self->{runningJob}->{host}) {

        if($self->isRunningEqualScheduled()) {
            debug_lg(PVD_DBG, "Running job and scheduled job are the same\n");
            $self->clearScheduledJob();
        }
        $self->clearRunningJob();
        $self->setProviderStatus($providerOnVal);
        
    } 
    # The job is the scheduled job
    elsif(defined($self->{scheduledJob} &&
                   $doneH->{jobId} == $self->{scheduledJob}->{info}->{jobId} &&
                   $rhost eq $self->{scheduledJob}->{host})) {
        $self->clearScheduledJob();
    }

    return 1;
}

sub handleJobSwitchMsg {
    my $self = shift;
    my $switchH = shift;
    my $rhost = shift;

    debug_ly(PVD_DBG, 
             "-----------> Handling jobSwitchMessage ($self->{runningJob}->{info}->{jobId} -> $switchH->{jobId}) from $rhost\n");
    
    return 0 if $rhost ne $self->{runningJob}->{host};

    # assume only scheduled jobs being switch
    $self->{scheduledJob}->{info}->{jobId} = $switchH->{jobId};
    $self->setRunningJob();
    # The job is the running job
    #if(defined($self->{runningJob}) &&
    #   ($switchH->{jobId} == $self->{runningJob}->{info}->{jobId})) {

#        if($self->isRunningEqualScheduled()) {
#            $self->{scheduledJob}->{info}->{jobId} = $switchH->{jobId};
#        }
#        $self->{runningJob}->{info}->{jobId} = $switchH->{jobId};
#    } 
#    # The job is the scheduled job
#    else {
#        $self->{scheduledJob}->{info}->{jobId} = $switchH->{jobId}; 
#    }

    return 1;
}

sub handleJobNoBgtMsg {
    my $self = shift;
    my $noBgtH = shift;
    my $rhost = shift;

    debug_ly(PVD_DBG, "-------------->  Handling job no budget message\n");
    # The job is the running job
    if(defined($self->{runningJob}) &&
       $noBgtH->{jobId} == $self->{runningJob}->{info}->{jobId} &&
       $rhost eq $self->{runningJob}->{host}) {

        if($self->isRunningEqualScheduled()) {
            debug_lg(PVD_DBG, "Running job and scheduled job are the same\n");
            $self->clearScheduledJob();
        }
        $self->clearRunningJob();
        $self->setProviderStatus($providerOnVal);
        
    } 
    # The job is the scheduled job
    else {
        $self->clearScheduledJob();
    }

    return 1;
}

sub handleScheduledJobMsg {
  my $self = shift;

  my $rhost = $self->{scheduledJob}->{host};
  my $sock = $self->{scheduledJob}->{socket};
  my $msg = recvMarketMsg($sock, $self->{recv_timeout});
  
  if(!$msg) {
    debug_lr(PVD_DBG, "Error receiving message from scheduled job\n");
    $self->clearScheduledJob();
    return 0;
  }
  
  debug_ly(PVD_DBG, "Message from scheduled:\n$msg\n");
  
  my $msgHash = XMLin($msg);
  if(!$msgHash) {
    debug_lr(PVD_DBG, "Error parsing the message as xml\n");
    $self->unScheduleJob("error parsing message");
    return 0;
  }
  
  if(! isMsgClass($distMarketClass, $msgHash)) {
      debug_lr(PVD_DBG, "Error: message from running job home is not a dist-market msg\n");
      return 0;
  }
  
  return $self->handleDistMarket($msgHash, $rhost,  $sock);
}


# ################################################################################
# #****m* BootMonitor/BootMonitorD->new
# # FUNCTION
# #
# # SYNOPSIS
# #
# # ARGUMENTS
# #
# # RETURN VALUE
# #  0    On error
# #  1    On success
# #******


1;







