#  NodeDistMarket $Id: DistMarket.pm,v 1.8 2007-10-23 11:38:20 elylevy Exp $ #  


#****c* economyd/NodeDistMarket
# FUNCTION
# 
# The NodeDistMarket runs the distributed market algorithm from the nodes point
# of view. This includes
#
# Choosing the candidat to run from all the available processes
# Calclulating the best node suitable for this candidat
# Responding to messages from other providers

package economyd::DistMarket;

use Errno;
use Sys::Syslog;
use Data::Dumper; 
use XML::Simple;

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::TimeFrame;
use economyd::EconomyParam;
use economyd::Market;
use Util::JobManager;
use Util::AssignManager;
use Util::ProviderManager;
use Util::DistMarketProtocol;
use Util::MarketProtocol;
use providerd::ProviderParam;

use strict;

use vars qw(@ISA);

@ISA = qw(economyd::Market);

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    
    my $self = $class->SUPER::new(@_);

    if(!$self) {
        debug_lr(MARKET_DBG, "Error creating DistMarket object\n");
        return undef
    }
    $self->{marketName} = "Distributed";

    return $self;
}

###################################
## Helper functions
###################################
sub msgJobProviders {
    my $self = shift;
    my $msg  = shift;
    my $job  = shift;
    my $send = {};
    
    my $jobH = $self->{jobMgr}->getJobInfo($job);

    my $where = $jobH->{where};
    if($jobH->{status} eq JOB_RUN_STAT and defined $where) {    
        $self->{providerMgr}->sendMsg($where, $msg);
        $send->{$where} = 1;
    }
    
    $where = $jobH->{'sched-where'};
    if($where ne "" && ! exists $send->{$where}) {
        $self->{providerMgr}->sendMsg($where, $msg);
        $send->{$where} = 1;
    }

    $where = $jobH->{'bid-where'};
    if($where ne "" && ! exists $send->{$where}) {
        $self->{providerMgr}->sendMsg($where, $msg);
        $send->{$where} = 1;
    }
}

# A function for the foreach job to reset the status of all jobs relating to a provider
sub _resetProcMarketStat {
  my $jobH = shift;
  my $data = shift;
  my $jm   = shift;
  
  my $provider = $data;
  
  if ($jobH->{'sched-where'} eq $provider || $jobH->{'bid-where'} eq $provider)
    {
    $jm->setJobMarketStatus($jobH->{id}, JOB_READY_MARKET_STAT, "");
  }
}

## A compare price function, so we can sort jobs by their max-pay
my $_jmgr;
sub _maxPriceCmp {
    my $ja = $_jmgr->getJobInfo($a);
    my $jb = $_jmgr->getJobInfo($b);
    
    return $ja->{'max-pay'} <=> $jb->{'max-pay'};
} 


my $_pmgr;
sub _providerPriceCmp {
    my $pa = $_pmgr->getProviderInfo($a);
    my $pb = $_pmgr->getProviderInfo($b);

    return $pa->{$nextPriceTag} <=> $pb->{$nextPriceTag};
}


sub choose {
    my $self = shift;
    my @matchList = ();
    
    
    # Get a list of all the processes which are not running 
    my $data;
    $data->{jobs} = [];
    $data->{usedProviders} = {};
    $data->{protectedProviders} = {};

    $self->{jobMgr}->foreachJob(\&_getJobs, $data);

    # Next sort the candidates by price
    $_jmgr =  $self->{jobMgr};
    my @sortedJobs = sort _maxPriceCmp @{$data->{jobs}};
    

    # Get a list of all available providers
    $data->{providers} = [];
    $self->{providerMgr}->foreachProvider(\&_getProviders, $data);
    $_pmgr = $self->{providerMgr};
    my @sortedProviders = sort  _providerPriceCmp @{$data->{providers}};
    
    foreach my $j (@sortedJobs) {
        my $jh = $self->{jobMgr}->getJobInfo($j);
        my $pIndex = 0;
        
        # checking if there are more providers
        last if(!@sortedProviders);
        foreach my $p (@sortedProviders) {
            my $ph = $self->{providerMgr}->getProviderInfo($p);
            
            # We should also add here some memory considerations and others
            my $bidVal = $ph->{$nextPriceTag};
            my $sched = 0;

            if ($jh->{'max-pay'} >= $bidVal) {

                # check if it is a used provider and if so check if the value of the current
                # proccess is less than the one we have now. if so set val to -1 (switch).
                if (exists $data->{usedProviders}->{$p}) {
                    my $rjh = $self->{jobMgr}->getJobInfo($data->{usedProviders}->{$p});
                    if ($jh->{'max-pay'} > $rjh->{'max-pay'} && $jh->{'curr-pay'} < $rjh->{'curr-pay'}) {
                        debug_ly(DMARKET_DBG, "Got job to switch $rjh->{id} ($rjh->{'max-pay'}) with $j ($jh->{'max-pay'})\n");
                        push @matchList, { jobId => $j, host => $p, 
                                           val => $bidVal, oldJobId => $rjh->{id}};
                        $sched = 1;
                    }
                }
                # check if the process is running elsewhere. 
                #If so we check that the price the job is  paying there is indeed higher.
                elsif(($jh->{'curr-pay'} == 0) ||
                   (($jh->{'curr-pay'} > 0) and ($bidVal < $jh->{'curr-pay'}))) {
                    debug_ly(DMARKET_DBG, "Got match job $j provider $p bid $bidVal\n");
                    push @matchList, { jobId => $j, host => $p, val => $bidVal};
                    $sched = 1;
                } 
            }
            # remove the provider from the list and move to next job.
            splice @sortedProviders, $pIndex, 1 if ($sched == 1);
            last if ($sched == 1);

            $pIndex++
        }
    }
#    foreach my $match (@matchList) {
#        print "Match $match->{jobId} with $match->{host} bid $match->{val}\n";
#    }
    
    return \@matchList;
    
}

# A function for the foreachJob, to get all jobs that can be assigned
sub _getJobs {
    my $jobH = shift;
    my $data = shift;
    my $jm   = shift;
    
    # Taking all the jobs which are in market ready status which means that 
    # such jobs safly bid
    if($jobH->{'market-status'} eq JOB_READY_MARKET_STAT) {
        push @{$data->{jobs}}, $jobH->{id};
        
        $data->{usedProviders}->{$jobH->{'sched-where'}} = $jobH->{id}
          if ($jobH->{'sched-where'} ne "");
        
    } elsif ($jobH->{'market-status'} eq JOB_PROTECTED_MARKET_STAT || 
             $jobH->{'market-status'} eq JOB_WIN_MARKET_STAT) {
        $data->{protectedProviders}->{$jobH->{'sched-where'}} = $jobH->{id};
    }
    
    $data->{protectedProviders}->{$jobH->{'bid-where'}} = $jobH->{id}
      if ($jobH->{'bid-where'} ne "");
 
}

# A function for the foreachProvider to get all providers 
# in status "on" and not protected
sub _getProviders {
    my $providerH = shift;
    my $data = shift;
    
    if($providerH->{status} eq $providerOnVal) {
        push @{$data->{providers}}, $providerH->{name}
          if(!exists($data->{protectedProviders}->{$providerH->{name}}));
    }
}

#****m* economyd/NodeDistMarket->doBids
# FUNCTION
#   Sending the bid messages to the providers using the ProviderManager
# SYNOPSIS
#   $res = $self->doBids($matchList)
# ARGUMENTS
#   $matchList   A reference to a list of matches where each match is a hash containing
#                host, jobId, val. 
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub doBids {
    my $self = shift;
    my $matchList = shift;
    
    foreach my $match (@$matchList) {
        my $destHost = $match->{host};

        # Replacing the host with our name, and using the origianl host as the
        # destination host to send the bid to.
        $match->{host} = $self->{myHostName};

        if (defined $match->{oldJobId}) {
            my $msg = createMarketMsg($distMarketClass, $dmJobSwitchType, $match->{jobId});
            debug_ly(DMARKET_DBG, "job switch msg: $match->{val} \n$msg");
            if($self->{providerMgr}->sendMsg($destHost, $msg)) {
                $self->{jobMgr}->setJobStatus($match->{jobId}, JOB_MIG_STAT, 
                                              $destHost);
                $self->{jobMgr}->setJobMarketStatus($match->{jobId}, 
                                                    JOB_READY_MARKET_STAT, $destHost, $match->{val});
                
                $self->{jobMgr}->setJobStatus($match->{oldJobId}, JOB_SUSPEND_STAT, "");
                $self->{jobMgr}->setJobMarketStatus($match->{oldJobId}, JOB_READY_MARKET_STAT, 
                                                    "", 0);
                
            } else {
                debug_lr(DMARKET_DBG, "Error sending job switch msg from ". 
                         "$match->{host} to $destHost\n");
            }
        } else {
            my $msg = createMarketMsg($distMarketClass, $dmBidType, $match);
            debug_ly(DMARKET_DBG, "bid msg:\n$msg");
            if($self->{providerMgr}->sendMsg($destHost, $msg)) {
                $self->{jobMgr}->setJobMarketStatus($match->{jobId}, JOB_BID_MARKET_STAT, 
                                                    $destHost, $match->{val});
            } else {
                debug_lr(DMARKET_DBG, "Error sending bid msg from $match->{host} to $destHost\n");
            }
        } 
    }
}

########################################
## API functions
########################################
sub handleJobStatusEvent {
    my $self = shift;
    my $msgH = shift;
    
    $self->{assignMgr}->assignJob($msgH->{jobId});
}

sub handleJobMarketStatusEvent {
    my $self = shift;
    my $msgH = shift;

     if ($msgH->{stat} eq JOB_NO_BUDGET_MARKET_STAT) {
         my $id = $msgH->{jobId};
         my $msg = createMarketMsg($distMarketClass, $dmJobNoBgtType, $id);
         $self->msgJobProviders($msg, $id);
     }
}

sub handleAddJobEvent {
    my $self = shift;
    my $msgH = shift;
    # Do nothing?
}

sub handleRemoveJobEvent {
    my $self = shift;
    my $msgH = shift;

    my $id = $msgH->{jobId};
    my $msg = createMarketMsg($distMarketClass, $dmJobDoneType, $id);
    $self->msgJobProviders($msg, $id);
}

sub handleRunningJobEvent {
    my $self = shift;
    my $msgH = shift;

    my $id = $msgH->{jobId};
    debug_lb(DMARKET_DBG, "job $id --> running\n");
    my $jh = $self->{jobMgr}->getJobInfo($id);
    if(!$jh) {
        debug_lr(DMARKET_DBG, "Error: got running for $id which is not in job manager\n");
        return;
    }
    $self->{jobMgr}->setJobStatus($id, JOB_RUN_STAT, $jh->{"where"});
}

sub handleMigDoneEvent {
    my $self = shift;
    my $msgH = shift;

    my $id = $msgH->{jobId};
    debug_lb(DMARKET_DBG, "job $id --> mig-done\n");
    my $jh = $self->{jobMgr}->getJobInfo($id);
    if(!$jh) {
        debug_lr(DMARKET_DBG, "Error: got mig-done for $id which is not in job manager\n");
        return;
    }

    # If the job was running before on another node that node should be 
    # informed that the job is done..
    if($jh->{'prev-where'}) {
        my $prevProvider = $jh->{'prev-where'}; 
        my $provider = $jh->{'where'};
        debug_lg(DMARKET_DBG, "Job moved to a different provider ($prevProvider --> $provider)\n");
        my $msg = createMarketMsg($distMarketClass, $dmJobDoneType, $id);
        $self->{providerMgr}->sendMsg($prevProvider, $msg);
    }
    # FIXME should check that the status of the process is indeed migrating
    #$jh->{$
    $self->{jobMgr}->setJobStatus($id, JOB_RUN_STAT, $jh->{"where"});
} 

sub handleRegisterEvent  { 
    my $self = shift;
    my $msgH = shift;
    
}

sub handleProviderMsg {
    my $self = shift;
    my $provider = shift;

    
    debug_ly(DMARKET_DBG, "Handling a message from provider $provider\n");

    my $msg = $self->{providerMgr}->receiveMessage($provider);

    if(!$msg) {
        debug_lr(DMARKET_DBG, "Error receiving message from $provider\n");
        $self->{jobMgr}->foreachJob(\&_resetProcMarketStat, $provider);
        return 0;
    }
    debug_lg(DMARKET_DBG, "MSG:$msg\n");
    my $distMarketMsg = XMLin($msg, NoAttr=>1);
    if(!$distMarketMsg) {
        debug_lr(DMARKET_DBG, "Error while parsing xml message from provider $provider\n");
        return 0;
    }
    
    if(! isMsgClass($distMarketClass, $distMarketMsg)) {
        debug_lr(DMARKET_DBG, "Error message from provider is not a dist market message\n");
        return 0;
    }
    
    # Schedule message
    if(isMsgType($dmScheduleType, $distMarketMsg)) {
        debug_lg(DMARKET_DBG, "Job $distMarketMsg->{jobId} SCHEDULED on $provider\n");
        $self->{jobMgr}->setJobMarketStatus($distMarketMsg->{jobId}, JOB_WIN_MARKET_STAT, $provider);
    }
    # Reject message
    elsif(isMsgType($dmRejectType, $distMarketMsg)) {
        debug_lg(DMARKET_DBG, " Job $distMarketMsg->{jobId} REJECTED on $provider\n");
        $self->{jobMgr}->setJobMarketStatus($distMarketMsg->{jobId}, JOB_READY_MARKET_STAT, "");
    }
    # Unschedule message
    elsif(isMsgType($dmUnScheduleType, $distMarketMsg)) {
        debug_lg(DMARKET_DBG, "Job $distMarketMsg->{jobId} UN-SCHEDULED on $provider\n");
        $self->{jobMgr}->setJobMarketStatus($distMarketMsg->{jobId}, JOB_READY_MARKET_STAT, "");
        #        $self->choose();
    }

    # BidOver message
    elsif(isMsgType($dmBidOverType, $distMarketMsg)) {
        debug_lg(DMARKET_DBG, "Bid-Over for Job $distMarketMsg->{jobId} from $provider\n");
        if($self->{jobMgr}->isRunningOn($distMarketMsg->{jobId}, $provider)) {
            $self->{jobMgr}->setJobMarketStatus($distMarketMsg->{jobId}, JOB_READY_MARKET_STAT, $provider);
        } else {
            $self->{jobMgr}->setJobStatus($distMarketMsg->{jobId}, JOB_MIG_STAT, $provider);
            $self->{jobMgr}->setJobMarketStatus($distMarketMsg->{jobId}, JOB_PROTECTED_MARKET_STAT, $provider);
            debug_lg(DMARKET_DBG, "Loading Job $distMarketMsg->{jobId} on $provider\n");
        }
    }
    # Unload Job message
    elsif(isMsgType($dmUnloadJobType, $distMarketMsg)) {
        $self->{jobMgr}->setJobStatus($distMarketMsg->{jobId}, JOB_SUSPEND_STAT, "");
        debug_lg(DMARKET_DBG, "Unloading Job $distMarketMsg->{jobId} from $provider\n");
        $self->{jobMgr}->setJobMarketStatus($distMarketMsg->{jobId}, JOB_READY_MARKET_STAT, "", 0);
    } 
    # Unprotect Job message
    elsif(isMsgType($dmJobUnprotectType, $distMarketMsg)) {
      $self->{jobMgr}->setJobMarketStatus($distMarketMsg->{jobId}, JOB_READY_MARKET_STAT, $provider);
      debug_lg(DMARKET_DBG, "Unprotecting Job $distMarketMsg->{jobId} on $provider\n");
    }
    else {
        debug_lr(DMARKET_DBG, "Error: unrecognized dist market message\n");
        return 0;
    }
    return 1;
}


sub periodicRunMarket {
    my $self = shift;

    my $matchList = $self->choose();
    $self->doBids($matchList);

    return 1;
}












# #****m* economyd/NodeDistMarket->getJobProviders
# # FUNCTION
# #   Return a list of all the job providers (it may be running on one node and 
# #   scheduled to run (win) on another node
# # SYNOPSIS
# #   @providerList = $self->getJobProviders($jobId)
# # ARGUMENTS
# #   $jobId       The job id 
# # RETURN VALUE
# #  @providerList  A list of all the providers this job is associated with
# #******
# sub getJobProviders {
#     my $self = shift;
#     my $job  = shift;
    
#     my $jobH = $self->{jobMgr}->getJobInfo($job);
#     return () if(!$jobH);
    
#     my @l = ();
#     push @l, $jobH->{where}
#       if($jobH->{status} eq JOB_RUN_STAT and defined $jobH->{where});
    
#     push @l, $jobH->{"sched-where"}
#       if($jobH->{'sched-where'} ne "");
    
#     push @l, $jobH->{"bid-where"}
#       if($jobH->{'bid-where'} ne "");

#     return @l;
# }





1;
