
#  ProviderCtl $Id: EconomyCtl.pm,v 1.9 2007-10-23 18:26:07 elylevy Exp $ #  
# 

#****c* economyd/EconomyCtl
# FUNCTION
# 
# This module is used to interface the economy market for queirying it and 
# settint (ctl) varios parameters

package economyd::EconomyCtl;

use strict;
use Socket;
use IO::Socket::INET;
use File::Basename;
use Data::Dumper;
use XML::Simple;

use economyd::EconomyParam; 
use Util::Net; 
use Util::Debug; 
use Util::Misc;

use Util::MarketProtocol;
use Util::AssignManager;
use Util::JobManager;
use Util::ProviderManager;
use providerd::ProviderParam;

#################### Functions from this class ############################
sub new;
sub getStatus;
sub getEconomydStatus;
sub getAssigndStatus;
sub getJobsStatus;
sub getProviderStatus;
############################################################################


my $filename = basename $0;

#****m* economyd/EconomyCtl->new
# FUNCTION
#   Constractor for the EconomyCtl object
# SYNOPSIS
#   $sCtl = new EconomyCtl(prog_name   => "program name");
# ARGUMENTS
#   prog_name        The program name for syslog
# RETURN VALUE
#  undef    On error
#  A reference to a EconomyCtl object on success
#******
sub new 
{
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    my $timeout = 10;
     
    $self->{sdPort} = $edCtlPort;
    $self->{errMsg} = "";
    
    debug_lb(SD_CTL_DBG, "Port: $self->{sdPort}\n");
    bless($self, $class);
    return $self;
}

sub close {
    my $self = shift;
    
}

sub initTCPSock {
    my $self = shift;
    my $machineName = shift;
    
    my $tcpSock = new IO::Socket::INET->new(PeerAddr => $machineName,
                                            PeerPort => $self->{sdPort},
                                            Proto    => 'tcp');
    if (!$tcpSock) {
        debug_lr(PVD_CTL_DBG, "Error generating tcp sock to $machineName\n");
        $self->{errMsg} = "Error generating tcp socket:  $!\n";
        return undef;
    }
    
    return $tcpSock;
}

sub errorMsg {
    my $self = shift;
    return  $self->{errMsg};
}

sub sendMessage {
    my $self = shift;
    my $machine = shift;
    my $msgTypeTag = shift;
    my $msgH  = shift;
    my $resRef  = shift;
    my $xml = new XML::Simple(NoAttr=>1, RootName=>"");
    
    # Generate the XML query from the hash
    $msgH->{$marketClassTag} = $economydCtlClass;
    $msgH->{$marketTypeTag} = $msgTypeTag;

    my $msgXml = $xml->XMLout($msgH);
    debug_lg(SD_CTL_DBG, "XML:\n$msgXml\n");

    # Generate the tcp sock and send the query
    my $tcpSock = $self->initTCPSock($machine);
    return 0 if(!$tcpSock);
    sendMarketMsg($tcpSock, $msgXml);
#    $tcpSock->send($msgXml);

    # First reading the header to learn about the size of the data
    my $response = recvMarketMsg($tcpSock, 5);

    if(!$response) {
        $self->{errMsg} = "Nothing recieved from providerd";
        return 0;
    }
#    debug_lg(SD_CTL_DBG, "Response length:".length($response)."\n");
    $tcpSock->close();
    
    #my $resHash  = $xml->XMLin($response);
    $$resRef = $response;
    return 1;
}


sub getStatus {
    my $self = shift;
    my $type = shift;
    my $machine = shift;
    my $statusResult = shift;
    my $retVal = 0;
    my $ctlH = {};
    my $resH;
    
     my $res = $self->sendMessage($machine, $type, $ctlH, \$resH);
    return 0 if(!$res);
    
    $retVal = 1;
    $$statusResult = $resH;
    return $retVal;
}

sub xmlToHash {
    my $self = shift;
    my $xmlStr = shift;
    my $forceArray = shift;
    my $keyAttr = shift;
    
    debug_lg(ED_CTL_DBG, "XML:\n$xmlStr\n");
    my $h = eval { XMLin($xmlStr,  
                         SuppressEmpty => "",  
                         ForceArray => $forceArray, 
                         KeyAttr => $keyAttr );
               };
    
    if($@) {
        debug_lr(ED_CTL_DBG, "Error converting xml to hash\n$@\n");
        #debug_lr(SD_CTL_DBG, $xmlStr);
        return undef;
    }
    debug_ly(ED_CTL_DBG, Dumper($h));
    return $h;
}

sub getEconomydStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;
    my $res = $self->getStatus($ctlTypeEconomydStatus, $machine, $statusResult);
    return 0 if (!$res);
    
    my $h = $self->xmlToHash($$statusResult); #, [$assigndTag], {$assigndTag => "name"});
    return 0 if(!defined($h));
    $$statusResult = $h->{content};
    return 1;
}

sub getAssigndStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    debug_lb(ED_CTL_DBG, "AS-TAG: $assigndTag\n");
    my $res = $self->getStatus($ctlTypeAssigndStatus, $machine, $statusResult);
    return 0 if(!$res);

    my $h = $self->xmlToHash($$statusResult, [$assigndTag], {$assigndTag => "name"});
    return 0 if(!defined($h));
    
    # Taking the part we need
    if(exists($h->{$assigndListTag}) and ref($h->{$assigndListTag})) {
        $h = $h->{$assigndListTag}->{$assigndTag};
    } else {
        $h = {};
    }

    my $str = "Assignds\n";
    $str .= "--------------------\n";

    foreach my $name (keys %$h) {
        $str .= "$name\n";
    }

    $$statusResult = $str;
    debug_ly(SD_CTL_DBG, Dumper($h));
    return 1;

}
sub getJobsStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    my $res = $self->getStatus($ctlTypeJobsStatus, $machine, $statusResult);
    return 0 if(!$res);

    my $h = $self->xmlToHash($$statusResult, [$jobTag], {$jobTag => "id"});
    return 0 if(!defined($h));

    
    # Taking the part we need
    if(exists($h->{$jobListTag}) and  ref($h->{$jobListTag})) {
        $h = $h->{$jobListTag}->{$jobTag};
    } else {
        $h = {};
    }

    debug_ly(SD_CTL_DBG, Dumper($h));
    my $str = sprintf("%-10s%-10s%-12s%-8s\t%-8s\t%-10s\n", 
                      "ID", "User", "Status", "T runtime", "M runtime", "Where");
    foreach my $id (sort {$a <=> $b} (keys %$h)) {
        my $jobH    = $h->{$id};
        my $status  = $jobH->{$allJobFields->{"status"}};
        my $where   = " - ";
        my $truntime = 0;
        my $mruntime = 0;


        $truntime = $jobH->{$allJobFields->{'total-run-time'}}
          if(exists($jobH->{$allJobFields->{'total-run-time'}}));

        $mruntime = $jobH->{$allJobFields->{'mig-run-time'}}
          if(exists($jobH->{$allJobFields->{'mig-run-time'}}));

        $where =  $jobH->{$allJobFields->{where}}
          if(exists($jobH->{$allJobFields->{where}})); 
       
        my $user = $jobH->{$allJobFields->{"user"}};
        $str .= sprintf("%-10s%-10s%-12s%-8s\t%-8s\t%-10s\n", 
                        $id, $user, $status, $truntime, $mruntime, $where);

    }

    $$statusResult = $str;
    return 1;
    
}

sub getMarketStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;
    
        my $res = $self->getStatus($ctlTypeJobsStatus, $machine, $statusResult);
    return 0 if(!$res);

    my $h = $self->xmlToHash($$statusResult, [$jobTag], {$jobTag => "id"});
    return 0 if(!defined($h));

    
    # Taking the part we need
    if(exists($h->{$jobListTag}) and  ref($h->{$jobListTag})) {
        $h = $h->{$jobListTag}->{$jobTag};
    } else {
        $h = {};
    }

    debug_ly(SD_CTL_DBG, Dumper($h));
    
     my $str = sprintf("%-10s%-10s%-12s%-6s\t%-6s\t%-6s\t%-6s\t%-10s\n", 
                      "ID", "User", "Market", "MaxPay", "CurrPay", "Total", 
                      "Budget", "Where");
    foreach my $id (sort {$a <=> $b} (keys %$h)) {
        my $jobH    = $h->{$id};
        my $maxPay  = $jobH->{$allJobFields->{"max-pay"}};
        my $where   = " - ";
        my $currPay = "0";
        my $marketStatus = "";
        my $totalPay = $jobH->{$allJobFields->{"total-pay"}};
        my $budget  = " - ";
        my $user = $jobH->{$allJobFields->{"user"}};

        $marketStatus = $jobH->{$allJobFields->{"market-status"}}
          if(exists($jobH->{$allJobFields->{"market-status"}})); 
        
        if(exists($jobH->{$allJobFields->{where}})) {
            $where   =  $jobH->{$allJobFields->{where}}
              if($jobH->{$allJobFields->{where}} ne "");
            
            $currPay =  $jobH->{$allJobFields->{"curr-pay"}};
        }
        
        if(exists($jobH->{$allJobFields->{"max-budget"}})) {
            $budget = sprintf("%-6.2f", $jobH->{$allJobFields->{"max-budget"}});
        }

        $str .= sprintf("%-10s%-10s%-6s\t%-6.2f\t%-6.2f\t%-6.2f\t$budget\t%-10s\n", 
                        $id, $user, $marketStatus,
                        $maxPay, $currPay, $totalPay, $where);
    }
    
    $$statusResult = $str;
    return 1;  
}

sub mSortOp { return Util::Misc::machines_sort_func($b , $a); }

sub getProvidersStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    my $res = $self->getStatus($ctlTypeProvidersStatus, $machine, $statusResult);
    return 0 if(!$res);

    my $h = $self->xmlToHash($$statusResult, [$providerTag], {$providerTag => "name"});
    return 0 if(!defined($h));
    
    # Taking the part we need
    if(exists($h->{$providerListTag}) and $h->{$providerListTag} and 
       exists($h->{$providerListTag}->{$providerTag})) {
        $h = $h->{$providerListTag}->{$providerTag};
    } else {
        $h = {};
    }
    debug_ly(SD_CTL_DBG, Dumper($h));
    
    my $str = sprintf("%-12s %-12s %-12s %-12s\n", 
                      "Provider", "Min-Price", "Curr-Price", "Next-Price");  

    foreach my $n (sort mSortOp keys %$h) {
        my $p = $h->{$n};
        $str .= sprintf("%-12s %-12.2f %-12.2f %-12.2f\n", $n, $p->{$minPriceTag}, 
                        $p->{$currPriceTag}, $p->{$nextPriceTag});;
    }
    $$statusResult = $str;

    return 1;
}


sub getClustersStatus {
    my $self = shift;
    my $machine = shift;
    my $statusResult = shift;

    my $res = $self->getStatus($ctlTypeClustersStatus, $machine, $statusResult);
    return 0 if(!$res);
    
    my $h = $self->xmlToHash($$statusResult, [$clusterTag], {$clusterTag => "name"});
    return 0 if(!defined($h));
    
    # Taking the part we need
    $h = $h->{$clustersListTag}->{$clusterTag};
    debug_ly(SD_CTL_DBG, Dumper($h));
    
    my $str;
    $str  .=  "Cluster\tRepresentatives\n";
    foreach my $c (keys %$h) {
        $str .= "$c\t@{$h->{$c}->{$repTag}}\n";
    }
    $$statusResult = $str;
    return 1;
}

sub setDebug {
    my $self = shift;
    my $machine = shift;
    my $type = shift;
    my $listRef = shift;
    
    my $ctlH;
    my $resH;
    $ctlH->{$marketTypeTag} = $type; 
    $ctlH->{levels} = [];
    
    foreach my $l (@$listRef) {
        push @{$ctlH->{levels}}, $l."_DBG"; 
    }
    my $res = $self->sendMessage($machine, $ctlMsgTag, $ctlH, \$resH);
    return $res;
}

sub addDebug {
    my $self = shift;
    my $machine = shift;
    my $listRef = shift;
    return $self->setDebug($machine, $ctlTypeAddDebug, $listRef);
}

sub removeDebug {
    my $self = shift;
    my $machine = shift;
    my $listRef = shift;
    return $self->setDebug($machine, $ctlTypeRemoveDebug, $listRef);
}

sub listDebug {
    my $self = shift;
    my $machine = shift;
    my $resultStr = shift;

    my $ctlH;
    my $resXml;
    $ctlH->{$marketTypeTag} = $ctlTypeListDebug; 
    my $res = $self->sendMessage($machine, $ctlMsgTag, $ctlH, \$resXml);
    
    my $h = $self->xmlToHash($resXml, ["levels"], {});
    return 0 if(!defined($h));
    
    my $str = "economyd debug levels:\n";
    foreach my $l (@{$h->{levels}}) {
        $str .= "$l\n";
    }
    $$resultStr = $str;
    return $res;
} 

sub setValue {
    my $self = shift;
    my $machine = shift;
    my $jid = shift;
    my $value = shift;

    return 0 if(!defined $jid);
    return 0 if(!defined $value);

    my $ctlH;
    my $resH;
    
    $ctlH->{$marketTypeTag} = $ctlTypeSetValue;
    $ctlH->{jobID} = $jid;
    $ctlH->{value} = $value;
    
    my $res = $self->sendMessage($machine, $ctlMsgTag, $ctlH, \$resH);
    return $res;
}

1;


    
