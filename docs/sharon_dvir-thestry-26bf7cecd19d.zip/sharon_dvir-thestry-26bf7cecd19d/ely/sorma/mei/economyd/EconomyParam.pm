package economyd::EconomyParam;

#use strict;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw( $edAssigndPort $edCtlPort $edProviderPort
                  $edConfFile
                  $edPidFile
                  $confProvidersTag $confClusterTag 
                  $confExternalMarketTag $confSolverProgTag
                  $confStatusFileTag  $confLogFileTag
                  $confMarketTypeTag
                
                  $ctlMsgTag $ctlTypeTag $ctlResultTag  $ctlResultErrorTag 

                  $ctlTypeEconomydStatus $ctlTypeAssigndStatus $ctlTypeJobsStatus
                  $ctlTypeProvidersStatus $ctlTypeClustersStatus
                  $ctlTypeAddDebug  $ctlTypeRemoveDebug $ctlTypeListDebug $ctlTypeSetValue
                  $ctlResultHeaderSize 


                  EM_DEF_TMP_DIR 
                  EM_DEF_JOB_FILE 
                  EM_DEF_PROVIDER_FILE
                  EM_DEF_ASSIGNMENT_FILE
                  EM_DEF_PRICING_FILE 

                );

# The default port of the provider daemon
$edAssigndPort = "9004";
$edCtlPort     = "9006";
$edProviderPort= "9008";

# Economyd configuration file
$edConfFile            = "/etc/mosix/ecod.conf";
$edPidFile             = "/var/run/economyd.pid";

$confProvidersTag      = "providers";
$confClusterTag        = "cluster";

$confStatusFileTag     = "status-file";
$confLogFileTag        = "log-file";
$confMarketTypeTag     = "market-type";

####### Ctl part #######
$ctlMsgTag         = "ctl";
$ctlTypeTag        = "type";
$ctlResultTag      = "ctl-result";
$ctlResultErrorTag = "error";

# Ctl types
#
# <ctl type="status"></ctl>
#

$ctlTypeEconomydStatus    = "status";
$ctlTypeAssigndStatus     = "assignd-status";
$ctlTypeJobsStatus        = "jobs-status";
$ctlTypeProvidersStatus   = "providers-status";
$ctlTypeClustersStatus    = "clusters-status";
$ctlTypeAddDebug          = "add-debug";
$ctlTypeRemoveDebug       = "remove-debug";
$ctlTypeListDebug         = "list-debug";
$ctlTypeSetValue          = "set-value";


# When sending a ctl response the size of the response may be very large.
# Due to that we first send a short header containing the size of the data.
# The size of the header is described in the above variable
$ctlResultHeaderSize    = 40;


###### Market part ########


1;
