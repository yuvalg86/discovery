#  CentralMarket $Id: CentralMarket.pm,v 1.4 2007-11-22 06:26:22 lior Exp $ #  


#****c* economyd/CentralMarket
# FUNCTION
# 
# The CentralMarket inherit from the Market object and uses the solver
# program to run a central market. A pipe is opened to the solver program,
# and through this pipe the requests/answers are sent.
#
package economyd::CentralMarket;

use Errno;
use Data::Dumper; 
use FileHandle;
use IPC::Open2;

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::TimeFrame;
use economyd::EconomyParam;
use Util::JobManager;
use Util::AssignManager;
use Util::ProviderManager;
use providerd::ProviderParam;
use economyd::Market;
use strict;

use vars qw(@ISA);

@ISA = qw(economyd::Market);

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    
    my $self = $class->SUPER::new(@_);

    if(!$self) {
        debug_lr(MARKET_DBG, "Error creating CentralMarket object\n");
        return undef
    }
    
    if(!$self->initSolverProg()) {
        return undef;
    }

    $self->{providerMgr}->addListener(\&handleProviderEvent, $self);
    $self->{providerIdHash} = {};
    $self->{idProviderHash} = {};

    $self->{marketName} = "Central";
    $self->{solverName} = "Greedy-Migration";
    return $self;
}

sub getProviderFromId {
    my $self = shift;
    my $id = shift;

    return $self->{idProviderHash}->{$id}
      if(exists($self->{idProviderHash}->{$id}));
    return undef;
}

sub getIdFromProvider {
    my $self = shift;
    my $provider = shift;

    return $self->{providerIdHash}->{$provider}
      if(exists($self->{providerIdHash}->{$provider}));
    return undef;
}

sub initSolverProg {
    my $self = shift;
    
    my $pid;

    my ($readFH, $writeFH);
    eval { $pid = open2($readFH, $writeFH, "../solver/solver /dev/pts/21");};
    if($@) {
        debug_lr(MARKET_DBG, "Error using open2 to run the solver\n");
        sleep 1;
        use POSIX ":sys_wait_h";
        #my $kid = waitpid(-1, WNOHANG);
        #print STDERR "KKK: $kid\n";
        #exit(1);
        return 0;
    }
    $self->{solverPid} = $pid;
    $self->{readFH} = $readFH;
    $self->{writeFH} = $writeFH;
    
    print {$self->{writeFH}} "set-solver mig \n";
    $self->{startTime} = time();
    print {$self->{writeFH}} "time 0\n";
    #print {$self->{writeFH}} "info\n";
    
    return 1;
}

sub sendMsg {
    my $self = shift;
    my $msg = shift;
    print {$self->{writeFH}} $msg."\n";
}

sub printSolverDebugInfo {
    my $self = shift;
    
    return if(!$self->{debug});
    $self->sendMsg("info");
    $self->sendMsg("lp");
    $self->sendMsg("lj");
}

sub handleJobStatusEvent {
    my $self = shift;
    my $msgH = shift;

    return 1 if($msgH->{stat} eq JOB_WAIT_STAT);
    
    print curr_func_name() . " at central\n";

    my $jobId = $msgH->{jobId};
    my $res = $self->{assignMgr}->assignJob($jobId);
    
    if(!$res) {
        debug_lr(MARKET_DBG, "Error: assigning job $jobId\n");
        return 0;
    }
    return 1;
}

sub handleJobMarketStatusEvent {
    my $self = shift;
    my $msgH = shift;
    
    print curr_func_name() . " at central\n";
}


sub handleAddJobEvent {
    my $self = shift;
    my $msgH = shift;
    
    print curr_func_name() . " at central\n";
    my $id = $msgH->{jobId};
    my $jInfo = $self->{jobMgr}->getJobInfo($id);
    my ($v, $m, $c, $start, $run);
    $v = $jInfo->{'max-pay'};
    $m = $jInfo->{'mem'};
    $m = 1 if($m <= 0);
    $c = $jInfo->{'cpu-num'};
    $start = time - $self->{startTime};
    my $solverCmd = "aj $id $v $m $c $start 100";
    $self->sendMsg("time $start");
    $self->sendMsg($solverCmd);
    $self->printSolverDebugInfo();

}

sub handleRemoveJobEvent {
    my $self = shift;
    my $msgH = shift;

    print curr_func_name() . " at central\n";
    my $id = $msgH->{jobId};
    my $solverCmd = "dj $id";
    $self->sendMsg($solverCmd);
    my $start = time - $self->{startTime};
    $self->sendMsg("time $start");
    $self->printSolverDebugInfo();

    my $info = $self->{jobMgr}->getJobInfo($id);
    #print "Removed job $id\n", Dumper($info), "\n";
    $self->{providerMgr}->setProviderCurrPrice($info->{where}, 0);

}

sub handleRunningJobEvent {
    my $self = shift;
    my $msgH = shift;
    
    print curr_func_name() . " at central\n";
}

sub handleMigDoneEvent {
    my $self = shift;
    my $msgH = shift;
    
    print curr_func_name() . " at central\n";
    my $id = $msgH->{jobId};
    $self->sendMsg("jmd $id");
    $self->sendMsg("jfd $id");
    $self->printSolverDebugInfo();
    return 1;
}

#****m* economyd/Market->handleProviderMsg 
# FUNCTION
#   A provider sent us a message. The address of the sending provider is 
#   given as an argument. The Market can use the ProviderMgr to access the 
#   message.
# SYNOPSIS
#   $res = $self->handleProviderMsg($addr)
# ARGUMENTS
#   $addr  The address of the provider that sent the message.
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub handleProviderMsg {
    my $self = shift;
    my $addr = shift;

    debug_lr(MARKET_DBG, "Got message from provider $addr :not handling\n");
    # this function is not implemented at this object.
    return 0;
}

#****m* economyd/Market->handleProviderEvent
# FUNCTION
#   The providerMgr triggre events for us.
# SYNOPSIS
#   $res = $self->handleProviderEvent
# ARGUMENTS
# # RETURN VALUE
#  0     on error
#  1     on success 
#******
sub handleProviderEvent {
    my $self = shift;
    my $msgH = shift;

    print curr_func_name() . " at central\n";

    if($msgH->{type} eq "add-provider") {
        $self->handleAddProviderEvent($msgH);
    }
    elsif($msgH->{type} eq "del-provider") {
        $self->handleRemoveProviderEvent($msgH);
    }
    else {
        debug_lr(MARKET_DBG, "Provider event $msgH->{type} is not recognized\n");
        return 0;
    }
    return 1;
}

sub handleAddProviderEvent {
    my $self = shift;
    my $msgH = shift;

    print curr_func_name() . " at central\n";
    
    my $name = $msgH->{id};
    
    # First verifying that the provider does not already exists in our hashes
    if(exists($self->{providerIdHash}->{$name}) ) {
        debug_lr(MARKET_DBG, "Error, trying to add an already existing provider!!!\n");
        return 0;
    }

    # We guess an initial id by the number at the end of the node;
    my $id;
    if($name =~ /(\d+)$/ ) {
        $id = $1;
    } else {
        debug_lr(MARKET_DBG, "Error provider name does not contain a number at the end\n");
        return 0;
    }
       
    # In case the id we guessed is taken, we skeep 100 id's up until we find a free one
    while(exists($self->{idProviderHash}->{$id})) {
        debug_lr(MARKET_DBG, "ID $id of $name is already taken!!!\n");
        $id += 100; # skeeping 100 ids up.
    }

    # Creating a 2 way mapping so we can go from (id -> provider) and from 
    # (provider -> id)
    $self->{idProviderHash}->{$id} = $name;
    $self->{providerIdHash}->{$name} = $id;

    # Getting the provider information and 
    my $pInfo = $self->{providerMgr}->getProviderInfo($name);
    my ($r, $m, $c, $s);
    $r = $pInfo->{$minPriceTag};
    $m = int($pInfo->{'mem'});
    $c = $pInfo->{'cpu-num'};
    $s = 100; # FIXME add the real speed here

    # Sending the add provider command to the solver
    my $solverCmd = "ap $id $r $m $c $s";
    print "CMD $solverCmd \n";
    $self->sendMsg($solverCmd);
    my $currTime = time - $self->{startTime};
    $self->sendMsg("time $currTime");
    # $self->sendMsg("info");    

    return 1;
}

sub handleRemoveProviderEvent {
    my $self = shift;
    my $msgH = shift;



    my $name = $msgH->{id};
    my $id;
    if(exists($self->{providerIdHash}->{$name})) {
        $id = $self->{providerIdHash}->{$name};
    } else {
        debug_lr(MARKET_DBG, "Strange, request to delete provider $name without id\n");
        return 0;
    }

    print curr_func_name() . " at central $id\n";
    my $solverCmd = "dp $id";
    $self->sendMsg($solverCmd);
    my $start = time - $self->{startTime};
    $self->sendMsg("time $start");
    #$self->sendMsg("info");

    delete($self->{providerIdHash}->{$name});
    delete($self->{idProviderHash}->{$id});
    return 1;
}


#****m* economyd/Market->periodicRunMarket
# FUNCTION
#   The market is given the opportunity to run in a periodic fashion.
# SYNOPSIS
#   $res = $self->periodicRunMarket
# ARGUMENTS
# # RETURN VALUE
#  0     on error
#  1     on success 
#******
sub periodicRunMarket {
    my $self = shift;
    
    #print curr_func_name() . " at central\n";
    my $start = time - $self->{startTime};
    $self->sendMsg("go $start");
    
    
    return 1;
}

sub handleMarketMsg {
    my $self = shift;

    #print curr_func_name() . " at central\n";
    
    my $line;
    my @msg = ();
    my $r = $self->{readFH};
    while($line = <$r>) {
        chomp($line);
        last if($line eq "e");
        debug_lg(MARKET_DBG, "Received from solver: $line\n");
        push @msg, $line;
    }

    return if(!@msg);

    my $res = 1;
    foreach my $line (@msg) {
        my ($jobId, $providerId);

        # FIXME Need to fix this line when adding pricing into the solver (compensation)
        if($line =~ /^(\d+)\s+(\d+)$/) {
            $jobId = $1;
            $providerId = $2;
            
            if(!$self->doAllocation($jobId, $providerId)) {
                $res = 0;
            }
        }
        else {
            debug_lr(MARKET_DBG, "Error: message from solver not in format ($line)\n");
            $res = 0;
        }
    }
    $self->printSolverDebugInfo();
    return $res;

}

sub doAllocation {
    my $self = shift;
    my $jobId = shift;
    my $providerId = shift;

    my $status;
    my $where = "";
    if($providerId == 0) {
        $status = JOB_SUSPEND_STAT;

    } else {
        my $provider = $self->getProviderFromId($providerId);
        if(!$provider) {
            debug_lr(MARKET_DBG, "ERROR: got allocation for non existant provider\n");
            return 0;
        }

        $status = JOB_RUN_STAT;
        $where = $provider;
    }
    
    debug_ly(MARKET_DBG, "Allocating job: $jobId to provider: $where ($status)\n");
    $self->{jobMgr}->setJobStatus($jobId, $status, $where);

    # FIXME Currently we send the job-freeze-done right away since the assignd does not
    # FIXME support detecting freeze done.
    if($status eq JOB_SUSPEND_STAT) {
        $self->sendMsg("jfd $jobId");
        $self->{jobMgr}->setJobPayment($jobId, 0);
   }
    else {
        # FIXME Setting the price on the provider. This should move to after we get a 
        # FIXME mig-done, running, and freeze-done
        my $jobInfo = $self->{jobMgr}->getJobInfo($jobId);
        my $price = $jobInfo->{"max-pay"};
        $self->{providerMgr}->setProviderCurrPrice($where, $price);
        $self->{jobMgr}->setJobPayment($jobId, $price);
    }
    return 1;
}
#****m* economyd/Market->getMarketFH
# FUNCTION
#   The market is given the opportunity to give a file handled that willb e 
#   monitored by an upper layer.
# SYNOPSIS
#   $fh = $self->getMarketFH()
# ARGUMENTS
# RETURN VALUE
#  Returns the file handle of the market or 
#  undef if there is no file handle
#******
sub getMarketFH {
    my $self = shift;
    return $self->{readFH};
}

sub isMarketFH {
    my $self = shift;
    my $fh = shift;

    return 1 if($fh == $self->{readFH});
    return 0;
}

1;
