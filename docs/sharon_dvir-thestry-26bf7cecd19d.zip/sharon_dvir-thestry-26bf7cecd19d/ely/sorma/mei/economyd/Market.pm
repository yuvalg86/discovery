#  Market $Id: Market.pm,v 1.5 2007-10-23 11:38:20 elylevy Exp $ #  


#****c* economyd/Market
# FUNCTION
# 
# The Market is an interface object used by the EconomyD to run a Market.
# It provides the necessary inteface methods so different markets can be 
# called by the EconomyD.
# The actual market mechanism will be implemented by the inheriting objects

package economyd::Market;

use Errno;
use Data::Dumper; 

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::TimeFrame;
use economyd::EconomyParam;
use Util::JobManager;
use Util::AssignManager;
use Util::ProviderManager;
use providerd::ProviderParam;

use strict;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                debug => 0,
                %params,
               };
    
    if(!exists($self->{jobMgr}) || !exists($self->{assignMgr}) ||
       !exists($self->{providerMgr})) {
        debug_lr(MARKET_DBG, "Error must supply jobMgr and providerMgr objects\n");
        return undef
    }

    $self->{assignMgr}->addListener(\&handleAssigndEvent, $self);
    $self->{jobMgr}->addListener(\&handleJobEvent, $self);
    
    bless($self, $class);
    $self->{marketName} = "Not-real-market";
    $self->{solverName} = "N/A";
    return $self;
}

sub getMarketName {
    my $self = shift;

    return $self->{marketName};
}

sub getSolverName {
    my $self = shift;
    return $self->{solverName};
}

#****m* economyd/Market->handleJobEvent
# FUNCTION
#   When there is a job event (happening at the jobMgr) the Market object
#   check if the event is handled and if so call the appropriate handling 
#   method.
# SYNOPSIS
#   $res = $self->handleJobEvent($msgH)
# ARGUMENTS
#   $msgH  A reference to the message hash.
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub handleJobEvent {
    my $self = shift;
    my $msgH = shift;

    debug_lr(MARKET_DBG,"Job event ".Dumper($msgH));
    if($msgH->{type} eq "status") {
        $self->handleJobStatusEvent($msgH);
    } elsif ($msgH->{type} eq "market") {
        $self->handleJobMarketStatusEvent($msgH);
    }
    else {
        debug_lr(MARKET_DBG,"Job event $msgH->{type} is not handled\n");
        return 0;
    }
    return 1;
}

sub handleJobStatusEvent {
    my $self = shift;
    my $msgH = shift;
}
sub handleJobMarketStatusEvent {
    my $self = shift;
    my $msgH = shift;
}

#****m* economyd/Market->handleAssigndEvent
# FUNCTION
#   Handiling an event from the assignd.
#   If the event is handled the apropriate function is called
# SYNOPSIS
#   $res = $self->handleAssigndEvent($msgH)
# ARGUMENTS
#   $msgH  A reference to the message hash.
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub handleAssigndEvent {
    my $self = shift;
    my $msgH = shift;

    debug_lr(MARKET_DBG,"Assignd event ".Dumper($msgH));
    
    if($msgH->{type} eq "add-job") {
        $self->handleAddJobEvent($msgH);
    }
    elsif($msgH->{type} eq "remove-job") {
        $self->handleRemoveJobEvent($msgH);
    }
    elsif ($msgH->{type} eq "running") {
        $self->handleRunningJobEvent($msgH);
    }
    elsif($msgH->{type} eq "mig-done") {
        $self->handleMigDoneEvent($msgH);
    } 
    elsif($msgH->{type} eq "register") {
        $self->handleRegisterEvent($msgH);
    }
    else {
        debug_lr(MARKET_DBG,"Assignd event $msgH->{type} is not recognized\n");
        return 0;
    }
    return 1;
}

sub handleAddJobEvent {
    my $self = shift;
    my $msgH = shift;
}
sub handleRemoveJobEvent {
    my $self = shift;
    my $msgH = shift;
}
sub handleRunningJobEvent {
    my $self = shift;
    my $msgH = shift;
}
sub handleMigDoneEvent {
    my $self = shift;
    my $msgH = shift;
}
sub handleRegisterEvent {
    my $self = shift;
    my $msgH = shift;
}


#****m* economyd/Market->handleProviderMsg 
# FUNCTION
#   A provider sent us a message. The address of the sending provider is 
#   given as an argument. The Market can use the ProviderMgr to access the 
#   message.
# SYNOPSIS
#   $res = $self->handleProviderMsg($addr)
# ARGUMENTS
#   $addr  The address of the provider that sent the message.
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub handleProviderMsg {
    my $self = shift;
    my $addr = shift;

    debug_lr(MARKET_DBG, "Got message from provider $addr :not handling\n");
    # this function is not implemented at this object.
    return 0;
}

#****m* economyd/Market->periodicRunMarket
# FUNCTION
#   The market is given the opportunity to run in a periodic fashion.
# SYNOPSIS
#   $res = $self->periodicRunMarket
# ARGUMENTS
# # RETURN VALUE
#  0     on error
#  1     on success 
#******
sub periodicRunMarket {
    my $self = shift;
    return 1;
}


sub handleMarketMsg {
    my $self = shift;
    
    return 1;
}
#****m* economyd/Market->getMarketFH
# FUNCTION
#   The market is given the opportunity to give a file handled that will be 
#   monitored by an upper layer.
# SYNOPSIS
#   $fh = $self->getMarketFH()
# ARGUMENTS
# RETURN VALUE
#  Returns the file handle of the market or 
#  undef if there is no file handle
#******
sub getMarketFH {
    my $self = shift;
    return undef;
}

sub isMarketFH {
    my $self = shift;
    my $fh = shift;

    return 0;
}

1;
