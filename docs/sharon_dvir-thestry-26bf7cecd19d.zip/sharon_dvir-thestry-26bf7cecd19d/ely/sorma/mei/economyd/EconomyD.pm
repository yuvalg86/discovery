#  Providerd $Id: EconomyD.pm,v 1.19 2007-10-17 13:11:20 lior Exp $ #  


#****c* economyd/EconomyD
# FUNCTION
# 
# The economyd is responsible for getting requests from jobs/users, getting 
# offers from providers, and producing an assignment.

package economyd::EconomyD;


use Errno;
use Sys::Syslog;
use Data::Dumper; 
use Socket;
use Carp;
use Getopt::Long;
use File::Basename;
use IO::Socket::INET;
use IO::Select;
use XML::Simple;
use Sys::Hostname;

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::TimeFrame;
use economyd::EconomyParam;
use Util::JobManager;
use Util::AssignManager;
use Util::ProviderManager;
use Util::MarketProtocol;
use providerd::ProviderParam;
use economyd::DistMarket;
use economyd::CentralMarket;
use strict;
############# Functions declarations ##########################

sub run;
sub handle_msg;
sub initComm;
sub readConfFile;

########### Global variables ####################################

my $logFile;
my $globExit = 0;

#my $defaultInitialStatus = $providerOnTag;
#my $defaultMinPrice      = 0;

#****m* economyd/EconomyD->new
# FUNCTION
#   Constractor for the ProviderD object
# SYNOPSIS
#   $pvd = new ProviderD(prog_name   => "program name",
#                        info_file   => "info file for infod",
#                        debug       => "debug level",
#                       );
# ARGUMENTS
#   prog_name        The program name for syslog
#   info_file        The information file for infod.
#   debug            Debug level.
# RETURN VALUE
#  undef    On error
#  A reference to a ProviderD object on success
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };
    
    if ( !exists($self->{prog_name}) ) {
        return undef;
    }
    if (!exists($self->{confFile})) {
        $self->{confFile} = $edConfFile;
    }
    # If we get a status file we will create such file
    if (!exists($self->{statusFile})) {
        $self->{statusFile} = "";
    }
    # If we get a status file we will create such file
    if (!exists($self->{logFile})) {
        $self->{logFile} = "";
    }
    
    # Internal object members
    $self->{listen}       = 10;
    $self->{dbg_level}    = 0;
    $self->{msg_len}      = 1024;
    $self->{recv_timeout} = 3;
    $self->{assigndPort}  = $edAssigndPort;
    $self->{ctlPort}      = $edCtlPort;
    $self->{providerPort} = $edProviderPort;
    $self->{hostname}     = getHostname();
    $self->{cfg}          = {};
    $self->{period}       = 2;
    $self->{setupProviderPrice} = 0;

    # Handling the daemon log (not the log file of the machines)
    Sys::Syslog::setlogsock('unix');
    openlog($self->{prog_name},  'pid,cons', 'daemon');
    
    # Becoming an object
    bless($self, $class);
    
    if(!$self->readConfFile()) {
        my $err = $self->getError();
        print STDERR "Error reading configuration file: $err\n";
        return undef;
    }

    # Setting a default marketType
    $self->{marketType} = "dist" 
      if(!exists($self->{marketType}));

    # Calling internal initialization methods
    return undef if(!$self->initComm());
    return undef if(!$self->initManagers());
    return undef if(!$self->stopAutomaticLB());

    # Initializaing the log to empty one
    $self->{log} = {};
    $self->{errorMsg} = "";
    
    $self->{ecoStats}->{socialWelfare} = 0;
    $self->{ecoStats}->{consumersSurplus} = 0;
    $self->{ecoStats}->{providersSurplus} = 0;
    
    return $self;
}

sub getError {
    my $self = shift;
    return $self->{errorMsg};
}

#****m* economyd/EconomyD->readConfFile
# FUNCTION
#   Reading the EconomyD configuration file
# SYNOPSIS
#   $res = $self->readConfFile()
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub readConfFile {
    my $self = shift;
    
    
    if(! -f $self->{confFile} ) {
        $self->{errorMsg} = "No file $self->{confFile}";
        return 0;
    }
    my $xml = new XML::Simple(RootName=>"conf");
    my $confH = eval {XMLin($self->{confFile}, 
                            ForceArray => ["cluster", "rep"],  
                            KeyAttr => {"cluster" => "name"});};
    if($@) {
        $self->{errorMsg} = $@;
        return 0;
    }
    return 0 if(! $confH);
    debug_ly(ED_DBG, "Config hash:\n", Dumper($confH));
    
    # Reading the status file from the configuration if it was not given in cmdline
    if(!$self->{statusFile}  && exists($confH->{$confStatusFileTag})) {
        $self->{statusFile} = $confH->{$confStatusFileTag};
    }

    # Reading the log file from the configuration if it was not given in cmdline
    if(!$self->{logFile}  && exists($confH->{$confLogFileTag})) {
        $self->{logFile} = $confH->{$confLogFileTag};
    }
    
    # Market Type (dist or central)
    if(!exists($self->{marketType})  && exists($confH->{$confMarketTypeTag})) {
        $self->{marketType} = $confH->{$confMarketTypeTag};
    }
    
    
    # Reading the providers part
    if(!exists($confH->{$confProvidersTag}->{$confClusterTag})) {
        $self->{errorMsg}  = "Error no $confProvidersTag and $confClusterTag sections\n";
        $self->{errorMsg} .= "in configuration file\n";
        return 0;
    }
    my $clustersNum = scalar keys(%{$confH->{$confProvidersTag}->{$confClusterTag}});
    if($clustersNum == 0) {
        $self->{errorMsg}  = "There must be at least one cluster defined in configuration file\n";
        return 0;
    }
    
    $self->{confH} = $confH;
    return 1;
}

#****m* economyd/EconomyD->initComm
# FUNCTION
#   Initialize communication sockets.
# SYNOPSIS
#   $pvd = $self->initComm()
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub initComm {
    my $self = shift;
    
    # Creating the assignd tcp socket
    my $i = 0;
    while(1) {
        $self->{tcpSock} =
          new IO::Socket::INET->new(Proto     => 'tcp',
                                    Type      => SOCK_STREAM ,
                                    LocalPort => $self->{assigndPort},
                                    Listen    => $self->{listen},
                                    Reuse     => 1,
                                   );
        if(!$self->{tcpSock}) {
            if(exists($!{EADDRINUSE})) {
                if($i< 61) {
                    print STDERR "." ; sleep 1;
                    next;
                }
            }
            print STDERR "Can't create tcp socket: $!\n";
            return 0;
        } 
        else { last; }
    }
 #   print $self->{tcpSock}->sockaddr()."\n";

    # Creating the ctl tcp socket
    $i = 0;
    while(1) {
        $self->{ctlTcpSock} =
          new IO::Socket::INET->new(Proto     => 'tcp',
                                    Type      => SOCK_STREAM ,
                                    LocalPort => $self->{ctlPort},
                                    Listen    => $self->{listen});
        
        if(!$self->{ctlTcpSock}) {
            if(exists($!{EADDRINUSE})) {
                if($i< 61) {
                    print STDERR "."; sleep 1;
                    next;
                }
            }
            print STDERR "Can't create ctl tcp socket: $!\n";
            return 0;
        }
        else { last; }
    }
    # Creating the basic select object
    $self->{selectRead} =  new IO::Select();
    $self->{selectWrite} = new IO::Select();
    $self->{selectException} = new IO::Select();

    if (!$self->{selectRead} || !$self->{selectWrite} || !$self->{selectException}) 
      {
          print STDERR "Can't initialize select objects \n";
          return 0;
      }
    return 1;
}


#****m* economyd/EconomyD->initManagers
# FUNCTION
#   Initialize managers (job,provider).
# SYNOPSIS
#   $pvd = $self->initManagers()
# RETURN VALUE
#  0     on error
#  1     on success 
#******
sub initManagers {
    my $self = shift;

    # Job/Assignd manager
    if(!($self->{jobMgr} = new Util::JobManager())) {
        debug_lr(ED_DBG, "Error initializing job manager\n");
        return 0;
    }
    if($self->{logFile}) {
        my $f;
        if(!open($f, ">$self->{logFile}")) {
            debug_lr(ED_DBG, "Error opening log file $self->{logFile}: $!\n");
            return 0;
        }
        $f->autoflush(1);
        $self->{jobMgr}->setLogFileHandle($f);
        $self->{logFileHndl} = $f;
    }
    # Assign Manager
    if(!($self->{assignMgr} = new Util::AssignManager("jobMgr" => $self->{jobMgr}))) 
      {
          debug_lr(ED_DBG, "Error initializing assign manager\n");
          return 0;
      }

 
    # Provider manager
    if(!($self->{providerMgr} = new Util::ProviderManager())) {
          debug_lr(ED_DBG, "Error initializing provider manager\n");
          return 0;
      }
    my $clusterH = $self->{confH}->{$confProvidersTag}->{$confClusterTag};
    foreach my $c (keys(%$clusterH)) {
        $self->{providerMgr}->addClusterInfoRep($c, $clusterH->{$c})
    }

    # Market Managers
    my $h = hostname;
    debug_lg(ED_DBG, "My hostname $h\n");

    # The distributed market where bidding is performed
    if($self->{marketType} eq "dist") {
        print "Working in distributed mode\n";
        if(!($self->{market} = 
             new economyd::DistMarket("jobMgr"      => $self->{jobMgr},
                                      "assignMgr"   => $self->{assignMgr},
                                      "providerMgr" => $self->{providerMgr},
                                      "myHostName"  => $h)))
          {
              debug_lr(ED_DBG, "Error initializing distributed market object\n");
              return 0;
          }
    }
    # A central makret mechanism (uses the solver)
    elsif( $self->{marketType} eq "central") {
        print "Working in central mode\n";
        $self->{market} = new economyd::CentralMarket("jobMgr"      => $self->{jobMgr},
                                                      "assignMgr"   => $self->{assignMgr},
                                                      "providerMgr" => $self->{providerMgr});
        if(!$self->{market}) {
            debug_lr(ED_DBG, "Error initializing central market object\n");
            return 0;
        }
    }
    else {
        debug_lr(ED_DBG, "Error no such market type $self->{marketType}\n");
        return 0;
    }
    
    return 1;
}

sub stopAutomaticLB {
    my $self = shift;

    `mosctl stay`;
    return 1;
}



sub sig_int_hndl {
    my $sig = shift;
    
    print STDERR "Terminating with signal: $sig\n";
    syslog("alert", "Got signal $sig, going down\n");
    $globExit = 1;
}



sub setSignalHandlers {
    my $self = shift;
    
    $SIG{INT} =  \&sig_int_hndl;
    $SIG{TERM} = \&sig_int_hndl;
}

sub doExit {
    my $self = shift;
    
    $self->{tcpSock}->close();
    $self->{assignMgr}->free();
    #$self->{marketMgr}->free();
}

sub runMarket {
    my $self = shift;
    debug_lb(ED2_DBG, "Running Market\n");
    
    # Checking if there are provider and jobs
    if($self->{jobMgr}->getReadyJobNum() == 0) {
        debug_lr(ED2_DBG, "There are 0 jobs, not running market\n");
        $self->{providerMgr}->clearCurrPrice()
          if($self->{setupProviderPrice});
        return 0;
    }
    if($self->{providerMgr}->getProviderNum() == 0) {
        debug_lr(ED2_DBG, "There are 0 providers, not running market\n");
        return 0;
    }
    
    $self->{market}->periodicRunMarket();
    #    my $matchList = $self->{market}->rchoose();
    #    $self->{distMarket}->doBids($matchList);
    # Get the new matchings and handle them
    return 1;
}

sub doAssignment {
    my $self = shift;
    
    # Parsing the xml
    debug_lb(ED_DBG, "Doing Assignment\n");
    my $assignmentXml = $self->{marketMgr}->getAssignmentXml();
    my $pricingXml = $self->{marketMgr}->getPricingXml();
    
    $self->{allocMgr}->setAssignmentXml($assignmentXml);
    $self->{allocMgr}->setPricingXml($pricingXml);
    $self->{allocMgr}->doAllocation();
    
    $self->calcSocialWelfare();
    return 1;
}

sub performPeriodicAction {
    my $self = shift;
    
    my $curr_time = time();
    my $sec_passed = $curr_time - $self->{periodStart};
    
    my $sec_left = $self->{periodLeft} - $sec_passed;
    debug_ly(ED2_DBG, "Period Management $sec_left $sec_passed\n");
    my $doPeriodic = 0;
    if($sec_left <= 0) { 
        #debug_ly(ED_DBG, "Period $self->{period} passed ($curr_time)\n");
        $self->{periodLeft}  = $self->{period};
        $doPeriodic = 1;
    } else {
        $self->{periodLeft}  = $sec_left;
    }
    $self->{periodStart} = $curr_time;

    return if(!$doPeriodic);
    
    $self->{jobMgr}->updateTotalPay();
    #my @nbj = $self->{jobMgr}->updateTotalPay();
    #foreach my $j (@nbj) {
    #    $self->{assignMgr}->assignJob($j);
    #}
    
    #$self->calcSocialWelfare();
    $self->{providerMgr}->probe();
    $self->runMarket();
    $self->updateStatusFile() 
      if($self->{statusFile});
}

sub calc_consumersSurplus {
    my $jh = shift;
    my $data = shift;

    if($jh->{$allJobFields->{status}} eq JOB_RUN_STAT) {
        my $maxPrice = $jh->{$allJobFields->{'max-pay'}};
        my $currPrice = $jh->{$allJobFields->{'curr-pay'}};
        $$data += $maxPrice - $currPrice;
    }
}

sub calc_providersSurplus {
    my $ph = shift;
    my $data = shift;

    if($ph->{$currPriceTag} > 0) {
        my $minPrice = $ph->{$minPriceTag};
        my $currPrice = $ph->{$currPriceTag};
        $$data += $currPrice - $minPrice;;
    }
}

sub calcSocialWelfare {
    my $self = shift;
    
    # Consumer (jobs) surplus = max-pay - curr-pay
    my $consumersSurplus = 0;
    $self->{jobMgr}->foreachJob(\&calc_consumersSurplus, \$consumersSurplus);
    $self->{ecoStats}->{consumersSurplus} = $consumersSurplus;
    
    # Providers surplus = curr-pay - min-price
    my $providersSurplus = 0;
    $self->{providerMgr}->foreachProvider(\&calc_providersSurplus, \$providersSurplus);
    $self->{ecoStats}->{providersSurplus} = $providersSurplus;
    
    # Social welfare is the sub of consumersSurplus + providersSurplus
    $self->{ecoStats}->{socialWelfare} = $consumersSurplus + $providersSurplus;
}

sub updateStatusFile {
    my $self = shift;

    my $economydXml = $self->getStatusXml();
    my $assignXml = $self->{assignMgr}->getAssignXml();
    my $jobsXml = $self->{jobMgr}->getJobsXml();
    my $providersXml = $self->{providerMgr}->getProvidersXml();
    my $clusterXml = $self->{providerMgr}->getClustersXml();
    
    if(!open(ST, ">$self->{statusFile}.tmp")) {
        debug_lr(ED_DBG, "Error opening status file: $self->{statusFile}.tmp\n");
    }
    print ST "<MEIStatus>\n";
    print ST $economydXml;
    print ST $assignXml;
    print ST $jobsXml;
    print ST $providersXml;
    print ST $clusterXml;
    print ST "</MEIStatus>\n";
    close ST;
    rename $self->{statusFile}.".tmp", $self->{statusFile};
}

sub getStatusXml {
    my $self = shift;
    return $self->getStatusStr(1);
}

sub getStatusStr {
    my $self = shift;
    my $xmlFormat = 0;
    $xmlFormat = shift
      if(@_);
    
    my $totalJobs = $self->{jobMgr}->getTotalJobNum();
    my $waitingJobs = $self->{jobMgr}->getJobsAtState(JOB_WAIT_STAT);
    my $runningJobs = $self->{jobMgr}->getJobsAtState(JOB_RUN_STAT);
#    my $noBudgetJobs = $self->{jobMgr}->getJobsAtState(JOB_NO_BUDGET_STAT);
    my $suspendedJobs = $self->{jobMgr}->getJobsAtState(JOB_SUSPEND_STAT);
    my $finishedJobs = $self->{jobMgr}->getJobsAtState(JOB_FINISH_STAT);
    my $assigndNum = $self->{assignMgr}->getAssignNum();
    my $providersNum = $self->{providerMgr}->getProviderNum();
    my $clustersNum = $self->{providerMgr}->getClusterNum();
#    my $marketStatus = $self->{marketMgr}->getMarketStatus();
#    my $marketCumputeTime = $self->{marketMgr}->getComputeTime();
    my $marketName = $self->{market}->getMarketName();
    my $solverName = $self->{market}->getSolverName();
    my $hostname = $self->{hostname};
    
    my $curr_time = time();
    my $sec_passed = $curr_time - $self->{periodStart};
    my $secUntilNextMarketRun = $self->{periodLeft} - $sec_passed;
    
    my $str;
    if($xmlFormat) {
        $str .= "<economydStatus>\n";
        $str .= "\t<lastUpdated>". time() ."</lastUpdated>\n";
        $str .= "\t<assignPort>$self->{assigndPort}</assignPort>\n";
        $str .= "\t<ctlPort>$self->{ctlPort}</ctlPort>\n";
        $str .= "\t<assigndNum>$assigndNum</assigndNum>\n";
        $str .= "\t<economydHost>$hostname</economydHost>\n";
        $str .= "\t<jobs>\n";
        $str .= "\t\t<total>$totalJobs</total>\n";
        $str .= "\t\t<wait>$waitingJobs</wait>\n";
        $str .= "\t\t<run>$runningJobs</run>\n";
 #       $str .= "\t\t<nobudget>$noBudgetJobs</nobudget>\n";
        $str .= "\t\t<suspend>$suspendedJobs</suspend>\n";
        $str .= "\t\t<finish>$finishedJobs</finish>\n";
        $str .= "\t</jobs>\n";
        $str .= "\t<providersNum>$providersNum</providersNum>\n";
        $str .= "\t<clustersNum>$clustersNum</clustersNum>\n";
        $str .= "\t<economyStatus>\n";
#        $str .= "\t\t<computeTime>$marketCumputeTime</computeTime>\n";
#        $str .= "\t\t<marketStatus>$marketStatus</marketStatus>\n";
        $str .= "\t\t<marketName>$marketName</marketName>\n";
        $str .= "\t\t<solverName>$solverName</solverName>\n";
        $str .= "\t\t<consumersSurplus>$self->{ecoStats}->{consumersSurplus}</consumersSurplus>\n";
        $str .= "\t\t<providersSurplus>$self->{ecoStats}->{providersSurplus}</providersSurplus>\n";
        $str .= "\t\t<socialWelfare>$self->{ecoStats}->{socialWelfare}</socialWelfare>\n";
        $str .= "\t</economyStatus>\n";
        $str .= "</economydStatus>\n";
    } else {
        $str = sprintf(
                       "Hostname:          %s\n".
                       "Assignd Port:      %d\n".
                       "Ctl Port:          %d\n".
                       "Assingd's          %d\n". 
                       "Jobs:              Total:%d \n".
                       "                   Wait: %d Run:%d Suspend:%d".
                       "                   Finish: %d\n".
                       "Providers:         %d (in %d clusters)\n".
                       "Time to next run:  %d\n".
                       "Consumers Surplus: %.3f\n".
                       "Providers Surplus: %.3f\n".
                       "Social Welfare:    %.3f\n",
                       
                       $hostname,
                       $self->{assigndPort},
                       $self->{ctlPort},
                       $assigndNum, 
                       $totalJobs, $waitingJobs, $runningJobs, $suspendedJobs, 
                       $finishedJobs,
                       $providersNum, $clustersNum,
                       $secUntilNextMarketRun,
                       $self->{ecoStats}->{consumersSurplus},
                       $self->{ecoStats}->{providersSurplus},
                       $self->{ecoStats}->{socialWelfare},
                      );
    }
    return $str;
}

#****m* economyd/EconomyD->performCtlAction
# FUNCTION
#   Takgin the message recieved on the ctl port parsing it and performing the
#   requested ctl action
# SYNOPSIS
#   $res = $sd->performCtlAction($msg);
# ARGUMENTS
#   $msg    The ctl message (should be an xml string)
# RETURN VALUE
#   $res  The xml result that should be sent to the client
#******
sub performCtlAction {
    my $self = shift;
    my $msgH = shift;
    
    my $resXml; ;
    debug_lg(SD_CTL_DBG, "Ctl message type: $msgH->{$marketTypeTag}\n");
    if($msgH->{$marketTypeTag} eq $ctlTypeEconomydStatus) {
        $resXml = $self->getStatusStr();
    }
    elsif($msgH->{$marketTypeTag} eq $ctlTypeAssigndStatus) {
        $resXml = $self->{assignMgr}->getAssignXml();
    }
    elsif($msgH->{$marketTypeTag} eq $ctlTypeJobsStatus) {
        $resXml = $self->{jobMgr}->getJobsXml();
    }
    elsif($msgH->{$marketTypeTag} eq $ctlTypeProvidersStatus) {
        $resXml = $self->{providerMgr}->getProvidersXml();
    }
    elsif($msgH->{$marketTypeTag} eq $ctlTypeClustersStatus) {
        $resXml = $self->{providerMgr}->getClustersXml();
    }
    elsif($msgH->{$marketTypeTag} eq $ctlTypeAddDebug) {
        foreach my $l (@{$msgH->{levels}}) {
            addDebugLevel($l);
        }
        $resXml = "ok";
    }
    elsif($msgH->{$marketTypeTag} eq $ctlTypeRemoveDebug) {
        foreach my $l (@{$msgH->{levels}}) {
            removeDebugLevel($l);
        }
        $resXml = "ok";
    }
    elsif($msgH->{$marketTypeTag} eq $ctlTypeListDebug ) {
        my @levels = getDebugLevels();
        foreach my $l (@levels) {
            $resXml .= "\t<levels>$l</levels>\n";
        }
    } 
    elsif($msgH->{$marketTypeTag} eq $ctlTypeSetValue) {
        if($self->{jobMgr}->setJobMaxPayment($msgH->{jobID}, $msgH->{value})) {
            $resXml = "ok";  
        } else {
            $resXml = "error";
        }
    }
    else {
        $resXml = "error no such ctl message: ( $msgH->{$marketTypeTag} )";
    }
    return $resXml;
}
#****m* economyd/EconomyD->handleCtlMsg
# FUNCTION
#   The EconomyD just got a ctl message. The handling of such messages
#   is fast so we perform the action, send the result, and close the 
#   connection
# SYNOPSIS
#   $res = $sd->handleCtlMsg()
# ARGUMENTS
# RETURN VALUE
#  0     On error
#  1     On sucess
#******
sub handleCtlMsg {
    my $self = shift;
    
    my $newconn = $self->{ctlTcpSock}->accept();
    if(!$newconn) {
        debug_lr(ED_DBG, "Error accepting ctl connection\n");
        return 0;
    }
    
    my $sockaddr       = $newconn->peername();
    my ($port, $iaddr) = sockaddr_in($sockaddr);
    my $rhostname       = gethostbyaddr($iaddr, AF_INET); 
    debug_lg(SD_CTL_DBG, "Got connection on ctl port : $rhostname\n");
    
    my $msg = recvMarketMsg($newconn, $self->{recv_timeout});
    if(!$msg) {
        debug_lr(SD_CTL_DBG, "Error receiving message from ctl client\n");
        $newconn->close();
        return 0;
    }
    
    # The result xml start 
    # my $xmlRes = "<$ctlResultTag>\n";
    
    # Parsing the xml
    my $resXmlStr;
    my $xml = new XML::Simple();
    my $msgH =  eval { $xml->XMLin($msg, ForceArray => ["levels"]); };
    debug_ly(SD_CTL_DBG, Dumper($msgH));
    if($@) {
        debug_lr(SD_CTL_DBG, "Error failed to translate ctl message to xml hash\n");
#        $resXmlStr = "<$ctlResultErrorTag>bad xml</$ctlResultErrorTag>";
    }
    else {
        # Keeping the socket so we can return an answer
        $resXmlStr = $self->performCtlAction($msgH);
        $resXmlStr .= "<$marketClassTag>economydCtlClass</$marketClassTag>";
        $resXmlStr .= "<$marketTypeTag>$msgH->{$marketTypeTag}</$marketTypeTag>";
    }

    sendMarketMsg($newconn, $resXmlStr);
    $newconn->close();
    return 1;
}

sub prepareFileHandles {
    my $self = shift;
    
    $self->{selectRead} = undef;
    $self->{selectWrite} = undef;
    $self->{selectException} = undef;

    $self->{selectRead} =  new IO::Select();
    $self->{selectWrite} = new IO::Select();
    $self->{selectException} = new IO::Select();
    
    # Removing the file handles
    #$self->{selectRead}->remove($self->{selectRead}->handles());
    #$self->{selectWrite}->remove($self->{selectWrite}->handles());
    #$self->{selectException}->remove($self->{selectException}->handles());
    
    # Adding the file handles
    my @assignSocks = $self->{assignMgr}->getAssignSock();
    $self->{selectRead}->add($self->{tcpSock}, $self->{ctlTcpSock}, @assignSocks);
    $self->{selectException}->add(@assignSocks)
      if(@assignSocks);
    
    # Adding providers sockets if any
    my @providerSocks = $self->{providerMgr}->getProviderSock();
    if(@providerSocks) {
        $self->{selectRead}->add(@providerSocks);
        $self->{selectException}->add(@providerSocks);
    }
    
    # Adding the market fh
    my $marketFh = $self->{market}->getMarketFH();
    if($marketFh) {
        $self->{selectRead}->add($marketFh);
        $self->{selectException}->add($marketFh);
    }
    #my $num = @assignSocks;
    #debug_lg(ED_DBG, "Got $num @assignSocks\n");
    #my @h = $self->{selectRead}->handles();
    #debug_ly(ED_DBG, "readset @h\n");
    #@h = $self->{selectRead}->handles();
    #debug_ly(ED_DBG, "readset2 @h\n");

    
}
#****m* providerd/ProviderD->run
# FUNCTION
#   Daemon main loop. Function return only if an exit was requested
#   by receiving a signal or by an error
# SYNOPSIS
#   $self->run();
#******
sub run {
    my $self = shift;
    my $paddr;
    my @map;
    my $debug_level=0;
    my $recv = '';
    my ($command, $arguments);
    my $new_socket;

    $self->setSignalHandlers();
  
    debug_ly(ED_DBG, "server started on port $self->{assigndPort} and $self->{ctlPort}\n");
    syslog("info", "server started on port $self->{assigndPort} and $self->{ctlPort}");
    
    $self->{periodStart} = time();
    $self->{periodLeft} = $self->{period};

    $self->{providerMgr}->probe();
    $self->updateStatusFile();
    #exit(1);
    while(1) {
    
	# Wating for a connection both tcp or udp
	debug_level(PVD2_DBG, "Wait on select\n");

        $self->prepareFileHandles();
        # Preparing the select object
        #debug_lb(ED_DBG, "In select, timeout $self->{periodLeft}\n");
        my @activeFH = IO::Select->select($self->{selectRead}, undef, undef, $self->{periodLeft});
	
        if($globExit) {
            return $self->doExit();
        }
        #if(!@activeFH) {
        #    debug_lr(ED_DBG, "Error in select\n");
        #    exit 1;
        #    next;
        #}
        
        if(@activeFH) {
            #print Dumper(\@activeFH); 
            # Checking the exceptions first
            if(@{$activeFH[2]}) {
                debug_lr(ED_DBG, "Error on one of the file handles\n");
                foreach my $eFh (@{$activeFH[2]}) {
                    if((my $assigndAddr = $self->{assignMgr}->isAssignSock($eFh))) {
                        debug_lr(ED_DBG, "Error from $assigndAddr\n");
                        $self->{assignMgr}->deleteAssignConnection($assigndAddr);
                        next;
                    }
                }
                return 0;
            }
            # Checking the read file handles
            elsif( @{$activeFH[0]})  {
                foreach my $fh (@{$activeFH[0]}) {
                # A new assignd connection
                    if($fh == $self->{tcpSock}) {
                        $self->{assignMgr}->addAssignConnection($self->{tcpSock});
                        next;
                    }
                    # One of the assignd send us message
                    if((my $addr = $self->{assignMgr}->isAssignSock($fh))) {
                        $self->{assignMgr}->handleAssignMsg($addr, $self->{selectRead});
                        next;
                    }
                    # One of the providers sent us a message 
                    if((my $provider = $self->{providerMgr}->isProviderSock($fh))) {
                        $self->{market}->handleProviderMsg($provider);
                        next;
                    }
                    if($self->{market}->isMarketFH($fh)) {
                        $self->{market}->handleMarketMsg();
                        next;
                    }
                    
                    # A ctl request
                    if($fh == $self->{ctlTcpSock}) {
                        $self->handleCtlMsg();
                        next;
                    }
                    debug_lr(ED_DBG, "Error, no object is claiming the socket\n");
                    next;
                }
            }
        }
	# We finished taking care of the messages and now we check if enough 
	# time has passed and we need to save the log to the file
	$self->performPeriodicAction();
    }
}


1;
