package Util::Misc;  # assumes Some/Module.pm

use strict;
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw( machines_sort_func );

my $dbg = 0;

###########################################################################
#----------------------- Functions def ------------------------------------
###########################################################################


#****m* Clip/Util/Misc/machines_sort_func
# FUNCTION
#   A sort function for sorting machine by name. Where machines represented
#   by ip are to be presented first than machine with name
#
#  ARGUMENTS 
#  Util::Misc::machines_sort_func($a , $b) 
#     $a, $b Are the usual sort arguments
#  RETURN
#  1 if a < b 0 if equal an -1 if a > b
#******
sub machines_sort_func {
    my $a = $_[0];
    my $b = $_[1];
    
    #print "Sorting $a $b\n";
    return 1 if(! defined($a));
    return -1 if(! defined($b));
    
    my $ip4_addr_regex = '((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])[.]){4}';
    
    if ("${a}.${b}." =~ /^(${ip4_addr_regex})(${ip4_addr_regex})$/) {
	# Both arguments are numerical IP addresses:
	my @temp = split /[.]/, "${a}.${b}";
	foreach (@temp) { $_ = substr(("00" . $_), -3) }
	return (join(".", $temp[0], $temp[1], $temp[2], $temp[3]) lt
		join(".", $temp[4], $temp[5], $temp[6], $temp[7]) ? -1 : 1);
	
    } elsif ("${a}." =~ /^${ip4_addr_regex}$/) {
	# Only 1st argument is a numerical IP address.
	# In our sorting a numerical IP addres precedes any hostname:
	return 1;
	
    } elsif ("${b}." =~ /^${ip4_addr_regex}$/) {
	# Only 2nd argument is a numerical IP address.
	# In our sorting a numerical IP addres precedes any hostname:
	return -1;
	
    } else {
		# Neither argument is a numerical IP address.
		# Lexicographical comparison is our friend:
        my ($wordA,$wordB,$numA,$numB);
        
        if ($a =~ /^(.*\D)(\d+)$/) {
            $wordA = $1;
            $numA = $2;
        }
        else {
            $wordA = $a;
            $numA = 0;
        }
        
        if ($b =~ /^(.*\D)(\d+)$/) {
            $wordB = $1;
            $numB = $2;
        }
        else {
            $wordB = $b;
            $numB = 0;
        }
 
        #print "Word part: $wordA $wordB Num part: $numA $numB\n";
	return (($wordA cmp $wordB) || ($numB <=> $numA));
    }
}


1;



