# util functions for clip.
package Util::Net;  # assumes Some/Module.pm
use Util::Debug;
use Socket;
use IO::Socket::INET;
use IO::Select;
use Sys::Hostname;


use strict;
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw( 
                 secure_recv
                 secure_msg_recv
                 recvAllData
                 recvData
                 getHostname
                 getSockPeerInfo
                 );




#****f* Util/Net/secure_recv
# FUNCTION
#   read from the given socket until $timeout or $len is recive.
# SYNOPSIS
#   $read_str = secure_recv( $socket, $len , $timeout )
# ARGUMENTS
#   socket  -- the socket to read from
#   len     -- the lenght to read
#   timeout -- the maximum time to read from the socket
# RETURN VALUE
#   the string that read from the socket
#******
sub secure_recv {
    my $socket = shift;
    my $len = shift;
    my $timeout = shift;
    my $data=undef;
    #undef($recv);
    debug_lr(NET_DBG, "message length $len\n");

    eval {
        local $SIG{ALRM} = sub {
            debug_lr(NET_DBG, "got timeout in recv syscall! ");
            die "alarm\n";
        };
        alarm $timeout;
    #     if ($socket->connected()) {
#             debug_lr(NET_DBG, "socket is connected!");
#         } else {
#             debug_lr(NET_DBG, "error, recv on closed socket!!!");
#             die "closed socket\n";
#         }
#        debug_lr(NET_DBG, "Source port: ".($socket->peerport()));
        $socket->recv($data,$len);

        alarm 0;
    };

    if ($@ or !defined($data) or !$data) {
        debug_lr(NET_DBG, "secure_recv: return undef! (recv)\n");
        debug_lr(NET_DBG, "$@") if $@;
        return undef;
    }

    debug_lr(NET_DBG, "message data:\n$data\n");
    return $data;
}

#****f* Util/Net/recvAllData
# FUNCTION
#   Try to read as much data from the socket as possible. It can perform
#   several reads if more data than the buffer size is ready.
# SYNOPSIS
#   $read_str = recvAllData( $socket, $len , $timeout )
# ARGUMENTS
#   socket  -- the socket to read from
#   len     -- the lenght to read
#   timeout -- the maximum time to read from the socket
# RETURN VALUE
#   the string that read from the socket
#******
sub recvAllData {
    my $socket = shift;
    my $len = shift;
    my $timeout = shift;
   
    my $msg;
    my $res;
    
    # The first receive
    $res = secure_recv($socket, $len, $timeout);
    return $res if(!$res);

    my $resLen = length($res);
    # received all the data;
    return $res if($resLen < $len);
    
    $socket->blocking(0);
    while(1) {
        debug_ly(NET_DBG, "Doing second receive data too big\n");
        my $extraData =  secure_recv($socket, $len, $timeout);
        last if(!$extraData);
        my $extraDataLen = length($extraData);
        $res .= $extraData;
        last if($extraDataLen < $len);
    }

    $socket->blocking(1);
    return $res;
}

sub recvData {
    my $socket = shift;
    my $totalLen = shift;
    my $timeout = shift;

    my $msg;
    my $res;
    my $i = 0;
    my $len = 0;
    debug_lb(NET_DBG, "recvData: about to reveive $totalLen\n");
    my $fail = 0;
    $socket->blocking(1);
   
    
    
    while(1) {
        debug_ly(NET_DBG, "Doing receive ($i) Len $len ($totalLen)\n");
        #$socket->recv($recv,$len);
        my $data =  secure_recv($socket, 16000, $timeout);
        if(!$data) {
            $fail++;
            last if ($fail > 5);
            sleep(1);
            next;
        }
        my $dataLen = length($data);
        $len += $dataLen;
        $res .= $data;
        last if($len >= $totalLen);
        $i++;
    }
    
    if($len < $totalLen) {
        return undef;
    }
    return $res;
    
}


#****f* Util/Net/getSockPeerInfo
# FUNCTION
#   Extract the peer information (name , address)
# SYNOPSIS
#    = secure_recv( $socket, $len , $timeout )
# ARGUMENTS
#   socket  -- the socket to read from
#   len     -- the lenght to read
#   timeout -- the maximum time to read from the socket
# RETURN VALUE
#   the string that read from the socket
#******
sub getSockPeerInfo {
    my $sock = shift;

    my $sockaddr        = $sock->peername();
    my ($port, $iaddr)  = sockaddr_in($sockaddr);
    my $rhostname       = gethostbyaddr($iaddr, AF_INET); 
    my $rhostaddr       = inet_ntoa($iaddr);

    return ($rhostname, $rhostaddr)
}

#****f* Util/Net/getHostname
# FUNCTION
#   Returns the hostname of the computer
# SYNOPSIS
#    = getHostname()
# RETURN VALUE
#   The host's string name
#******
sub getHostname {
  return hostname();
}
1;
