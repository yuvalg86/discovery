package Util::SimpleConfFile;

use strict;
use Data::Dumper;
use Util::Debug;


sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };

    if ( !exists($self->{confFile}) ) {
        debug_ly(CF_DBG, "Warning: no conf file was given to SimplConfFile object\n");
        return undef;
    }
    
    bless($self, $class);
    
    return undef if(!$self->loadConfFile());
    debug_ly(CF_DBG, Dumper($self->{conf}, "conf"));
    return $self;
}


sub loadConfFile {
    my $self = shift;

    if(! open F, "$self->{confFile}") {
        debug_lr(CF_DBG, "Error opening $self->{confFile}: $!\n");
        return 0;
    }
    
    while(my $line = <F>) {
        next if($line =~ /^#/);
        next if($line =~ /^\s*$/);
        
        if($line =~ /\s*([\w\.\\\/]+)\s*=\s*([\w\.\\\/\-\,\:\(\)\}\{]+)/) {
            debug_lb(CF_DBG, "Got possible line $1 === $2\n");
            my $var = $1;
            my $value = $2;

            $self->{conf}->{$var} = $value;
        }
    }
    close F;
    return 1;
}

sub getVariable {
    my $self = shift;
    my $name = shift;

    return undef if(!exists($self->{conf}->{$name}));
    return $self->{conf}->{$name};
    
}


1;
