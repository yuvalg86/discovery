#  $Id: AssignManager.pm,v 1.12 2007-10-14 13:18:42 lior Exp $ #  


#****c* sormad/AssignManager
# FUNCTION
# 
# Managing the assignd connection: Registering jobs, removing them and sending
# assignments orders

package Util::AssignManager;

##################### AssingManager global definitions ########
#use Exporter 'import';
require Exporter;
@ISA = qw(Exporter);

@EXPORT = qw (
 $registerTag  $registerTypeTag $registerTypeVal
 $assigndListTag  $assigndTag 
 $jobStatusTag $jobAssignTag 
);

my $registerTag     = "client";
my $registerTypeTag = "type";
my $registerTypeVal = "assignd";
our $assigndListTag  = "assignds";
our $assigndTag      = "assignd";
our $jobStatusTag    = "job-status";
our $jobAssignTag    = "assign-job";

our $providerTag     = "provider";

#################### End of assignd definition part ########
use strict;

use Sys::Syslog;
use Data::Dumper; 
use Socket;
use Carp;
use IO::Socket::INET;
use IO::Select;
use XML::Simple;

use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::JobManager;


sub new;
sub newConnection;
sub handleAssignMsg;
sub assignJob;
sub getStatusStr;

#****m* sormad/AssignManager->new
# FUNCTION
#   Constractor for the AssignManager object
# SYNOPSIS
#   $pm = new AssignManager();
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to a AssignManager
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };
    
    if ( !exists($self->{jobMgr})) {
        return undef;
    }
    
    $self->{listenerList} = ();
    $self->{cfg}          = {};
    $self->{assignH}      = {};
    $self->{lastMsgInfo}  = {};
    $self->{msg_len}      = 1024;
    $self->{recv_timeout} = 3;
    bless($self, $class);
    return $self;
}


sub free {
    my $self = shift;
    foreach my $a (keys(%{$self->{assignH}})) {
        $self->{assignH}->{$a}->{sock}->close();
    }
}
sub getAssignNum {
    my $self = shift;
    my $n = keys(%{$self->{assignH}});
    return $n;
}


sub validateAssigndAddr {
    my $self = shift;
    my $addrStr = shift;

    return 1;
}


#****m* sormad/AssignManager->addNewConnection
# FUNCTION
#   Manage a new connection made to the main socket
# SYNOPSIS
#   $pm = new AssignManager();
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to a AssignManager
#******
sub addAssignConnection {
    my $self = shift;
    my $socket = shift;
    
    my $newconn = $socket->accept();
    
    my $sockaddr        = $newconn->peername();
    my ($port, $iaddr)  = sockaddr_in($sockaddr);
    my $rhostname       = gethostbyaddr($iaddr, AF_INET); 
    my $rhostaddr       = inet_ntoa($iaddr);
    debug_lg(AMGR_DBG, "Got connection on tcp: $rhostname $rhostaddr\n");
    
    # it is now possible to perform IP based validation
    if(!$self->validateAssigndAddr($rhostaddr)) {
        $newconn->close();
        return 0;
    }
    
    # IP is valid we continue
    if(exists($self->{assignH}->{$rhostaddr})) {
        debug_lr(AMGR_DBG, "Already has connection from $rhostname\n");
        $newconn->close();
        return 0 ;
    }

    debug_lb(AMGR_DBG, "Adding new assignd at address $rhostname\n");
    $self->{assignH}->{$rhostaddr}->{sock}     = $newconn;
    $self->{assignH}->{$rhostaddr}->{verified} = 0;
    $self->{assignH}->{$rhostaddr}->{jobs}     = 0;
    return 1;
}


#****m* sormad/AssignManager->deleteAssignConnection
# FUNCTION
#   An assignd disconnected and its connection + jobs are removed
# SYNOPSIS
#   $res = $am->deleteAssignConnection($addr, $readSet);
# ARGUMENTS
#   $addr      The address of the disconnecting assignd
#   $readSet   It is neccesary to remove the connection from the readset before
#              closing the connection (should be fixed)
# RETURN VALUE
#  0        In the connection does not exists
#  1        If the deletion was ok.
#******
sub deleteAssignConnection {
    my $self = shift;
    my $addr = shift;
    my $readSet = shift;
    
    if(!exists($self->{assignH}->{$addr})) {
        debug_lr(AMGR_DBG, "Error $addr conenction does not exists\n");
        return 0;
    }
    
    debug_lb(AMGR_DBG, "Deleting assignd on address $addr\n");
    $readSet->remove($self->{assignH}->{$addr}->{sock});
    $self->{assignH}->{$addr}->{sock}->close();
    $self->{jobMgr}->removeJobsByNode($addr);
    delete($self->{assignH}->{$addr});
    return 1;
}

sub getAssignSock {
    my $self = shift;
    
    my @sockList = ();
    foreach my $a (keys %{$self->{assignH}}) {
        push @sockList, $self->{assignH}->{$a}->{sock};
    }
    return @sockList;
}


sub isAssignSock {
    my $self = shift;
    my $sock = shift;

    debug_ly(AMGR2_DBG, "Checking if sock is from assignd\n");
    my $aH = $self->{assignH};
    foreach my $a (keys(%$aH)) {
        #debug_ly(AMGR_DBG, "\tcheckng addr $a\n");
        
        if($sock == $aH->{$a}->{sock}) {
            debug_ly(AMGR2_DBG, "\tFound matching $a\n");
            return $a;
        }
    }
    return undef;
}

sub isAssigndExists {
    my $self = shift;
    my $addr = shift;
    
    return exists($self->{assignH}->{$addr});
}


sub verifyAssignConnection {
    my $self = shift;
    my $msgH = shift;

    return 0 if(!exists($msgH->{$registerTag}));
    return 0 if(!exists($msgH->{$registerTag}->{$registerTypeTag}));
    return 0 if($msgH->{$registerTag}->{$registerTypeTag} ne $registerTypeVal);
    return 1;
}

sub addListener {
    my $self = shift;
    my $func = shift;
    my $obj = shift;
    
    return (push @{$self->{listenerList}}, {'func'=>$func, 'obj'=>$obj}) - 1;
}

sub triggerListener {
    my $self = shift;
    my $msgH = shift;

   foreach my $listener (@{$self->{listenerList}}) {
       my $obj = $listener->{obj};
       my $func = $listener->{func};
       
       if(defined($obj)) {
           &{$func}($obj, $msgH);
       }  
       else {
           &{$func}($msgH);
       }
   }
}

sub handleJobMsg {
    my $self = shift;
    my $msgH = shift;
    my $addr = shift;
    
    foreach my $id (keys %$msgH) {
        debug_lb(AMGR_DBG, "Job message ID: $id\n");
        $msgH->{$id}->{$mandatoryJobFields->{from}} = $addr;
        $self->{lastMsgInfo}->{type} = "add-job";
        $self->{lastMsgInfo}->{jobId} = $msgH->{$id}->{"id"};
        if(!$self->{jobMgr}->addJob($msgH->{$id})) {
            debug_lr(AMGR_DBG, "Failed to add job ($id) to job manager\n");
        }
    }
    
    $self->triggerListener($self->{lastMsgInfo});
    
    return 1;
}

sub handleJobStatusMsg {
    my $self = shift;
    my $msgH = shift;
    
    foreach my $id (keys %$msgH) {
        debug_lb(AMGR_DBG, "Job status message ID: $id $msgH->{$id}->{content}\n");
        if( $msgH->{$id}->{'content'} =~ /\s+$jobFinishedValue\s+/ ) {
            $self->{lastMsgInfo}->{type} = "remove-job";
            $self->{lastMsgInfo}->{jobId} = $id; 
            $self->triggerListener($self->{lastMsgInfo});
            
            if(!$self->{jobMgr}->removeJob($id)) {
                debug_lr(AMGR_DBG, "Failed to remove job ($id) from job manager\n");
            }
        } elsif ($msgH->{$id}->{'content'} =~ /\s+$jobMigDoneValue\s+/) {
            $self->{lastMsgInfo}->{type} = "mig-done";
            $self->{lastMsgInfo}->{jobId} = $id; 
            debug_lg(AMGR_DBG, "Got mig done message for job $id\n");
            $self->triggerListener($self->{lastMsgInfo});
        } elsif ($msgH->{$id}->{'content'} =~ /\s+$jobRunningValue\s+/) {
            $self->{lastMsgInfo}->{type} = "running";
            $self->{lastMsgInfo}->{jobId} = $id; 
            debug_lg(AMGR_DBG, "Got running message for job $id\n");
            $self->triggerListener($self->{lastMsgInfo});
        }
    }
    return 1;
}


sub handleRegisterMsg {
  my $self = shift;

  $self->{lastMsgInfo}->{type} = "register";
  $self->triggerListener($self->{lastMsgInfo});

}

sub handleAssignMsg {
    my $self = shift;
    my $assigndAddr = shift;
    my $readSet = shift;
    debug_lg(AMGR_DBG, "Handling message from assignd\n");

    if(!$self->isAssigndExists($assigndAddr)) {
        debug_lr(AMGR_DBG, "Error $assigndAddr does not exists in AssignMgr object\n");
        return 0;
    }
    my $assign = $self->{assignH}->{$assigndAddr};
    my $msg = recvAllData($assign->{sock}, $self->{msg_len}, $self->{recv_timeout});
    
    
    if($msg) {
        $msg = "<msg>$msg</msg>";
        debug_lg(AMGR_DBG, "Client message:\n$msg\n");
        # Converting the XML message to a hash
        my $msgH =  eval { XMLin($msg,  ForceArray => [$jobTag, $jobStatusTag], 
                                 KeyAttr => {"$jobTag" =>"+$idTag",
                                             "$jobStatusTag" => "+$idTag"}
                                );
                       };
        if($@) {
            debug_lr(AMGR_DBG, "Error failed to translate message to XML\n");
            return 0;
        }
        
        #        debug_lg(AMGR_DBG, Dumper($msgH));

        my $retVal;
        if(1) { #if($assign->{verified}) {

            if(exists($msgH->{$jobTag})) {
              $retVal = $self->handleJobMsg($msgH->{$jobTag}, $assigndAddr);
            }
            elsif (exists($msgH->{$jobStatusTag})) {
              $retVal = $self->handleJobStatusMsg($msgH->{$jobStatusTag}); 
            }
            elsif (exists($msgH->{$registerTag})) {
              $retVal = $self->handleRegisterMsg();
            }

            return $retVal;
        } else {
            if(!$self->verifyAssignConnection($msgH)) {
                debug_lr(AMGR_DBG, "Connection was not verified in first message -> deleteing\n");
                $self->deleteAssignConnection($assigndAddr, $readSet);
                return 0;
            }
        }
    } else {
        $self->deleteAssignConnection($assigndAddr, $readSet);
        return 0;
    }
    return 1;
}

sub assignJob {
    my $self = shift;
    my $job  = shift;
    

    debug_lb(AMGR_DBG, "Assigning job $job\n");
    my $jobH = $self->{jobMgr}->getJobInfo($job);
    if(!$jobH) {
        debug_lr(AMGR_DBG, "Error: job !!$job!! does not exists\n");
        return 0;
    }
    my $jobStatus = $jobH->{$statusTag};
    my $from = $jobH->{$allJobFields->{from}};

    # FIXME what is the line below??
    if ($jobStatus eq JOB_FINISH_STAT) {
        debug_lb(AMGR_DBG, "Job $jobH->{id} already finished\n");
        return 1;
    }

    if(!exists($self->{assignH}->{$from})) {
        debug_lr(AMGR_DBG, "Error assignd $from does not exists\n");
        return 0;
    }
    
    # The were is used only if there is a run status
    my $where;
    if($jobStatus eq JOB_RUN_STAT ||
      $jobStatus eq JOB_MIG_STAT) {
        $where = $jobH->{$allJobFields->{where}};
        $where =~ s/\s//g;
        my $addr = gethostbyname($where);
        debug_lr(AMGR_DBG, "Error!!!! $where is not correct") unless $addr;
        $where = inet_ntoa($addr);
    }
    
    my $jobAssignAction;
    if($jobStatus eq JOB_RUN_STAT || $jobStatus eq JOB_MIG_STAT) {
        $jobAssignAction = JOB_RUN_STAT;
    } else {
        $jobAssignAction = $jobStatus;
    }
    #$jobAssignAction = JOB_SUSPEND_STAT
    #  if($jobAssignAction eq JOB_NO_BUDGET_STAT);
    
    
    my $xml;
    $xml .= "<$jobAssignTag $idTag=\"$job\">\n";
    $xml .= "\t<$statusTag>$jobAssignAction</$statusTag>\n";
    $xml .= "\t<$providerTag>$where</$providerTag>\n"
      if($where);
    $xml .= "</$jobAssignTag>\n";
    
    debug_ly(AMGR_DBG, "assignd $from\n$xml\n");
    
    my $sock = $self->{assignH}->{$from}->{sock};
    $sock->send($xml);
    
    return 1;
}

#****m* sormad/AssignManager->getStatusStr
# FUNCTION
#   Returns a string containing the status of the assigndMgr object. 
#   This is used mainly for debugging 
# SYNOPSIS
#   $str = $am->getStatusStr();
# ARGUMENTS
# RETURN VALUE
#   A string with the status of the AssignManager
#******
sub getStatusStr {
    my $self = shift;
    
    my $str;

    $str .= "Connected assignd:\n";
    foreach my $addr (sort keys(%{$self->{assignH}})) {
        $str .= "$addr \n";
    }
    return $str;
}

sub getAssignXml {
    my $self = shift;

    my $xml;
    $xml .= "<$assigndListTag>\n";
    foreach my $addr (sort keys(%{$self->{assignH}})) {
        $xml .= "\t<$assigndTag name=\"$addr\"/>\n";
    }
    $xml .= "</$assigndListTag>\n";
    return $xml;
}

1;
    
