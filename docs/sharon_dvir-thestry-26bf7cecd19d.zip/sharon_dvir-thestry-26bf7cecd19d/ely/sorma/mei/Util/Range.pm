#  Range.pm$Id: Range.pm,v 1.2 2007-10-11 08:49:33 lior Exp $ #  


#****c* Util/Range.pm
# FUNCTION
# 
# A library for parsing ranges

package Util::Range;



sub parseRange {
    
    my $arg = shift;
    
    my @computers;
    my @deductlist;
    my @temp;
    my @parts;
    my ($comp, $comps, $deduct);
    
    # split by ,
    @parts = split /,/, $arg;
    
    while (@parts) {
        
        ## get an argument
        $arg = shift @parts;
        
        # see if there's a deduction list (^...)
        ($comps,$deduct)=split /\^/, $arg,2;
        
        # add machines to correct list
        if ($comps) {
            $comps = getCompsFromInfod($comps);
            if (($comps =~ /,/)) {
                if ($deduct) {
                    @parts = ("^".$deduct, @parts);
                }
                @parts = ((split /,/,$comps),@parts);
                next;
            }
            @computers = (@computers, getComps($comps));
        }
        
        if ($deduct) {
            @deductlist = (@deductlist, getComps($deduct));
        }
        
        # process remove list
        foreach $comp (@computers) {
            if (! (grep {/^$comp$/} @deductlist)) {
                @temp = (@temp, $comp);
            }
        }
        
        @computers = @temp;
        @deductlist = ();
        @temp = ();
        
    }
    
    return @computers;
}

sub getCompsFromInfod {
    my $comp = shift;
    if (!($comp =~ /^@/)) {
        return $comp;
    } else {
        $comp =~ s/^@(.*)$/$1/;
    }
    
    sanityCheck();
    
    $comp = `infod-client --server $comp --opt live-list`;
    $comp =~ s/^ (.*)$/$1/;
    chomp $comp;
    
    return $comp;
}

sub getComps {
    my $comps = shift;
    
    # build computer list
    my $head;
    my $num;
    my $hyphen;
    my @complist;
    my ($num1, $num2, $number);
    
    # check for an ip as a machine name
    if ($comps =~ /^(\d{1,3}\.\d{1,3}\.\d{1,3}\.)(\d{1,3}(\.\.\d{1,3})?)$/) 
  #
  
  {
      #}
      ($head,$hyphen,$num) = ($1,"",$2);
      #}{
  } else {
      
      # get machine header (xil,gx,sp...) and machine number
      ($head,$hyphen,$num) = $comps =~ /^([^-\d]+)(-?)(.*)/;
  }    

# if it's a range, create all machines
if ($num =~ /\d+\.\.\d+/) {
    ($num1,$num2)=$num=~/^(\d+)\.\.(\d+)/;
  } else {
    @complist = (@complist, "$comps");
    return @complist;
  }
  foreach $number ($num1..$num2) {
    @complist = (@complist, "$head$hyphen$number");
  }
  
return @complist;
}

1;

