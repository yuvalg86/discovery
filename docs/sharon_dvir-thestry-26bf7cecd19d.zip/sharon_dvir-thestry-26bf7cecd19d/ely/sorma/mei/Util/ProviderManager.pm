#  ProviderManager$Id: ProviderManager.pm,v 1.17 2007-10-17 13:11:19 lior Exp $ #  


#****c* Util/ProviderManager
# FUNCTION
# 
# Manager communication to providers and maintain the list of available 
# providers and their status

package Util::ProviderManager;
use IPC::Open2;
use Util::Range;

########### ProviderManager global definitions #######
#use Exporter 'import';
require Exporter;
@ISA = qw(Exporter);

@EXPORT = qw (
  $defaultInfodClientProg $defaultInfodClientTimeout
  $clustersListTag $clusterTag $repTag
  $providerListTag $providerTag
);

our $defaultInfodClientProg     = "/bin/infod-client";
our $defaultInfodClientTimeout  = "3";

our $clustersListTag      = "clusters";
our $clusterTag           = "cluster";
our $repTag               = "rep";

our $providerListTag   = "providers";
our $providerTag       = "provider";


# This hash should not be here it should be passed to the getProviderXml
# routine as an argument
our $providerMarketFields = {
                             "name"    => 1,
                             "IP"      => 1,
                             "$minPriceTag"  => 1,
                             "cpu-num" => 1,
                             "mem"     => 0,
                            };

########## End of ProviderManager global definitions part ####

use strict;

use Sys::Syslog;
use Data::Dumper; 
use Socket;
use IO::Socket::INET;
use XML::Simple;


use Util::Debug;
use Util::Net;    # for secure_recv and catch_sigpipe function
use Util::Misc;
use Util::ProviderXMLParser;
use providerd::ProviderParam;
use providerd::ProviderCtl;
use Util::MarketProtocol;

#### Functions in this modules #####
# General 
sub new;
sub update;
sub getProvidersXml;
sub setProviderEcoStatus;
sub getError;
sub getClusterNum;
sub getProviderNum;
sub getProviderInfo;
sub addListener;
sub foreachProvider;

# Info gathering
sub addClusterInfoRep;
sub removeClusterInfoRep;
sub probe;

# Price methods
sub setProviderCurrPrice;
sub clearCurrPrice;

# Comm methods
sub getProviderSock;
sub isProviderSock;
sub closeProviderConn;
sub receiveMessage;
sub handleProviderMsg;
sub sendMsg;

############################################

sub mSortOp { return Util::Misc::machines_sort_func($b , $a); }




#****m* Util/ProviderManager->new
# FUNCTION
#   Constractor for the ProviderManager object
# SYNOPSIS
#   $pm = new ProviderManager("providerConf" => $pv_conf
#                             "infodClientProg" => $infod_prog
#                             "timeout" => $timeout);
# ARGUMENTS
#   "providerConf"   The providers configuration, which is a hash describing 
#                    possible providers
#   "infodClientProg The name of the infod-client program to use
#   "timeout"        The timeout to use in the infod-client 
# RETURN VALUE
#  undef    On error
#  A reference to a ProviderManager object on success
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                infodClientProg => $defaultInfodClientProg,
                timeout         => $defaultInfodClientTimeout,
                %params,
               };
    
    $self->{cfg} = {};
    
    if(!($self->{providerCtl} =  providerd::ProviderCtl->new())) {
        debug_lr(PMGR_DBG, "Error while creating providerCtl object\n");
        return undef;
    }
    if(!($self->{providerParser} = Util::ProviderXMLParser->new())) {
        debug_lr(PMGR_DBG, "Error while creating ProviderXMLParser object\n");
        return undef;
    }
    
    my @sl = qw( infod_dead_str infod_status IP name ncpus freepages );
    push @sl, $economyInfoTag;
    $self->{providerParser}->setSelectedItems(\@sl);

    # Internal class information
    $self->{clusterH} = {};
    $self->{providerVec} = {};
    $self->{providerConn} = {};
    
    $self->{recv_len} = 2048;
    $self->{recv_timeout} = 3;
    $self->{retries} = 3;

    $self->{commandPipeR} = undef;
    $self->{commandPipeW} = undef;
    initCommandPipe($self);

    setSignalHandlers($self);
    # Becoming an obejct
    bless($self, $class);
    return $self;
}

sub setSignalHandlers {
  my $sig = shift;
  $SIG{PIPE} =  \&sig_int_hndl;
}

sub sig_int_hndl {
  my $sig = shift;

  debug_lr("Got signal $sig");
}

sub initCommandPipe {
  my $self = shift;

  my $infodClient = $self->{infodClientProg};
  my $timeout = $self->{timeout};
  
  # Command used for probing
  my $command = "$infodClient -i --timeout $timeout";

  my ($readFH, $writeFH);
  if(! open2($readFH, $writeFH, "$command")) {
      debug_lr(PMGR_DBG, "Error opening pipe to infod-client failed: $!\n");
      return 0;
  };

  $self->{commandPipeR} = $readFH;
  $self->{commandPipeW} = $writeFH;

}

sub getStatusStr {
    my $self = shift;
    
    my $str;
    $str .= "Provider Manager Status:\n";
    $str .= "--------------------------\n";
    $str .= "Cluster\t\tRepresentatives\n";
    foreach my $c (sort keys(%{$self->{clusterH}})) {
        my $list = $self->{clusterH}->{$c}->{repList};
        $str .= "$c\t\t@$list\n";
    }
    $str .= "\n\n";
    $str .= "Providers:\tReserv-price:\n";
    foreach my $n (sort mSortOp keys %{$self->{providerVec}}) {
        my $p = $self->{providerVec}->{$n};
        $str .= sprintf("%-10s\t%6.3f\n", $n, $p->{$minPriceTag});;
    }
    return $str;
}

sub getClusterNum {
    my $self = shift;
    return scalar keys %{$self->{clusterH}};
}

sub getProviderNum {
    my $self = shift;
    return scalar keys %{$self->{providerVec}};
}

sub addListener {
    my $self = shift;
    my $func = shift;
    my $obj = shift;
    
    return (push @{$self->{listenerList}}, {'func'=>$func, 'obj'=>$obj}) - 1;
}

sub triggerListener {
    my $self = shift;
    my $msgH = shift;

   foreach my $listener (@{$self->{listenerList}}) {
       my $obj = $listener->{obj};
       my $func = $listener->{func};
       
       if(defined($obj)) {
           &{$func}($obj, $msgH);
       }  
       else {
           &{$func}($msgH);
       }
   }
}


#****m* Util/ProviderManager->addClusterInfoRep
# FUNCTION
#   Add an information representative 
# SYNOPSIS
#   $res = $pm->addClusterInfoRep($name, $infoRepList);
# ARGUMENTS
#   $name          The name of the cluster
#   $infoRepList   A reference to a list of representatives e.g., ["mos1","mos2","mos3"]
# RETURN VALUE
#  0   on error
#  1   on success
#******
sub addClusterInfoRep {
    my $self = shift;
    my $clusterName = shift;

    my $info = shift;
    my $infoRepList = $info->{rep};

    print "Cluster $clusterName Info:\n", Dumper($info);
    debug_lb(PMGR_DBG, "Adding info representatives to $clusterName reps: @$infoRepList\n");
    if(!exists($self->{clusterH}->{$clusterName})) {
        my @tmpList = @$infoRepList ;
        $self->{clusterH}->{$clusterName}->{repList} = \@tmpList;
        $self->{clusterH}->{$clusterName}->{repInd} = 0;
        
    }else {
        my $rl = $self->{clusterH}->{$clusterName}->{repList};
        push @$rl, @$infoRepList;
    } 
 


    # If we have a node-range element we create a hash of the nodes this cluster
    # may use or not.
    if(exists($info->{'node-range'}) ) {
        # parsing the range
        my @nodeList = Util::Range::parseRange($info->{'node-range'});
        if(!@nodeList) { debug_lr(PMGR_DBG, "Error parsing node range\n"); return 0;}
        my $nodeHash = {};
        foreach my $n (@nodeList) { $nodeHash->{$n} = 1;};
        $self->{clusterH}->{$clusterName}->{'node-range'} = $nodeHash;
    }
    return 1;   
}

sub removeClusterInfoRep {
    my $self = shift;
    my $clusterName = shift;
    
    debyg_lb(PMGR_DBG, "Removing $clusterName representatives\n");
    delete($self->{clusterH}->{$clusterName}) 
      if(exists($self->{clusterH}->{$clusterName}));
    return 1;
}

#****m* Util/ProviderManager->probeNode
# FUNCTION
#   Get the xml string of a cluster via a node
# SYNOPSIS
#   $res = $pm->probeNode($node, $outRef);
# ARGUMENTS
#   $node          The node to prob (e.g., mos1);
#   $outRef        Reference to a scalar that should contain the output 
# RETURN VALUE
#  0   on error
#  1   on success
#******
sub probeNode {
    my $self = shift;
    my $node = shift;
    my $outputRef = shift;
    
    my $buff = "";

    my $readPipe = $self->{commandPipeR};        
    my $writePipe = $self->{commandPipeW}; 

    debug_lg(PMGR2_DBG, "Sending: get $node, on pipe\n");
    print $writePipe "get $node\n";
    
    
    my $size = <$readPipe>;

    my $res;


    if (! defined $size) {
      debug_lr(PMGR_DBG, "Error in read $! \n");
      $self->initCommandPipe();
      return 0;
    } elsif ($size !~ /^\d+$/) {
      $res = <$readPipe>;
      $res = <$readPipe>;
      debug_lr(PMGR_DBG, "Error can't connect infod\n");

      return 0;
    }

    chomp($size);
    debug_lg(PMGR2_DBG, "Trying to read from pipe $size bytes\n");   
    
    if (($res = read($readPipe, $buff, $size)) != $size) {
      if (! defined $res) {
        debug_lr(PMGR_DBG, "Error in read !$\n");
        $self->initCommandPipe();
      } else {
        $res = <$readPipe>;
        $res = <$readPipe>;
        debug_lr(PMGR_DBG, "Error: not reading enough data from pipe ($res : $size): $!\n");
      }
      return 0;
    } 


    #print "SSSSSSSSSSSSSSSSSS:\n",$output;

    # Probing successed.
    $$outputRef = $buff;
    return 1;
}


sub extractNodeInfo {
    my $self = shift;
    my $allInfo = shift;

    my $resInfo = {};
    
    #debug_ly(PMGR_DBG, Dumper($allInfo));
    #print "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSs\n";
    return 0 if($allInfo->{infod_dead_str} ne "alive");
    return 0 if(!exists($allInfo->{$economyInfoTag}));
    return 0 if($allInfo->{$economyInfoTag} eq "error");
    return 0 if(!ref($allInfo->{$economyInfoTag}));
    return 0 if(exists($allInfo->{$economyInfoTag}->{error}));
 

    my $addr = gethostbyname($allInfo->{name});
    $resInfo->{IP}              = inet_ntoa($addr);
    $resInfo->{name}            = $allInfo->{name};
    $resInfo->{'cpu-num'}       = $allInfo->{ncpus};
    $resInfo->{mem}             = ($allInfo->{freepages} * 4096.0) / (1024*1024);
    
    my $ecoInfo = $allInfo->{$economyInfoTag};
    foreach my $k (keys(%$ecoInfo)) {
        $resInfo->{$k} = $ecoInfo->{$k};
    }

#     $resInfo->{$minPriceTag}    = $ecoInfo->{$minPriceTag};
#     $resInfo->{$currPriceTag}   = $ecoInfo->{$currPriceTag};
#     $resInfo->{$statusTag}      = $ecoInfo->{$statusTag};
#     $resInfo->{$onTimeTag}      = $ecoInfo->{$onTimeTag};
#     $resInfo->{$schedPriceTag}  = $ecoInfo->{$schedPriceTag};
#     $resInfo->{$incPriceTag}    = $ecoInfo->{$incPriceTag};



    return $resInfo;
}

sub extractClusterInfo {
    my $self = shift;
    my $clusterName = shift;
    my $vectorH = shift;

    #delete($self->{clusterH}->{$clusterName}->{vec});
    foreach my $n (keys %{$vectorH->{cluster_info}}) {
        #debug_lr(PMGR_DBG, Dumper($vectorH->{cluster_info}->{$n}));
        # Skeeping a node if it does not appear in the node-range 
        # and we have a node-range defined for this cluster
        next if (exists($self->{clusterH}->{$clusterName}->{'node-range'}) &&
                 !exists($self->{clusterH}->{$clusterName}->{'node-range'}->{$n}));
        my $nodeInfo = $self->extractNodeInfo($vectorH->{cluster_info}->{$n});
        next if !$nodeInfo;
        $nodeInfo->{cluster} = $clusterName;
        $self->{providerVec}->{$n} = $nodeInfo; 
    }
    #debug_lg(PMGR_DBG, Dumper($newVec));
    #$self->{clusterH}->{$clusterName}->{vec} = $newVec;
    
}

sub probe {
  my $self = shift;

  $self->{prevVec} = $self->{providerVec};
  #delete($self->{providerVec});
  $self->{providerVec} = {};

  debug_lb(PMGR2_DBG, "Probing clusters\n");
  foreach my $c (sort keys(%{$self->{clusterH}})) {
    my $vectorXmlRef;
    for (my $i = 0; $i< $self->{retries};$i++) {
      my $clusterRep = 
        $self->{clusterH}->{$c}->{repList}->[$self->{clusterH}->{$c}->{repInd}];
      debug_lg(PMGR2_DBG,"Probing $clusterRep try $i\n");
      
      
      if(! $self->probeNode($clusterRep, \$vectorXmlRef)) {
        debug_lr(PMGR_DBG, "Error probing $clusterRep\n");
        $self->{clusterH}->{$c}->{repInd}++;
   
        $self->{clusterH}->{$c}->{repInd} = $self->{clusterH}->{$c}->{repInd} %
          scalar(@{$self->{clusterH}->{$c}->{repList}});
   
        # Here we should choose the next representative if any
        # FIXME we should make sure that if there is not even one live representative
        # FIXME then we should not probe the nodes forever
        next;
      }
      
      my $vectorH = $self->{providerParser}->parseStr(\$vectorXmlRef);
      if(!defined($vectorH)) {
        debug_lr(PMGR_DBG, "Error failed to translate vector to XML\n");
        next;
      }

      # Taking the hash and storing the relevant stuff
      $self->extractClusterInfo($c, $vectorH);

    
      debug_lg(PMGR2_DBG, "Found " . $self->getProviderNum() . " Providers\n");
      #debug_lg(PMGR_DBG, Dumper($self->{providerVec}));
      #debug_lg(PMGR_DBG, $self->getProvidersXml());
      last;
    }
  }

  # Comparing the oldVec to the current providerVec and sending events of 
  # add-provider, remove-provider, modified-provider
#  print "Curr Vec: \n", Dumper($self->{providerVec});
#  print "Prev Vec: \n", Dumper($self->{prevVec});
  
  $self->detectProvidersChanges();
  delete($self->{prevVec});
    
  return 1;
}

sub detectProvidersChanges {
    my $self = shift;
    
    # Iterating over the providerVec and adding new providers
    foreach my $newP (keys %{$self->{providerVec}}) {
        #print "Checking $newP for addition\n";
        if(!exists($self->{prevVec}->{$newP})) {
            $self->{lastEventInfo}->{type} = "add-provider";
            $self->{lastEventInfo}->{id} = $newP;
            debug_ly(PMGR_DBG, "Adding new provider $newP\n");
            $self->triggerListener($self->{lastEventInfo});
        } 
        
        # Deleting the new/existing provider from the prevVec 
        delete $self->{prevVec}->{$newP};

    }
    
    # The providers remaining in the prevVec are such that does not exists in
    # the currVec
    foreach my $old (keys %{$self->{prevVec}}) {
        $self->{lastEventInfo}->{type} = "del-provider";
        $self->{lastEventInfo}->{id} = $old;
        debug_lg(PMGR_DBG, "removing provider $old\n");
        $self->triggerListener($self->{lastEventInfo});
    }
    delete $self->{prevVec};
    $self->{prevVec} = {};
}

sub getProviderXml {
    my $self = shift;
    my $p    = shift;
    my $marketXml = shift;
    
    my $pInfo = $self->{providerVec}->{$p};

    my $xml;
    $xml .= "<$providerTag name=\"$p\" >\n";

    if($marketXml) {
        foreach my $mk (keys %$providerMarketFields) {
            next if($mk eq "name");
            if($providerMarketFields->{$mk} and !exists($pInfo->{$mk})) {
                debug_lr(JMGR_DBG, "Error a mandatory market field $mk is not present in provider $p\n");
                return undef;
            }
            
            if(exists($pInfo->{$mk})) {
                if(exists($providerFieldsFmt->{$mk})) {
                    $xml .= sprintf("\t<$mk>". $providerFieldsFmt->{$mk} . "</$mk>\n", 
                                    $pInfo->{$mk});
                }
                else {
                    $xml .= "\t<$mk>$pInfo->{$mk}</$mk>\n"
                }
            }
        }
    }
    else {
        foreach my $k (keys %$pInfo) {
            next if($k eq "name");
            if(exists($providerFieldsFmt->{$k})) {
                $xml .= sprintf("\t<$k>". $providerFieldsFmt->{$k} . "</$k>\n", 
                                $pInfo->{$k});
            }
            else {
                #print "$k\n";
                $xml .= "\t<$k>$pInfo->{$k}</$k>\n";
            }
        }
    }

    $xml .= "</$providerTag>\n";
    return $xml;
}


sub getProvidersXml {
    my $self = shift;
    my $marketXml = 0;
    $marketXml = shift
      if(@_);
    
    my $xml;
    

    $xml .= "<$providerListTag>\n";
    foreach my $p (keys %{$self->{providerVec}}) {
        my $providerXml = $self->getProviderXml($p, $marketXml);
        $xml .= $providerXml;
    }
    $xml .= "</$providerListTag>\n";
    return $xml;
}

sub getProvidersMarketXml {
    my $self = shift;
    return $self->getProvidersXml(1);
}



sub getClustersXml {
    my $self = shift;
    
    my $xml;
    
    $xml .= "<$clustersListTag>\n";
    
    foreach my $c (sort keys(%{$self->{clusterH}})) {
        my $list = $self->{clusterH}->{$c}->{repList};
        $xml .= "\t<$clusterTag name=\"$c\">\n";
        foreach my $rep (@$list) {
            $xml .= "\t\t<$repTag>$rep</$repTag>\n";
        }
        $xml .= "\t</$clusterTag>\n";
    }
    $xml .= "</$clustersListTag>\n";
    return $xml;
}

sub setProviderCurrPrice {
    my $self = shift;
    my $provider = shift;
    my $price = shift;
    
    if(exists($self->{providerVec}->{$provider})) {
        my $pH = $self->{providerVec}->{$provider};
        my $oldPrice = $pH->{$currPriceTag};
        if(!$oldPrice != $price) {
            debug_lg(PMGR_DBG, "Provider $provider price changed $oldPrice $price\n");
            
        }
        $pH->{$currPriceTag} = $price;
    }

    my $res = $self->{providerCtl}->setCurrPrice($provider, $price);
    return $res;
}


# Setting all providers curr-price to 0 and sending a message to those who had
# a >0 price before
sub clearCurrPrice {
    my $self = shift;

    foreach my $p (keys %{$self->{providerVec}}) {
        my $pH = $self->{providerVec}->{$p};
        my $oldPrice = $pH->{$currPriceTag};
        
        if($oldPrice != 0) {
            my $res = $self->{providerCtl}->setCurrPrice($p, 0);
            $pH->{$currPriceTag} = 0;
        }
    }
}


#****m* Util/ProviderManager->getProviderInfo
# FUNCTION
#   Get information about a given provider. The result is its information hash
# SYNOPSIS
#   $res = $pm->addProviderInfo($name);
# ARGUMENTS
#   $IP     "The name of the provider 
# RETURN VALUE
#  undef    on error
#  hash-ref on success (the given provider was found)
#******
sub getProviderInfo {
    my $self = shift;
    my $name = shift;

    if(exists($self->{providerVec}->{$name})) {
        return $self->{providerVec}->{$name};
    }
    return undef;
}

#****m* Util/ProviderManager->foreachProvider
# FUNCTION
#   An iterator over the providers
# SYNOPSIS
#   $res = $pm->foreachProvider($funcRef, $dataRef);
# ARGUMENTS
#   $funcRef       A reference to a function that will be run for each provider
#   $dataRef       A reference to a data that will be passed for each function call
# RETURN VALUE
#   none
#******
sub foreachProvider {
    my $self = shift;
    my $func = shift;
    my $data = shift;

    #print Dumper $self->{jobH};
    foreach my $p (keys %{$self->{providerVec}}) {
        #   print "Doing $j\n";
        &{$func}($self->{providerVec}->{$p}, $data);
    }
}

#****m* Util/ProviderManager->getProviderSock
# FUNCTION
#   Returns a list of all the sockets which connects to providers
# SYNOPSIS
#   @sockList = $pm->getProviderSock();
# ARGUMENTS
# RETURN VALUE
#   A list of sockets used by providers
#******
sub getProviderSock {
    my $self = shift;

    my @s = ();
    foreach my $p (keys %{$self->{providerConn}}) {
        push @s, $self->{providerConn}->{$p}->{socket};
    }
    return @s;
}

#****m* Util/ProviderManager->isProviderSock
# FUNCTION
#   Checks if the given socket (filehandle) is one of the providers connections
# SYNOPSIS
#   $res = $pm->isProviderSock($fh);
# ARGUMENTS
#   $fh    The filehandle in question
# RETURN VALUE
#   The name of the provider if this is a provider file handle
#   undef if this is not a provider file handle.
#******
sub isProviderSock {
    my $self = shift;
    my $fh = shift;

    foreach my $p (keys %{$self->{providerConn}}) {
        if($self->{providerConn}->{$p}->{socket} == $fh) {
            return $p;
        }
    }
    return undef;
}

#****m* Util/ProviderManager->sendMsg
# FUNCTION
#   Send a message to a provider. The connection is initialized if there
#   is no active connection;
# SYNOPSIS
#   $res = $pm->sendMsg($provider, $msg)
# ARGUMENTS
#   $provider      Name of provider to send message to.
#   $msg           Message to send
# RETURN VALUE
#   0    on error 
#   1    on success
#******
sub sendMsg {
    my $self = shift;
    my $provider = shift;
    my $xmlMsg = shift;

    my $sock;
    debug_lg(PMGR_DBG, "Sending a message to provider: $provider\n");
    # If necessary establish connection to provider
    if(!exists($self->{providerConn}->{$provider}) || 
       !exists($self->{providerConn}->{$provider}->{socket})||
       !defined($self->{providerConn}->{$provider}->{socket})) {

        $sock = $self->{providerCtl}->initTCPSock($provider);
        debug_lr(PMGR_DBG, "Error: initTCPSock failed\n")
          if(!defined($sock));
        return 0 if(!defined($sock));
        $self->{providerConn}->{$provider}->{socket} = $sock;
    } else {
        $sock = $self->{providerConn}->{$provider}->{socket};
    }
    
    if(!defined($sock)) {
        debug_lr(PMGR_DBG, "Error socket is not defined\n");
    }
    
    return sendMarketMsg($sock ,$xmlMsg);
}

#****m* Util/ProviderManager->closeProviderConn
# FUNCTION
#   Close a connection to a provider
# SYNOPSIS
#   $res = $pm->closeProviderConn($provider);
# ARGUMENTS
#   $provider      Name of provider to close connection to.
# RETURN VALUE
#   0    on error (e.g. provider does not exists)
#   1    on success
#******
sub closeProviderConn {
    my $self = shift;
    my $provider = shift;

    return 0 if(!exists($self->{providerConn}->{$provider}));
    
    $self->{providerConn}->{$provider}->{socket}->close();
    delete($self->{providerConn}->{$provider});
    return 1;
}

#****m* Util/ProviderManager->receiveMessage
# FUNCTION
#   Receive a message from a given provider
# SYNOPSIS
#   $msg = $pm->receiveMessage($provider);
# ARGUMENTS
#   $provider      Name of provider to receive message from
# RETURN VALUE
#   The message on success
#   undef on error;
#******
sub receiveMessage {
    my $self = shift;
    my $provider = shift;

    return 0 if(!exists($self->{providerConn}->{$provider}));
    
    my $sock = $self->{providerConn}->{$provider}->{socket};
    my $msg = recvMarketMsg($sock, $self->{recv_timeout});
#    my $msg = secure_msg_recv($sock, $headerSize, 
#                              $self->{recv_timeout});
    if(!$msg) {
        $self->closeProviderConn($provider);
    }
    return $msg;
}

#****m* Util/ProviderManager->handleProviderMsg
# FUNCTION
#   Getting a message from one of the providers
# SYNOPSIS
#   $res = $pm->foreachProvider($funcRef, $dataRef);
# ARGUMENTS
#   $funcRef       A reference to a function that will be run for each provider
#   $dataRef       A reference to a data that will be passed for each function call
# RETURN VALUE
#   none
#******
sub handleProviderMsg {
    my $self = shift;
    
    debug_lg(PMGR_DBG, "Handling provider message\n");
    
}

1;

