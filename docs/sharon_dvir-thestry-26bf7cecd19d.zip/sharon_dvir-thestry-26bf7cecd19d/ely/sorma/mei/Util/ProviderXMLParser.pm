#  ProviderXMLParser $Id: ProviderXMLParser.pm,v 1.3 2007-04-29 08:15:10 lior Exp $ #  


#****c* Util/ProviderXMLParser
# FUNCTION
# 
# This module parse an XML string which was produced by the infod-client
# program. The output of the module is a Hash contining the following:
#
# $h => { cluster_info => {
#             node1 => {
#                      item1 => val1,
#                      item2 => val2,
#             },
#             node2 => {
#                      item1 => val1,
#                      item2 => val2,
#             }, ...
#
# Where node1 and node2 are the names of the nodes found in the xml under
# the "node" element. And item1 and item2 are the item selected by the module
# This module uses the XML::Parser module to parse the xml string.
# 

package Util::ProviderXMLParser;


use Time::HiRes qw( gettimeofday tv_interval );
use XML::Parser;
use Data::Dumper;
use Util::Debug;

my $elementsToSave = {}; 

my $nodesInfo = {};
my $inNode = 0;
my $inName = 0;
my $currNode = "DDDDD";
my $currElement = "EEEEE";
my $elementList = ();
my $currIndex = -1;
my $nodeIndex = -1;
my $inElementToSave = 0;
my $saveCurrElement = 0;

my $currHashRef;
my $hashRefList = ();

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };
    bless($self, $class);

    $self->{parser} = new XML::Parser(Handlers => {Start => \&handle_start,
                                                   End   => \&handle_end,
                                                   Char  => \&handle_char});
    if(!$self->{parser}) {
        debug_lr(PROVIDER_XML_DBG, "Error creating XML::Parser object\n");
        return undef;
    }
    $nodesInfo = {};
    return $self;
}

sub setSelectedItems {
    my $self = shift;
    my $selectedListRef = shift;
    
    # Generating the hash of elementsToSave
    $elementsToSave = {};
    foreach my $item (@$selectedListRef) {
        debug_ly(PROVIDER_XML_DBG, "Setting selected item: $item\n");
        $elementsToSave->{$item} = 1;
    }
}
    
sub parseStr {
    my $self = shift;
    my $xmlStrRef = shift;

    $nodesInfo = {};
    my $beforeTime = [gettimeofday];
    
    #print "DDDDDDDDDD", $$xmlStrRef;
    eval {$self->{parser}->parsestring($$xmlStrRef);};
    if($@) {
        debug_lr(PROVIDER_XML_DBG, "Error parsing XML\n$@\n");
        return undef;
    }
    my $afterTime = [gettimeofday];
    my $elapsed = tv_interval($beforeTime, $afterTime);
    debug_ly(PROVIDER_XML_DBG, "Elapsed $elapsed\n");
    return $nodesInfo;
}


sub getParentRef {
    my $itemIndex = shift;

    my $ref = $nodesInfo;
    for(my $i = 0 ; $i < $itemIndex ; $i++) {
        #print "Getting ref of $elementList[$i]\n";
        if(!exists($ref->{$elementList[$i]})) {
            $ref->{$elementList[$i]} = {};
            
        }
        $ref = $ref->{$elementList[$i]};
    }
    
    return $ref;
}

sub getRefFromList {
    my $itemIndex = shift;
    
    my $ref;
    if($inNode) {
        return $currNodeHash 
          if($itemIndex == ($nodeIndex + 1));

        $ref = $currNodeHash;
        
        for(my $i = $nodeIndex+1 ; $i < $itemIndex ; $i++) {
            #print "Getting ref of $elementList[$i]\n";
            if(!exists($ref->{$elementList[$i]})) {
                $ref->{$elementList[$i]} = {};
            }
            $ref = $ref->{$elementList[$i]};
        }
    }
    else {
        $ref = $nodesInfo;
        for(my $i = 0 ; $i < $itemIndex ; $i++) {
            #print "Getting ref of $elementList[$i]\n";
            if(!exists($ref->{$elementList[$i]})) {
                $ref->{$elementList[$i]} = {};
                
            }
            $ref = $ref->{$elementList[$i]};
        }
    }
    return $ref;
}

sub handle_start {
    my $expat = shift;
    my $element = shift;
    my @attrList = @_;

    $currElement = $element;
    push @elementList, $element;
    $currIndex++;


    if($element eq "node") {
        $inNode = 1;
        $nodeIndex = $currIndex;
        $currNodeHash = {};
    } elsif ($element eq "name") {
        $inName = 1;
    }
    
    if(!$inElementToSave &&  exists($elementsToSave->{$element})) {
        $inElementToSave = 1;
    }
     
    # Saving attributes if any inside node or items to save
    if($inElementToSave or $element eq 'node') {
        # The next line update the currHashRef so the handle_char routine will have it 
        # ready
        $currHashRef = getRefFromList($currIndex);

        # In case of attributes in the node element or saved elements we keep the 
        # attributes as well
        if(@attrList) {
            for(my $i=0 ; $i < @attrList ; $i+=2) {
                $currHashRef->{$attrList[$i]} = $attrList[$i+1];
            }
        }
    }
}

sub handle_end {
    my $expat = shift;
    my $element = shift;
    
    if($element eq 'node') {
        $inNode = 0;
        my $parentRef = getParentRef($currIndex);
        $parentRef->{$currNode} = $currNodeHash;
    } elsif($element eq 'name') {
        $inName = 0;
    }

    if($inElementToSave && exists($elementsToSave->{$element})) {
        $inElementToSave = 0;
    }
    pop @elementList;
    $currIndex--;
}

sub handle_char {
    my $expart = shift;
    my $string = shift;

    if($inName) {
        $currNode = $string;
    }
    
    if($inElementToSave) {

        # The following line is VERY IMPORTANT since the infod-client xml 
        # generate some spaces in some recursive tags
        return if($string =~ m/^\s+$/);
        $currHashRef->{$currElement} = $string;
    }
}

1;
