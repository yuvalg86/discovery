#!/usr/bin/perl -w

package TestProviderXMLParser;

use base qw(Test::Unit::TestCase);

use strict;

use Util::ProviderXMLParser;
use Util::Debug;
use Data::Dumper;

sub new {
    my $self = shift()->SUPER::new(@_);
    # your state for fixture here
    return $self;
}

sub readFile {
    my $self = shift;
    my $fileName = shift;

    my $res = 1;
    open(F, "provider-xml-files/$fileName") or $res =0;
    $self->assert($res, "Failed opening xml-small file: $!");
    my @lines = <F>;
    my $str = join('', @lines);
    return $str;
}

sub test_parseShortXML {
    my $self = shift;
    my $res;
#    addDebugLevel(PROVIDER_XML_DBG);
    debug_lg(PROVIDER_XML_DBG, "\n");
    
    my $providerParser = new Util::ProviderXMLParser();
    $self->assert($providerParser, "Error creating ProviderXMLParser object");
    
    my @selectedItems = qw (name infod_dead_str infod_status load speed ncpus freepages
                            totalpages economy-status);
    $providerParser->setSelectedItems(\@selectedItems);
    
    my $xmlStr = $self->readFile("xml-small");
    my $providerH  = $providerParser->parseStr(\$xmlStr);
    if(isDebugLevelOn(PROVIDER_XML_DBG)) {
        print Dumper($providerH);
    }
    
    # Checking the hash itself
    $self->assert(defined($providerH), "Error parsing small-file");

    $res = exists($providerH->{cluster_info}->{sorma1});
    $self->assert($res, "Sorma1 entry is missing from hash");
    
    $res = exists($providerH->{cluster_info}->{sorma1}->{load});
    $self->assert($res, "Sorma1->load entry is missing from hash");
    
    # Checking that the age attribute was added
    $res = exists($providerH->{cluster_info}->{sorma1}->{age});
    $self->assert($res, "Sorma1->age entry is missing from hash");
    
    # Checking that an xml entry economy-info was included as well 
    $res = exists($providerH->{cluster_info}->{sorma1}->{'economy-status'});
    $self->assert($res, "Sorma1->economy-status entry is missing from hash");
    $res = exists($providerH->{cluster_info}->{sorma1}->{'economy-status'}->{error});
    $self->assert($res, "Sorma1->economy-status->error is missing from hash");
    

    clearDebugLevel();
}


sub test_parseLongXML {
    my $self = shift;
    my $res;
    
    #addDebugLevel(PROVIDER_XML_DBG);
    debug_lg(PROVIDER_XML_DBG, "\n");
    
    my $providerParser = new Util::ProviderXMLParser();
    $self->assert($providerParser, "Error creating ProviderXMLParser object");
    
    my @selectedItems = qw (name infod_status load);
    $providerParser->setSelectedItems(\@selectedItems);
    
    my $xmlStr = $self->readFile("xml-big");
    my $providerH  = $providerParser->parseStr(\$xmlStr);
    if(isDebugLevelOn(PROVIDER_XML_DBG)) {
        print Dumper($providerH);
    }
    
    # Checking the hash itself
    $self->assert(defined($providerH), "Error parsing small-file");

    for(my $i=1 ; $i<=38 ; $i++) {
        my $node = "sorma$i";
        

        $res = exists($providerH->{cluster_info}->{$node});
        $self->assert($res, "$node entry is missing from hash");
    
        $res = exists($providerH->{cluster_info}->{$node}->{load});
        $self->assert($res, "$node ->load entry is missing from hash");
    }
    

    clearDebugLevel();
}


sub test_extraSpaceXML {
    my $self = shift;
    my $res;
    
    #addDebugLevel(PROVIDER_XML_DBG);
    debug_lg(PROVIDER_XML_DBG, "\n");
    
    my $providerParser = new Util::ProviderXMLParser();
    $self->assert($providerParser, "Error creating ProviderXMLParser object");

    my @sl = qw( infod_dead_str infod_status IP name ncpus freepages economy-status );
    $providerParser->setSelectedItems(\@sl);
    
    my $xmlStr = $self->readFile("xml-extra-space");
    my $providerH  = $providerParser->parseStr(\$xmlStr);
    if(isDebugLevelOn(PROVIDER_XML_DBG)) {
        print Dumper($providerH);
    }
    
    # Checking the hash itself
    $self->assert(defined($providerH), "Error parsing extra-space file");

    # Sorma3 should have an economy-status field
    $res = exists($providerH->{cluster_info}->{sorma3});
    $self->assert($res, "sorma3 entry is missing from hash");
    
    $res = exists($providerH->{cluster_info}->{sorma3}->{'economy-status'}->{'curr-price'});
    $self->assert($res, "sorm3 ->economy-info->curr-price entry is missing from hash");

    clearDebugLevel();
}


1;

package main;

use Test::Unit::TestRunner;

my $testrunner = Test::Unit::TestRunner->new();
$testrunner->start("TestProviderXMLParser");
