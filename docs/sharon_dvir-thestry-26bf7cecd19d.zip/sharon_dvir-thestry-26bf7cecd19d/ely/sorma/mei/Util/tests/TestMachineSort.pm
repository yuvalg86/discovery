#!/usr/bin/perl -w

package TestMachineSort;
use base qw(Test::Unit::TestCase);

use strict;

use Util::Misc;
use Util::Debug;
use Data::Compare;

sub new {
    my $self = shift()->SUPER::new(@_);
    # your state for fixture here
    return $self;
}


my @mList_1 = qw( sorma1 sorma10 sorma2 sorma3 sorma4);
my @expected_1= qw( sorma1 sorma2 sorma3 sorma4 sorma10 );

sub sort_op { return Util::Misc::machines_sort_func($b , $a); }
sub test_simpleSort {
    my $self = shift;
    
    #addDebugLevel(TF_DBG);
    debug_lg(TF_DBG, "\n");
    print "Before sort: @mList_1\n";
    my @sortList = sort sort_op @mList_1;
    print "After sort: @sortList \n";
    $self->assert(Compare(@sortList, @expected_1) == 1, 
                  "mList_1 was not sorted as expected ( @sortList )");

}




1;
