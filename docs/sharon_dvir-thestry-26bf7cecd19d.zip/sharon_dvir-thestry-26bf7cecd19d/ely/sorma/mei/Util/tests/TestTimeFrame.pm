#!/usr/bin/perl -w

package TestTimeFrame;
use base qw(Test::Unit::TestCase);

use strict;

use Util::TimeFrame;
use Util::Debug;
use Data::Compare;

sub new {
    my $self = shift()->SUPER::new(@_);
    # your state for fixture here
    return $self;
}


my $simple_frame_1 = 
  {
   'frame' => [
               {
                'end' =>   '18:30',
                'start' => '10:30'
               },
               {
                'end'   => '6:00',
                'start' => '4:00'
               }
              ]
  };


sub test_simple_1 {
    my $self = shift;
    
    #addDebugLevel(TF_DBG);
    debug_lg(TF_DBG, "\n");
    my $tf = new Util::TimeFrame('conf' => $simple_frame_1);
    $self->assert_not_null($tf, "Unable to create TimeFrame object");
    
    my $res = $tf->getOpenStatus("10:33");
    $self->assert($res >0, "Open status is not > 0");
    
    $res = $tf->getOpenStatus("8:00");
    $self->assert($res == 0, "Open status for 8:00 is not 0");
  
    $res = $tf->getOpenStatus("4:00");
    $self->assert($res == 2, "Open status for 4:00 is not 2");
}


my $simple_frame_2 = 
  {
   'frame' => {
                'end' =>   '18:30',
                'start' => '10:30'
               },
  };


# The TimeFrame object should handle also single frames which appear not in an anonymous 
# list but as an anonymous hash.
sub test_simple_2 {
    my $self = shift;
    
    #addDebugLevel(TF_DBG);
    debug_lg(TF_DBG, "\n");
    my $tf = new Util::TimeFrame('conf' => $simple_frame_2);
    $self->assert_not_null($tf, "Unable to create TimeFrame object");
    
    my $res = $tf->getOpenStatus("10:33");
    $self->assert($res >0, "Open status is not > 0");
    
    $res = $tf->getOpenStatus("8:00");
    $self->assert($res == 0, "Open status for 8:00 is not 0");
  
}




my $split_frame_1 = 
  {
   'frame' => [
               {
                'start' => '22:30',
                'end' =>   '7:30'
               },
              ]
  };


sub test_split_1 {
    my $self = shift;
    
    #addDebugLevel(TF_DBG);
    debug_lg(TF_DBG, "\n");
    my $tf = new Util::TimeFrame('conf' => $split_frame_1);
    $self->assert_not_null($tf, "Unable to create TimeFrame object");
    
    my $res = $tf->getOpenStatus("6:30");
    $self->assert($res >0, "Open status is not > 0");

    $res = $tf->getOpenStatus("22:30");
    $self->assert($res == 9, "Open status is not 9 ($res)");
    
}


my $contained_frame_1 = 
  {
   'frame' => [
               {
                'start' => '10:30',
                'end' =>   '12:30'
               },
               {
                'start' => '8:30',
                'end' =>   '14:30'
               },
              ]
  };


sub test_contained_1 {
    my $self = shift;
    
    #addDebugLevel(TF_DBG);
    debug_lg(TF_DBG, "\n");
    my $tf = new Util::TimeFrame('conf' => $contained_frame_1);
    $self->assert_not_null($tf, "Unable to create TimeFrame object");

    my $res = $tf->getOpenStatus("11:30");
    $self->assert($res == 3, "Open status is not 3 ($res)");
    
}

my $empty_frame_1 = 
  {
   'frame' => [],
  };


sub test_empty_1 {
    my $self = shift;
    
    #addDebugLevel(TF_DBG);
    debug_lg(TF_DBG, "\n");
    my $tf = new Util::TimeFrame('conf' => $empty_frame_1);
    $self->assert_not_null($tf, "Unable to create TimeFrame object");
    
    my $res = $tf->getOpenStatus("11:30");
    $self->assert($res == 0, "Open status is not 0 ($res)");

    $tf = new Util::TimeFrame();
    $self->assert_not_null($tf, "Unable to create TimeFrame object");
    $res = $tf->getOpenStatus("11:30");
    $self->assert($res == 0, "Open status is not 0 ($res)");
    
}


my $always_frame_1 = 
  {
   'always' => 1,
   'frame' => [],
  };

sub test_always_1 {
    my $self = shift;
    
    #addDebugLevel(TF_DBG);
    debug_lg(TF_DBG, "\n");
    my $tf = new Util::TimeFrame('conf' => $always_frame_1);
    $self->assert_not_null($tf, "Unable to create TimeFrame object");
    
    my $res = $tf->getOpenStatus("11:30");
    $self->assert($res == -1, "Open status is not -1 ($res)");
    
}



1;
