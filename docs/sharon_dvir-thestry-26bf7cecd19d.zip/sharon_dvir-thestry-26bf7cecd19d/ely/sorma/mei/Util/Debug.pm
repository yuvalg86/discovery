#
#  Copyright (c)  2002 - 2005, Amnon Barak  and  Amnon Shiloh.
#  All rights reserved.
# 
#  THIS SOFTWARE  IS  SUBJECT  TO  THE CLIP SOFTWARE LICENSE AGREEMENT.
# 
#  THIS SOFTWARE IS PROVIDED IN ITS "AS IS" CONDITION, WITH NO WARRANTY
#  WHATSOEVER.  NO  LIABILITY  OF  ANY  KIND FOR ANY DAMAGES WHATSOEVER
#  RESULTING FROM THE USE OF THIS SOFTWARE WILL BE ACCEPTED.
# 
#  Authors: Lior Amar and Asaf Spainer
# 
#  CLIP $Id: Debug.pm,v 1.17 2007-10-08 10:12:21 lior Exp $ 


# util functions for clip.
package Util::Debug;  # assumes Some/Module.pm

#use Util::Paths;
use Data::Dumper;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw( debug_level 
		  debug_lr
                  debug_ly 
                  debug_lg 
		  debug_lb 
		  print_hash

		  print_msg
		  die_log_msg 
		  log_msg
                  isDebugOn
                  isDebugLevelOn
                  addDebugLevel
                  removeDebugLevel
                  getDebugLevels
                  readDebugFile
                  clearDebugLevel
		  clear_all_debug_level

                  NAIVE_DBG
                  ALLOC_MGR_DBG
                  AMGR_DBG
                  AMGR2_DBG
                  MMGR_DBG
                  PMGR_DBG PMGR2_DBG
                  JMGR_DBG JMGR2_DBG
                  SD_DBG  SD2_DBG  SD_CTL_DBG
		  PVD_DBG PVD2_DBG PVD3_DBG PVD_CTL_DBG
                  ED_DBG  ED2_DBG  ED_CTL_DBG
                  MARKET_DBG
                  DMARKET_DBG
                  NET_DBG
                  TF_DBG
                  CF_DBG
                  BNK_DBG
                  PROVIDER_XML_DBG
                  MPROT_DBG

                  curr_func_name
                  calling_func_name

		);

use strict;

# For the network module
use constant NET_DBG        => "NET_DBG";
# For the time frame module
use constant TF_DBG         => "TF_DBG";
# For the ProviderXMLParser
use constant PROVIDER_XML_DBG => "PROVIDER_XML_DBG";

# For the SIMPEL conf file 
use constant CF_DBG         => "CF_DBG";
# The naive solver 
use constant NAIVE_DBG      => "NAIVE_DBG";
use constant MMGR_DBG       => "MMGR_DBG";
use constant PMGR_DBG       => "PMGR_DBG";
use constant PMGR2_DBG      => "PMGR2_DBG";
use constant AMGR_DBG       => "AMGR_DBG";
use constant AMGR2_DBG      => "AMGR2_DBG";
use constant JMGR_DBG       => "JMGR_DBG";
use constant JMGR2_DBG      => "JMGR2_DBG";
use constant ALLOC_MGR_DBG  => "ALLOC_MGR_DBG";

# Sormad
use constant SD_DBG         => "SD_DBG";
use constant SD2_DBG        => "SD2_DBG";
use constant SD_CTL_DBG     => "SD_CTL_DBG";

# Providerd
use constant PVD_DBG        => "PVD_DBG";
use constant PVD2_DBG       => "PVD2_DBG";
use constant PVD3_DBG       => "PVD3_DBG";
use constant PVD_CTL_DBG    => "PVD_CTL_DBG";

# Economyd (the distributed market)
use constant ED_DBG         => "ED_DBG";
use constant ED2_DBG        => "ED2_DBG";
use constant ED_CTL_DBG     => "ED_CTL_DBG";
use constant MARKET_DBG     => "MARKET_DBG";
use constant DMARKET_DBG    => "DMARKET_DBG";
use constant BNK_DBG        => "BNK_DBG";
use constant MPROT_DBG      => "MPROT_DBG";

#############################################################################
#------------------ Functions def -------------------------------------------
#############################################################################
sub print_hash;
sub debug_level;
sub debug_level_color;
sub debug_lr;
sub debug_lg;
sub debug_ly;
sub debug_lb;

sub get_level_color_str;

#############################################################################
#------------------ Globals -------------------------------------------------
#############################################################################
my $dbgLevelHash;
my $SETCOLOR_GREEN="\033[1;32m";
my $SETCOLOR_GREEN1="\033[1;36m";
my $SETCOLOR_RED="\033[1;31m";
my $SETCOLOR_YELLOW="\033[1;33m";
my $SETCOLOR_BLUE="\033[1;34m";

my $SETCOLOR_NORMAL="\033[0;39m";

my $esc = "\033[";
my $bpre =  "$esc;1m";
my $bpost = "$esc;m";

sub debug_lr {
    debug_level_color("red", @_);
}

sub debug_lg {
    debug_level_color("green", @_);
}

sub debug_ly {
    debug_level_color("yellow", @_);
}

sub debug_lb {
    debug_level_color("blue", @_);
}

sub debug_level {
    my $level = shift;
    my $msg = shift;
    my $color = $SETCOLOR_NORMAL;

    if (@_) {
	$color = shift;
    }

    if (exists($dbgLevelHash->{$level})) {
	print STDERR  $SETCOLOR_GREEN1, "$level: ", $color, $msg , $SETCOLOR_NORMAL;
    }

}

sub debug_level_color {
    my $color = shift;
    my $color_str = get_level_color_str($color);
    
    debug_level(@_, $color_str);
}


sub get_level_color_str {
    my $color = shift;
    my $color_esc;

  SWITCH: for ($color) {
      /green/     && do {$color_esc = $SETCOLOR_GREEN; print  last;};
      /red/       && do {$color_esc = $SETCOLOR_RED; print  last;};
      /yellow/    && do {$color_esc = $SETCOLOR_YELLOW; print  last};
      /blue/      && do {$color_esc = $SETCOLOR_BLUE; print  last};
      $color_esc = $SETCOLOR_NORMAL;
  }
    
    return $color_esc;
}

sub print_hash {
    my $level = shift;
    if (!exists($dbgLevelHash->{$level})) {
	return;
    }
    
    my $hash = shift;
    print  STDERR $SETCOLOR_GREEN1, "START HASH($level):" , $SETCOLOR_NORMAL, "\n";
    print  STDERR Data::Dumper->Dump([$hash], ["hash"]);
    print  STDERR $SETCOLOR_GREEN1, "END HASH($level)" , $SETCOLOR_NORMAL, "\n\n";
}

sub clear_all_debug_level {
    $dbgLevelHash = undef;
}

sub clearDebugLevel {
    $dbgLevelHash = undef;
}

sub isDebugOn {
    return keys(%$dbgLevelHash) > 0;
}

sub isDebugLevelOn {
    my $lvl = shift;
    return 1 
      if(exists($dbgLevelHash->{$lvl}));
    return 0;
}

sub addDebugLevel {
    my $level = shift;
    
    $dbgLevelHash->{$level} = 1;
}


sub removeDebugLevel {
    my $level = shift;
    
    delete $dbgLevelHash->{$level}
      if(exists($dbgLevelHash->{$level}));
}

sub getDebugLevels {
    my @l;

    @l = keys(%$dbgLevelHash);
    return @l;
}
################################
# read the debug levels
################################

sub readDebugFile
{
    my $conf_file = shift;
    
    open(FILE, $conf_file) or return 0;
    
    while(my $line = <FILE>)  {
	#print "line $line";
	next if $line =~ /^\#/;  #comment line
        $line =~ s/^\s+//;
        $line =~ s/\s+$//;
	addDebugLevel($line);
    }
}

# my $dbg_file;
# $dbg_file = $ENV{CLIP_DBG_FILE} ? $ENV{CLIP_DBG_FILE} : "/.clip_dbg";
    

# if( -r $dbg_file) {
#     read_clip_debug_file($dbg_file);
# } else {
#     #print STDERR "CLIP: cannot read debug file: $dbg_file\n";
# }

#####################
# Getting the current function name
sub curr_func_name  { (caller(1))[3] }
sub calling_func_name { (caller(2))[3] }

1;

END { }  ; 


