package Util::MarketProtocol;
use Data::Dumper;
use Util::Net;
use Util::Debug;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(recvMarketMsg sendMarketMsg $marketProtocoltag
                 $marketHeaderSize $marketTypeTag $marketClassTag $marketDataTag 
                 $providerCtlClass $distMarketClass $economydCtlClass
                 $resultOKTag $resultErrorTag
                 createMarketMsg recvMarketMsg getData sendMarketMsg createAndSendMarketMsg
                 isMsgClass isMsgType);

our $marketHeaderSize    = 50;
our $marketTypeTag       = "type";
our $marketClassTag      = "class";
our $marketProtocolTag   = "message";
our $marketDataTag       = "data";

# Message classes
our $providerCtlClass    = "provider-ctl";
our $economydCtlClass    = "economyd-ctl";
our $distMarketClass     = "dist-market";

our $resultOKTag     = "ok";
our $resultErrorTag  = "error";

use strict;
use XML::Simple;

sub recvMarketMsg {
    my $socket = shift;
    my $timeout = shift;

    my $header = secure_recv($socket, $marketHeaderSize, $timeout);
    return undef if ! defined($header);
    chomp($header);

    return undef unless($header && $header =~ /\s*(\d+)\s*/);
    my $len = $1;

    # Recieve the result of the query
    return secure_recv($socket, $len, $timeout);
}

sub getData {
    my $msgH = shift;

    return (exists $msgH->{$marketDataTag} ? $msgH->{$marketDataTag} : undef);
}

sub createAndSendMarketMsg {
    my $socket = shift;
    my $class = shift;
    my $type = shift;
    my @params = @_;

    sendMarketMsg($socket, createMarketMsg($class, $type, @params));
}

sub createMarketMsg {
    my $class = shift;
    my $type = shift;
    my @params = @_;

    my $msgXml;


    if ($class eq $distMarketClass) {
        $msgXml = Util::DistMarketProtocol::createDMMsg($type, @params);
    }

    return $msgXml;
}

sub sendMarketMsg {

    my $socket = shift;
    my $msgXml = shift;

    if(!defined($socket)) {
        debug_lr(MPROT_DBG, "sendMarketMsg: Error socket is not defined\n"); 
        return 0;
    }
    
    $msgXml = "<$marketProtocolTag>\n".$msgXml."</$marketProtocolTag>";

    # create header
    my $format = "%$marketHeaderSize"."s";
    my $header = sprintf($format, length($msgXml));

    
    $header   .= ' 'x($marketHeaderSize - length($header));
    
    debug_lg(MPROT_DBG, "Header: [$header] reallen:".length($msgXml)."\n".
             "Data: [".$msgXml."]\n");
    
    if ($socket->peername()) {
      return $socket->send($header.$msgXml);
    } else {
        debug_lr(MPROT_DBG, "Send failed undefined peer name\n");
        return;
    }
}

sub isMsgType {
    my $type = shift;
    my $msgH = shift;

    return ($msgH->{$marketTypeTag} eq $type) ? 1 : 0;
}

sub isMsgClass {
    my $class = shift;
    my $msgH = shift;

    return ($msgH->{$marketClassTag} eq $class) ? 1 : 0;
}
