#****c* Util/TimeFrame
# FUNCTION
# 
# Manage time frames. Time frames determine when the provider is available or 
# not
# 
# 

package Util::TimeFrame;

use strict;
use Data::Dumper; 
use Date::Manip;
use Util::Debug;


my $frameTag   = "frame";
my $alwaysTag  = "always";
 
#****m* Util/TimeFrame->new
# FUNCTION
#   Constractor for the TimeFrame object
# SYNOPSIS
#   $tf = new TimeFrame('conf' => $conf)
# ARGUMENTS
#   conf          A has table which is used as the initial configuration 
# RETURN VALUE
#  undef    On error
#  A reference to a TimeFrame object on success
#******
sub new {
	my $proto = shift;
	my $class = ref($proto) || $proto;
	
	my %params = @_;
          
	my $self = {
	    %params,
	};

	if ( !exists($self->{conf}) ) {
            debug_ly(TF_DBG, "Warning: no conf file was given to time frame object\n");
            $self->{conf} = {"$frameTag" =>[]};
	}
        
	bless($self, $class);
	
        return undef if(!$self->verifyTimeFrames());
        debug_ly(TF_DBG, Dumper($self->{conf}, "conf"));
	return $self;
}

sub verifyTimeFrames {
    my $self = shift;
    
    my @tfList = ();
    my $c = $self->{conf};
    # we get a list in the name of frame
    return 1 if(exists($c->{$alwaysTag}));
                
    return 0 if(!exists($c->{$frameTag}));

    # Checking if we got the $frameTag as a list of as a hash
    if(ref($c->{$frameTag}) eq "HASH") {
        $c->{$frameTag} = [$c->{$frameTag}];
    }
    
    my $index = 0;
    foreach my $tf (@{$c->{$frameTag}}) {
        my $start = $tf->{start};
        my $end   = $tf->{end};

        my $unixStart = UnixDate(ParseDate($start), "%s");
        my $unixEnd   = UnixDate(ParseDate($end), "%s");

        debug_ly(TF_DBG, "Verifying $start ($unixStart) - $end ($unixEnd)\n");
        if(!$unixStart || !$unixEnd) {
            debug_lr(TF_DBG, "Error in $index time frame\n");
            return 0;
        }
        if($unixEnd < $unixStart) {
            debug_ly(TF_DBG, " start time > end time in frame $index, splitting\n");
            if( ($unixStart - $unixEnd) > 24*60*60) {
                debug_lr(TF_DBG, "Error start > end by more than 24h\n");
                return 0;
            }
            # Splitting, the time frame to 2 time frames. The original one and
            # one from 00:00 to $end
            my $newFrame = {
                            'start' => "00:00",
                            'end'   => $end,
                           };
            push @{$c->{$frameTag}}, $newFrame;
        }
        debug_lg(TF_DBG, "TF  $start - $end\n");
        $index++;
    }
    
    return 1;
}


#****m* Util/TimeFram->getOpenStatus
# FUNCTION
#   Checks if the provider should be open or closed and how much time is left
#   until the next close
# SYNOPSIS
#   $res = $tf->isOpen();
# ARGUMENTS
# RETURN VALUE
#  > 0    If the provider should be open and how much time left
#  0    If the provider should be closed
#******
sub getOpenStatus {
    my $self = shift;
    my $timeStr = shift;
    
    $timeStr = "now" if(!$timeStr);

    return -1 if(exists($self->{conf}->{$alwaysTag}));
    
    my $date = ParseDate($timeStr);
    return 0 if(!$date);
    my $currUnixTime =  UnixDate($date, "%s");
    
    my $openTime = 0;
    my $c = $self->{conf};
    
    my $index = 0;
    my @matchedTFEnd = ();
    foreach my $tf (@{$c->{$frameTag}}) {
        my $start = $tf->{start};
        my $end   = $tf->{end};
        
        my $unixStart = UnixDate(ParseDate($start), "%s");
        my $unixEnd   = UnixDate(ParseDate($end), "%s");
        
        # Adding 24 hours so we get end>start
        $unixEnd += 24*60*60 if($unixEnd < $unixStart);
        
        if($currUnixTime >= $unixStart &&
           $currUnixTime < $unixEnd) {
            
            debug_lb(TF_DBG, "Found apropriate time frame $index\n");
            push @matchedTFEnd, $unixEnd;
        }    
        $index++;
    }
    return 0 if(!@matchedTFEnd);

    my $maxEndTime = -1;
    foreach my $endTime (@matchedTFEnd) {
        $maxEndTime = $endTime > $maxEndTime ? $endTime : $maxEndTime;
    }
    my $secLeft = $maxEndTime - $currUnixTime;
    debug_lb(TF_DBG, "Seconds left $secLeft\n");
    return $secLeft/(3600);
}


1;
