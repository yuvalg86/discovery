#  JobManager $Id: JobManager.pm,v 1.19 2007-09-06 15:11:49 elylevy Exp $ #  


#****c* sormad/JobManager
# FUNCTION
# 
# This module is a data-structure for managing the current jobs in the cluster.
# The jobs are kept and are accessible via the interface functions

package Util::JobManager;


########### ProviderManager global definitions #######
require Exporter;
@ISA = qw(Exporter);


#use Exporter 'import';

@EXPORT = qw (
 $mandatoryJobFields $additionalJobFields $allJobFields
 $jobFieldsFmt 
 $jobTag  $idTag $jobFinishedValue $jobRunningValue $jobMigDoneValue $statusTag
 $priceTag
 $jobListTag

 JOB_RUN_STAT 
 JOB_WAIT_STAT
 JOB_MIG_STAT
 JOB_ABORT_STAT
 JOB_FINISH_STAT
 JOB_SUSPEND_STAT

 JOB_BID_MARKET_STAT
 JOB_WIN_MARKET_STAT
 JOB_READY_MARKET_STAT
 JOB_PROTECTED_MARKET_STAT
 JOB_NO_BUDGET_MARKET_STAT
);


$mandatoryJobFields = {
                       'id'           => "id",
                       'max-pay'      => "max-pay",
                       'from'         => "from",
                      };

$additionalJobFields = {
                        'cpu-num'       => "cpu-num",
                        'user'          => "user",
                        'max-budget'    => "max-budget",
                        'mem'           => "mem",
                        'finish'        => "finish",
                        'where'         => "where",
                        'prev-where'    => "prev-where",
                        'status'        => "status",
                        'market-status' => "market-status",
                        'sched-where'   => "sched-where",
                        'bid-where'     => "bid-where",
                        'bid-price'     => "bid-price",
                        'sched-price'   => "sched-price",
                        'curr-pay'      => "curr-pay",
                        'total-pay'     => "total-pay",
                        'prev-update'   => "prev-update",
                        'uid'           => "uid",
                        'total-run-time'=> "total-run-time",
                        'mig-run-time'  => "mig-run-time",
                        'run-time-mark' => "run-time-mark",
                       };

$allJobFields = {
                 %$mandatoryJobFields,
                 %$additionalJobFields,
                };


$jobFieldsFmt = {
                 'max-pay'      => "%.4f",
                 'max-budget'   => "%.4f",
                 'mem'          => "%.2f",
                 'curr-pay'     => "%.4f",
                 'total-pay'    => "%.4f",
};

our $jobTag           = "job";
our $idTag            = "id";
our $jobFinishedValue = "finished";
our $jobMigDoneValue  = "migdone";
our $jobRunningValue  = "running";
our $jobListTag       = "submissions";

our $statusTag   = "status";
our $priceTag    = "price";


use constant  'JOB_WAIT_STAT'     => 'wait';
use constant  'JOB_MIG_STAT'      => 'migrating';
use constant  'JOB_RUN_STAT'      => 'run';
use constant  'JOB_SUSPEND_STAT'  => 'suspend';
use constant  'JOB_ABORT_STAT'    => 'abort';
use constant  'JOB_FINISH_STAT'   => 'finish';

use constant  'JOB_BID_MARKET_STAT' => 'bid';
use constant  'JOB_WIN_MARKET_STAT' => 'win';
use constant  'JOB_READY_MARKET_STAT' => 'ready';
use constant  'JOB_PROTECTED_MARKET_STAT' => 'prot';
use constant  'JOB_NO_BUDGET_MARKET_STAT' => 'nobgt';

####################################### End of global defines ################


use strict;
use Sys::Syslog;
use Data::Dumper; 
use XML::Simple;

use Util::Debug;
use sormad::SormadParam;

sub new;
sub getTotalJobNum;
sub getRunableJobNum;
sub getWaitingJobNum;
sub getNoBudgetJobNum;
sub getJobsAtState;
sub getJobsXml;
sub addJob;
sub removeJob;
sub removeJobsByNode;
sub updateJob;
sub getStatusStr;
sub setJobStatus;
sub setJobMarketStatus;
sub getJobInfo;
sub setJobPayment;
sub updateTotalPay;
sub foreachJob;

#****m* sormad/JobManager->new
# FUNCTION
#   Constractor for the JobManager object
# SYNOPSIS
#   $jMgr = new ProviderD();
# ARGUMENTS
# RETURN VALUE
#  undef    On error
#  A reference to a JobManager object on success
#******
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my %params = @_;
    
    my $self = {
                %params,
               };
    
    $self->{totalJobNum} = 0;    # The number of registerd job
    $self->{jobsAtState}->{JOB_RUN_STAT()} = 0;
    $self->{jobsAtState}->{JOB_WAIT_STAT()} = 0;
    $self->{jobsAtState}->{JOB_SUSPEND_STAT()} = 0;
    $self->{jobsAtState}->{JOB_ABORT_STAT()} = 0;
    $self->{jobsAtState}->{JOB_FINISH_STAT()} = 0;

    $self->{marketReadyJobs} = 0;

    $self->{jobH} = {};
    $self->{jobLog} = "";
    $self->{logFileHndl} = undef;

    $self->{listenerList} = ();

    $self->{f} = {};

    
    bless($self, $class);
    $self->setFieldsNames();
    return $self;
}

# sets the names of the different job fields
sub setFieldsNames {
    my $self = shift;
    
    foreach my $name (keys %$mandatoryJobFields) {
        $self->{f}->{$name} = $mandatoryJobFields->{$name};
    }
    foreach my $name (keys %$additionalJobFields) {
        $self->{f}->{$name} = $additionalJobFields->{$name};
    }
}

sub addListener {
    my $self = shift;
    my $func = shift;
    my $obj = shift;

    return (push @{$self->{listenerList}}, {'func'=>$func, 'obj'=>$obj}) - 1;
}

sub triggerListener {
    my $self = shift;
    my $msgH = shift;

   foreach my $listener (@{$self->{listenerList}}) {
       my $obj = $listener->{obj};
       my $func = $listener->{func};

       if(defined($obj)) {
           &{$func}($obj, $msgH);
       }
       else {
           &{$func}($msgH);
       }
   }
}

# verify that a giving job hash has all the mandatory fields
sub verifyJobHash {
    my $self = shift;
    my $jH = shift;

    foreach my $k (keys(%$mandatoryJobFields)) {
        if(!exists($jH->{$k})) {
            debug_lr(JMGR_DBG, "Missing field $k\n");
            return 0;
        }
        # Removing spaces 
        $jH->{$k} =~ s/^\s+//;
        $jH->{$k} =~ s/\s+$//;
    }
    return 1;
}

# sets the log file handle to the given handle
sub setLogFileHandle {
    my $self = shift;
    my $hndl = shift;

    $self->{logFileHndl} = $hndl;
}


#****m* sormad/JobManager->getTotalJobNum
# FUNCTION
#   Returns the total number of jobs
# SYNOPSIS
#   $jobNum = $self->getTotalJobNum();
# ARGUMENTS
# RETURN VALUE
#  The total number of jobs
sub getTotalJobNum {
    my $self = shift;
    return $self->{totalJobNum};
}


#****m* sormad/JobManager->getReadyJobNum
# FUNCTION
#   Returns the number of ready to be bid upon jobs
# SYNOPSIS
#   $readJobsNum = $self->getReadyJobNum();
# ARGUMENTS
# RETURN VALUE
#  The number of ready to be bid upon jobs
sub getReadyJobNum {
    my $self = shift;
    
    #my $total = $self->getTotalJobNum();
    #my $noBudget = $self->getJobsAtState(JOB_NO_BUDGET_STAT);
    
    #return $total - $noBudget;
    return $self->getMarketReadyJobNum();
}

# returns the number of job with market ready status
sub getMarketReadyJobNum {
    my $self = shift;
    return $self->{marketReadyJobs};
}

#****m* sormad/JobManager->getJobsAtState
# FUNCTION
#   Returns the number of job in a given job state
# SYNOPSIS
#   $jobsNum = $self->getReadyJobNum($state);
# ARGUMENTS
#   state - the job state we want to count
# RETURN VALUE
#  The number of job in a given job state
sub getJobsAtState {
    my $self = shift;
    my $state = shift;
    
    if(exists($self->{jobsAtState}->{$state})) {

        return $self->{jobsAtState}->{$state};
    }
    debug_lr(JMGR_DBG, "Error no such state $state\n");
    return -1;
    
    #return exists($self->{jobsAtState}->{$state}) ? 
    #  $self->{jobsAtState}->{$state} : -1
}

# Convert the given job xml into hash
sub jobXmlToHash {
    my $self = shift;
    my $jobInfo = shift;
    
    if(! ref($jobInfo)) {
        debug_lg(JMGR_DBG, "Got string converting to xml\n");
        my $jobH = XMLin($jobInfo);
        if(!$jobH) {
            debug_lr(JMGR_DBG, "Failed converting string to job info hash\n");
            return 0;
        }
        $jobInfo = $jobH;
    }
    return $jobInfo;
}

#****m* sormad/JobManager->addJob
# FUNCTION
#   Adds the given job
# SYNOPSIS
#   $self->addJob($jobH,0);
# ARGUMENTS
#   jobH - The job hash we want to add (can be xml)
#   verify - Should we verify the job hash (0 false 1 true)
# RETURN VALUE 
#  0 on failure
#  1 on success
sub addJob {
    my $self = shift;
    my $jobInfo = shift;  # A hash ref
    my $noVerify = 0;
    $noVerify = shift  if(@_);
    
    # If we get a scalar we treat is as xml string
    return 0 if(!($jobInfo = $self->jobXmlToHash($jobInfo)));
    
    # A special flags tell the method not to verify
    unless($noVerify) {
        return 0 if(!$self->verifyJobHash($jobInfo));
    }
    
    if(exists($self->{jobH}->{$jobInfo->{id}})) {
        debug_ly(JMGR_DBG, "Job already exists only updating\n");
        return $self->updateJob($jobInfo, 1);
    }

    my $id = $jobInfo->{id};
    $self->{jobH}->{$id} = $jobInfo;
    $self->{totalJobNum}++;
    
    # Setting the status of the job
    my $jh = $self->{jobH}->{$id};
    
    $jh->{$self->{f}->{'total-run-time'}} = 0
      if(! exists($jh->{$self->{f}->{'total-run-time'}}));
    
    $jh->{$self->{f}->{'mig-run-time'}} = 0;
    $jh->{$self->{f}->{'total-pay'}} = 0;
    $jh->{$self->{f}->{'curr-pay'}}  = 0;
    $jh->{"sched-where"} = "";
    $jh->{"sched-price"} = "";
    $jh->{"bid-where"}   = "";
    $jh->{"bid-price"}   = "";
    $jh->{"prev-where"}  = "";
    
    my $c;
    if(exists($jobInfo->{$self->{f}->{where}}) and $jobInfo->{$self->{f}->{where}} ne ""){
        $jh->{$self->{f}->{'run-time-mark'}} = time();
        $self->setJobStatus($id, JOB_RUN_STAT, $jobInfo->{$self->{f}->{where}}, \$c);
    } else {
        $self->setJobStatus($id, JOB_WAIT_STAT, "", \$c);
    }
    
    # Setting the default market status to ready
    $self->setJobMarketStatus($id, JOB_READY_MARKET_STAT, "");

    ####### Fixing some of the job fields #####
    # Fixing the where field
    $jh->{$self->{f}->{where}} = ""
      if(!exists($jh->{$self->{f}->{where}}));
         

    # Setting the user field from the uid field
    if(!exists($jobInfo->{$self->{f}->{user}})) {
        if(exists($jh->{$self->{f}->{uid}})) {
            $jh->{$self->{f}->{user}} = getpwuid($jh->{$self->{f}->{uid}});
        }
        else {
            $jh->{$self->{f}->{user}} = $jh->{$self->{f}->{from}};
        }
    }

    # Setting a default cpu-num usage to 1 (if non was given)
    $jh->{$self->{f}->{'cpu-num'}} = 1
      if(!exists($jobInfo->{$self->{f}->{'cpu-num'}}));
    
    # Fixing the mem field to be a number and not include the MB suffix
    if(exists($jh->{$self->{f}->{'mem'}})) {
        $jh->{$self->{f}->{'mem'}} =~ s/(\d+)MB/$1/;
    } else {
        $jh->{$self->{f}->{'mem'}} = -1;
    }
    # Adding some new fields
    #$jh->{$self->{f}->{'prev-update'}} = time(); # Taking the time of the addition
     
    
    debug_ly(JMGR_DBG, "Successfully added job: $jobInfo->{id}\n");
    return 1;
}


#****m* sormad/JobManager->removeJob
# FUNCTION
#   Removes a given job 
# SYNOPSIS
#   $self->removeJob($jobID);
# ARGUMENTS
#   jobID - The job id we want to remove (can be xml)
# RETURN VALUE 
#  0 on failure
#  1 on success
sub removeJob {
    my $self = shift;
    my $jobID = shift;  # A hash ref
    
    if(!exists($self->{jobH}->{$jobID})) {
        debug_lr(JMGR_DBG, "Job $jobID does not exists\n");
        return 0;
    }
    debug_lr(JMGR_DBG, "Removing job $jobID\n");
    
    my $c;
    $self->setJobStatus($jobID, JOB_FINISH_STAT, "", \$c);
    $self->{totalJobNum}--;
    delete($self->{jobH}->{$jobID});
    return 1;
}


#****m* sormad/JobManager->removeJobsByNode
# FUNCTION
#   Removes all jobs from a given node
# SYNOPSIS
#   $self->removeJobsByNode($addr);
# ARGUMENTS
#   addr - The address of the node
# RETURN VALUE 
#  0 on failure
#  1 on success
sub removeJobsByNode {
    my $self = shift;
    my $addr = shift;

    debug_lb(JMGR_DBG, "Removing all jobs of node: $addr\n");
    # In the future this will be optimize, now a simple linear search
    foreach my $id (keys(%{$self->{jobH}})) {
        $self->removeJob($id)
          if($addr eq $self->{jobH}->{$id}->{$self->{f}->{from}});
    }
    return 1;
}

#****m* sormad/JobManager->updateJob
# FUNCTION
#   Updates job information for given job info
# SYNOPSIS
#   $self->addJob($jobInfo,0);
# ARGUMENTS
#   jobInfo - The job hash we want to update (can be xml)
#   verify - Should we verify the job hash (0 false 1 true)
# RETURN VALUE 
#  0 on failure
#  1 on success
sub updateJob {
    my $self = shift;
    my $jobInfo = shift;

    my $noVerify = 0;
    $noVerify = shift if(@_);
    
    # If we get a scalar we treat is as xml string
    return 0 if(!($jobInfo = $self->jobXmlToHash($jobInfo)));
    
    # A special flags tell the method not to verify
    unless($noVerify) {
        return 0 if(!$self->verifyJobHash($jobInfo->{id}));
    }
    
    if(!exists($self->{jobH}->{$jobInfo->{id}})) {
        debug_lr(JMGR_DBG, "Job $jobInfo->{id} does not exists cant update\n");
        return 0;
    }

    $self->{jobH}->{$jobInfo->{id}} = $jobInfo;
    return 1;
}

#****m* sormad/JobManager->getJobInfo
# FUNCTION
#   Returns the job information of the job with the given id
# SYNOPSIS
#   $self->getJobInfo($jobID);
# ARGUMENTS
#   jobID - The job id we want to get
# RETURN VALUE 
#  0 on failure
#  1 on success
sub getJobInfo {
    my $self = shift;
    my $jobID = shift;
    
    if(!exists($self->{jobH}->{$jobID})) {
        return undef;
    }
    return $self->{jobH}->{$jobID};
}

#****m* sormad/JobManager->getJobXml
# FUNCTION
#   Returns the job xml the job with the given id
# SYNOPSIS
#   $self->getJobInfo($jobID,$marketXML);
# ARGUMENTS
#   jobID - The job id we want to get
#   MarketXML
# RETURN VALUE 
# The job's xml
sub getJobXml {
    my $self = shift;
    my $id = shift;
    my $marketXml = shift;
    
    return "" if(!exists($self->{jobH}->{$id}));
    
    my $j = $self->{jobH}->{$id};
    my $str = "<$jobTag id=\"$id\">\n";
    
    # Placing only the tags supported by the market
    if($marketXml) {
        foreach my $mk (keys %$jobMarketFields) {
            next if($mk eq "id");
            if($jobMarketFields->{$mk} and !exists($j->{$mk})) {
                debug_lr(JMGR_DBG, "Error a mandatory market field $mk is not present in job $id\n");
                return undef;
            }
            
            # If the budget is 0 or less we dont send this process to the market
            if($mk eq $self->{f}->{"max-budget"} and exists($j->{$mk})) {
                return "" 
                  if($j->{$mk} <= 0 );
            }
            
            if(exists($j->{$mk})) {
                if(exists($jobFieldsFmt->{$mk})) {
                    $str .= sprintf("\t<$mk>". $jobFieldsFmt->{$mk} . "</$mk>\n", 
                                    $j->{$mk});
                }
                else {
                    $str .= "\t<$mk>$j->{$mk}</$mk>\n"
                }
            }
        }
    }
    # Placing all current tags in the xml
    else {
        foreach my $k (keys %$j) {
            next if($k eq "id");
            
            if(exists($jobFieldsFmt->{$k})) {
                $str .= sprintf("\t<$k>". $jobFieldsFmt->{$k} . "</$k>\n", 
                                $j->{$k});
            }
            else {
                $str .= "\t<$k>$j->{$k}</$k>\n";
                if (! defined $j->{$k}) {
                    debug_lr(JMGR_DBG, "Undefined $k $j->{id} in xml creation\n");
                    #print Dumper($j);
                }
            }
        }
    }
    
    $str .= "</$jobTag>\n";
    return $str;
}

#****m* sormad/JobManager->getJobsXml
# FUNCTION
#   Returns the xml of all jobs
# SYNOPSIS
#   $self->getJobsXml($marketXML);
# ARGUMENTS
#   MarketXML
# RETURN VALUE 
# The jobs' xml
sub getJobsXml {
    my $self = shift;
    my $marketXml = 0;
    $marketXml = shift
      if(@_);
        
    my $xmlStr = "<$jobListTag>\n";
    foreach my $j (keys %{$self->{jobH}}) {
        my $jStr = $self->getJobXml($j, $marketXml);
        $xmlStr .= $jStr;
    }
    $xmlStr .= "</$jobListTag>\n";
    return $xmlStr;
}

#****m* sormad/JobManager->getJobsMarketXml
# FUNCTION
#   Returns the market xml of all jobs
# SYNOPSIS
#   $self->getJobsMarketXml();
# ARGUMENTS
#   MarketXML
# RETURN VALUE 
# The jobs' market xml
sub getJobsMarketXml {
    my $self = shift;
    return $self->getJobsXml(1);
}

# Returns the jobs status as string
sub getStatusStr {
    my $self = shift;
    my $str;

    $str .= sprintf("%-10s\t%-8s\t%-6s\t%-6s\t%-10s\n", 
                    "ID", "Status", "MaxPay", "CurrPay", "Where");
    foreach my $id (sort {$a <=> $b} (keys %{$self->{jobH}})) {
        my $jobH    = $self->{jobH}->{$id};
        my $maxPay  = $jobH->{$self->{f}->{"max-pay"}};
        my $status  = $jobH->{$self->{f}->{"status"}};
        my $mStatus = $jobH->{$self->{f}->{"market-status"}};

        my $schedWhere = "-";
        $schedWhere = $jobH->{$self->{f}->{"sched-where"}}
          if (exists $jobH->{$self->{f}->{"sched-where"}});

        my $where   = " - ";
        my $currPay = "0";
        if(exists($jobH->{$self->{f}->{where}})) {
            $where   =  $jobH->{$self->{f}->{where}};
            $currPay = $jobH->{$self->{f}->{"curr-pay"}};
        }
        $str .= sprintf("%-10s\t%-8s\t%-8s\t%-6.2f\t%-6.2f\t%-10s\t%-10s\n", 
                        $id, $status, $mStatus, $maxPay, $currPay, $where, $schedWhere);
    }
    return $str;
}

#****m* sormad/JobManager->setJobMarketStatus
# FUNCTION
#  Setting the job market status
# SYNOPSIS
#   $res = $jmgr->setJobMarketStatus($id, $status, $provider)
# ARGUMENTS
#  $id          Job id number
#  $status      Market status to set
#  $provider    The provider this market status applies to
# RETURN VALUE
#  0     on error
#  1     on success
#******
sub setJobMarketStatus {
    my $self = shift;
    my $job  = shift;
    my $status = shift;
    my $provider = shift;
    my $price    = shift;
    
    return 0 
      if(!exists($self->{jobH}->{$job}));
    
    my $jobH = $self->{jobH}->{$job};
    
    my $prevStatus = exists($jobH->{$self->{f}->{'market-status'}}) ? 
      $jobH->{$self->{f}->{'market-status'}} : ""; 
    
    $jobH->{$self->{f}->{'market-status'}} = $status;

    if ($status eq JOB_WIN_MARKET_STAT) {
      $jobH->{$self->{f}->{'sched-where'}} = $provider;  
      $jobH->{$self->{f}->{'sched-price'}} = $jobH->{$self->{f}->{'bid-price'}}; 
#      print "sched-price is ".$jobH->{$self->{f}->{'sched-price'}}."\n";
      $jobH->{$self->{f}->{'bid-price'}} = "";

    } 
    elsif ($status eq JOB_BID_MARKET_STAT) {

      $jobH->{$self->{f}->{'bid-where'}} = $provider;
      $jobH->{$self->{f}->{'bid-price'}} = $price;
      $jobH->{$self->{f}->{'sched-where'}} = "";
      $jobH->{$self->{f}->{'sched-price'}} = "";  
    } 
    elsif ($status eq JOB_PROTECTED_MARKET_STAT || 
           $status eq JOB_READY_MARKET_STAT) {
        $jobH->{$self->{f}->{'bid-where'}} = "";
        $jobH->{$self->{f}->{'sched-where'}} = $provider;
        $jobH->{$self->{f}->{'bid-price'}} = "";
        
        $jobH->{$self->{f}->{'curr-pay'}} = $jobH->{$self->{f}->{'sched-price'}}
          if($jobH->{$self->{f}->{'sched-price'}} ne "");  
        $jobH->{$self->{f}->{'curr-pay'}} = $price 
          if(defined($price));
        
        $jobH->{$self->{f}->{'sched-price'}} = "";
    }
    elsif($status eq JOB_NO_BUDGET_MARKET_STAT) {
      $jobH->{$self->{f}->{'sched-where'}} = "";
      $jobH->{$self->{f}->{'bid-where'}} = "";
      $jobH->{$self->{f}->{'bid-price'}} = "";
      $jobH->{$self->{f}->{'sched-price'}} = "";
      $jobH->{$self->{f}->{'curr-pay'}} = 0;
    }
    
    # Updating the number of ready jobs
    $self->{marketReadyJobs}--
      if(($prevStatus eq JOB_READY_MARKET_STAT) and 
         ($status ne JOB_READY_MARKET_STAT));
    
    $self->{marketReadyJobs}++
      if(($prevStatus ne JOB_READY_MARKET_STAT) and 
         ($status eq JOB_READY_MARKET_STAT));

    $self->{lastMsgInfo}->{type} = "market";
    $self->{lastMsgInfo}->{stat} = $status;
    $self->{lastMsgInfo}->{jobId} = $job;
    $self->triggerListener($self->{lastMsgInfo});

    return 1;
}

sub isRunningOn {
      my $self = shift;
      my $job = shift;
      my $provider = shift;

      my $jobH = $self->{jobH}->{$job};

      return ($jobH->{$self->{f}->{where}} eq $provider);
}

sub handleRunTime {
  my $self = shift;
  my $job = shift;
  my $prevStatus = shift;
  my $newStatus = shift;
  my $time = shift;
  
  $time = time() if (! defined($time));

#  return if ($prevStatus eq $newStatus);

  if ($prevStatus eq JOB_RUN_STAT) {
      debug_lr(JMGR_DBG, "Running job without running time\n")
        if (! defined $job->{'run-time-mark'});
    
    my $timePassed = $time - $job->{'run-time-mark'};
    my $currPay = $job->{"curr-pay"};
    my $payAddition = ($job->{"curr-pay"}/3600)*$timePassed;
    
      #debug_lg(JMGR_DBG, "Adding $timePassed sec to job, $job->{'run-time-mark'}\n");
    $job->{'total-run-time'} += $timePassed;
    $job->{'mig-run-time'}   += $timePassed;
    
    $job->{"total-pay"}      += $payAddition;
    
    if(exists($job->{"max-budget"})) {
        $job->{"max-budget"} -= $payAddition;
    
        if($job->{$self->{f}->{"max-budget"}} <= 0) {
            my $c;

            $self->setJobMarketStatus($job->{"id"}, JOB_NO_BUDGET_MARKET_STAT,"");
            $self->setJobStatus($job->{"id"}, JOB_SUSPEND_STAT, "", \$c);
        }
    }
  } 
  if ($newStatus eq JOB_RUN_STAT) {
      $job->{'run-time-mark'} = $time;
  }
  if ($newStatus eq JOB_MIG_STAT) {
      $job->{'mig-run-time'} = 0;
  }

}

#****m* sormad/JobManager->setJobStatus
# FUNCTION
#  Setting the job status
# SYNOPSIS
#   $res = $jmgr->setJobStatus($id, $status, $provider, $changed)
# ARGUMENTS
#  $id          Job id number
#  $status      Status to set
#  $provider    The provider this status applies to
#  $changed     A ref to a scalar that indicate (0|1) if there was a change 
#               from the previous status
# RETURN VALUE
#  0     on error
#  1     on success
#******
sub setJobStatus {
    my $self = shift;
    my $job  = shift;
    my $newStatus = shift;
    my $provider = shift;
    my $changed = shift;

    my $c = 0;
    return 0 
      if(!exists($self->{jobH}->{$job}));
   
    my $jobH = $self->{jobH}->{$job};
    
    # The status
    my $prevStatus = exists($jobH->{$self->{f}->{status}}) ? $jobH->{$self->{f}->{status}} : ""; 

    # In case of a waiting job, it remains in wait if new status is suspended.
    if($prevStatus eq JOB_WAIT_STAT and 
       $newStatus eq JOB_SUSPEND_STAT) {
      $newStatus = JOB_WAIT_STAT;
    }

    debug_ly(JMGR_DBG, "Changing job $job status from $prevStatus to $newStatus\n");
    $self->handleRunTime($jobH, $prevStatus, $newStatus);

    #debug_lr(JMGR_DBG, "prevStat $prevStatus newStat $newStatus\n");
    $jobH->{$self->{f}->{status}} = $newStatus; 
    
    # If there was a change in the job status we update the statistics
    if($newStatus ne $prevStatus) {
        $c = 1;
        # Previous status is decremented if it is not the first time the job
        # added
        $self->{jobsAtState}->{$prevStatus} --
          if($self->{jobsAtState}->{$prevStatus});
        $self->{jobsAtState}->{$newStatus} ++;
    }
    
    # Saving the current where location of the process
    if(defined($jobH->{$self->{f}->{where}})) {
        $jobH->{$self->{f}->{'prev-where'}} = $jobH->{$self->{f}->{where}};
    }
    # The where (or which provider should run this job)
    if($provider) {
        $c = 1
          if($jobH->{$self->{f}->{where}} ne $provider);
        $jobH->{$self->{f}->{where}} = $provider;
    }


    # Clearing the where and curr-pay if the job is not running now
    if($newStatus eq JOB_SUSPEND_STAT)
      # || $newStatus eq JOB_NO_BUDGET_STAT) 
      {
          $jobH->{$self->{f}->{where}}="";
      }
    
    # Adding a log entry
    $self->addJobLogLine($job) if($c);

    $self->{lastMsgInfo}->{type} = "status";
    $self->{lastMsgInfo}->{stat} = $newStatus;
    $self->{lastMsgInfo}->{jobId} = $job;
    $self->triggerListener($self->{lastMsgInfo});
    
    $$changed = $c;
    return 1;
}

# adds a log line about the given job id.
# if/where it started running and waiting
sub addJobLogLine {
    my $self = shift;
    my $id = shift;

    my $jh = $self->{jobH}->{$id};
    
    my $timeStr = time();
    my $status = $jh->{$self->{f}->{status}};
    my $logLine =  "$timeStr $id $status ";
    my $jobDetails = "";
    # First time the job was submitted
    if($status eq JOB_WAIT_STAT) {
        my $maxPay = $jh->{$self->{f}->{'max-pay'}};
        my $maxBudgetStr = "-";
        if(exists($jh->{$self->{f}->{'max-budget'}})) {
          $maxBudgetStr = sprintf("%.2f", $jh->{$self->{f}->{'max-budget'}});
        }
        my $from = $jh->{$self->{f}->{'from'}};
        
        $jobDetails = sprintf("%.2f $maxBudgetStr %s ", $maxPay, $from);
    }
    elsif ($status eq JOB_RUN_STAT) {
        my $where = $jh->{$self->{f}->{'where'}};
        my $currPay = $jh->{$self->{f}->{'curr-pay'}};
        
        $jobDetails = sprintf("%.2f %s ",$currPay, $where);
    }
    

    $logLine .= $jobDetails . "\n";
    if(defined($self->{logFileHndl})) {
        print {$self->{logFileHndl}} $logLine;
    }
}

#****m* sormad/JobManager->setJobPayment
# FUNCTION
#  Setting the job payment
# SYNOPSIS
#   $res = $jmgr->setJobPayment($id, $payment)
# ARGUMENTS
#  $id          Job id number
#  $payment     The payment to set
# RETURN VALUE
#  0     on error
#  1     on success
#******
sub setJobPayment {
    my $self = shift;
    my $job  = shift;
    my $payment = shift;

    return 0 
      if(!exists($self->{jobH}->{$job}));
    
    my $jobH = $self->{jobH}->{$job};
    $jobH->{$self->{f}->{'curr-pay'}} = $payment; 

    return 1;
}

sub setJobMaxPayment {
    my $self = shift;
    my $job  = shift;
    my $payment = shift;

    return 0 
      if(!exists($self->{jobH}->{$job}));
    
    my $jobH = $self->{jobH}->{$job};
    debug_lg(JMGR_DBG, "Max pay $job: $jobH->{'max-pay'} -> $payment\n");
    $jobH->{$self->{f}->{'max-pay'}} = $payment; 
    return 1;
}


# It is possible to supply the currTime via a parameter. This is very usefull 
# for testings
sub updateTotalPay {
    my $self = shift;

    my $currTime;
    $currTime = $@ ? shift : time();

    debug_lb(JMGR2_DBG, "Updating total pay\n");

    foreach my $id ((keys %{$self->{jobH}})) {
        my $jh = $self->{jobH}->{$id};
        
        # The job is running 
        if($jh->{$self->{f}->{status}} eq JOB_RUN_STAT) {
            $self->handleRunTime($jh, JOB_RUN_STAT, JOB_RUN_STAT, $currTime);
        }

    }

    return 1;
}

#****m* sormad/JobManager->foreachJob
# FUNCTION
#  Runs a given function on all the jobs
# SYNOPSIS
#   $res = foreachJob($self, $func, data)
# ARGUMENTS
#  $id          Job id number
#  $func        Reference to the function we want to run
#  $data        Data for the function
# RETURN VALUE
#******
sub foreachJob {
    my $self = shift;
    my $func = shift;
    my $data = shift;

    #print Dumper $self->{jobH};
    foreach my $j (keys %{$self->{jobH}}) {
     #   print "Doing $j\n";
        &{$func}($self->{jobH}->{$j}, $data, $self);
    }
}

1;
