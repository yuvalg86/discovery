package Util::DistMarketProtocol;
use Data::Dumper;
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw($bidPeriod $protectedPeriod $freePeriod createDMMsg
                 $dmBidType $dmScheduleType $dmRejectType $dmJobSwitchType
                 $dmUnScheduleType $dmBidOverType $dmLoadJobType $dmUnloadJobType 
                 $dmJobDoneType $dmJobNoBgtType $dmJobUnprotectType);

# Market times
$bidPeriod = 10;
$protectedPeriod = 10;
$freePeriod = 10;

# Dist Market Protocol

our $dmBidType              = "bid";
our $dmScheduleType         = "schedule";
our $dmRejectType           = "reject";
our $dmUnScheduleType       = "unSchedule";
our $dmBidOverType          = "bidOver";
our $dmLoadJobType          = "loadJob";
our $dmUnloadJobType        = "unloadJob";
our $dmJobDoneType          = "jobDone";
our $dmJobNoBgtType         = "jobNoBudget";
our $dmJobUnprotectType     = "jobUnprotect";
our $dmJobSwitchType        = "jobSwitch";

use strict;
use XML::Simple;
use Util::MarketProtocol;

sub createDMMsg {
    my $type = shift;
    my @params = @_;

    # create message xml
    my $cmd = "_create".ucfirst($type)."Msg"; 
    my $msgH = eval "$cmd(\@params)"; 
    $msgH->{$marketClassTag} = $distMarketClass;
    $msgH->{$marketTypeTag} = $type;

    my $xml = XMLout($msgH, NoAttr=>1, RootName=>"");
    print "$@\n" if ! defined $xml;

    return $xml;
}

# Bid messages
sub _createBidMsg {
    my $bidRef = shift;
    my $msgH = {};

    $msgH->{val}   = $bidRef->{val};
    $msgH->{host}  = $bidRef->{host};
    $msgH->{jobId} = $bidRef->{jobId};
    
    return $msgH;
}

# Reject messages
sub _createRejectMsg {
    my $jobId = shift;
    my $reason = shift;
    my $val = shift;
    my $msgH = {};
    $msgH->{jobId} = $jobId;
    $msgH->{reason} = $reason;
    $msgH->{val} = $val;

    return $msgH;
}

# Schedule messages
sub _createScheduleMsg {
    my $jobId = shift;
    my $reason = shift;
    my $val = shift;
    my $msgH = {};
    $msgH->{jobId} = $jobId;
    $msgH->{reason} = $reason;
    $msgH->{val} = $val;
    return $msgH;
}

# UnUnschedule messages
sub _createUnScheduleMsg {
    my $jobId = shift;
    my $reason = shift;
    my $val = shift;
    
    $val = -1 if(!defined($val));

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    $msgH->{reason} = $reason;
    $msgH->{val} = $val;
    return $msgH;
}

# LoadJob messages
sub _createLoadJobMsg {
    my $jobId = shift;

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    return $msgH;
}

# bidOver messages
sub _createBidOverMsg {
    my $jobId = shift;

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    return $msgH;
}

# UnloadJob messages
sub _createUnloadJobMsg {
    my $jobId = shift;

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    return $msgH;
}


# Job done messages
sub _createJobDoneMsg {
    my $jobId = shift;

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    return $msgH;
}


# Job no budget messages
sub _createJobNoBudgetMsg {
    my $jobId = shift;

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    return $msgH;
}


# Job unprotect message
sub _createJobUnprotectMsg {
    my $jobId = shift;

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    return $msgH;
}

# Job switch messages
sub _createJobSwitchMsg {
    my $jobId = shift;

    my $msgH = {};
    $msgH->{jobId} = $jobId;
    return $msgH;
}
1;
