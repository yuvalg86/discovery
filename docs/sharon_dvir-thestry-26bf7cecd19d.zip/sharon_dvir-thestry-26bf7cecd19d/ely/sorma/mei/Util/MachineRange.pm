#
#  Copyright (c)  2002 - 2005, Amnon Barak  and  Amnon Shiloh.
#  All rights reserved.
# 
#  THIS SOFTWARE  IS  SUBJECT  TO  THE CLIP SOFTWARE LICENSE AGREEMENT.
# 
#  THIS SOFTWARE IS PROVIDED IN ITS "AS IS" CONDITION, WITH NO WARRANTY
#  WHATSOEVER.  NO  LIABILITY  OF  ANY  KIND FOR ANY DAMAGES WHATSOEVER
#  RESULTING FROM THE USE OF THIS SOFTWARE WILL BE ACCEPTED.
# 
#  Authors: Lior Amar and Asaf Spainer
# 
#  CLIP $Id: MachineRange.pm,v 1.2 2006-12-13 07:53:27 lior Exp $ 


# util functions for clip.
package MachineRange;  # assumes Some/Module.pm

use Util::Debug;
use strict;

##########################################################################
#------------------- Functions def ---------------------------------------
##########################################################################

sub get_machine_list;
sub build_machine_list;


##########################################################################

#-------------------------------------------------------------------------
# Building a list of machines from a given range  
# mos1...2
#
sub build_machine_list 
{
    my $range;
    my $list = shift;
    my @range_list = split /\,/ , $list;
    my @list = ();
    my $i;
	
    foreach $range( @range_list ) {
	if( $range =~ /^(.*)\.\.(.*)$/ ) {
	    my $first_machine = $1;
	    my $until = $2;
	    $first_machine =~ /^(.*\D)(\d+)$/ or
		die "`$first_machine' doesn't end with a digit!\n";
	    my $name = $1;
	    my $from = $2;
	    for $i( $from..$until ) {
		push @list , "$name$i";
	    }
	} else {
	    push @list , $range ;
	}
    }

    return @list;
}

#--------------------------------------------------------------------------
# This function is use by add and remove machine scripts 
# to parse this list of the machine
#
sub get_machine_list 
{
    my $list = shift;
    my @two_lists = split /\^/ , $list;
    my $machine;
	
    @two_lists <= 2 or
	die "`!' might appear only once inside machine list!\n";
    my @temp_list = build_machine_list( $two_lists[0] );
    my %del_list = ();
    if( defined $two_lists[1] ) {
	foreach $machine( build_machine_list( $two_lists[1] ) ) {
	    $del_list{$machine} = 1;
	}
    }
    my %list = ();
    foreach $machine( @temp_list ) {
	$list{$machine} = 1 if not defined $del_list{$machine};
    }
    return keys %list;
}


    
1;

END { }  ; 
